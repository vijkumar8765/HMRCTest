
package lbf_party_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGResponseEnvelope;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_PartyRetrResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_PartyRetrResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_ResponseEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="partyRetrieveDetails" type="{http://LBF_Party_1_0}DG_PartyRetrDetails" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_PartyRetrResponse", propOrder = {
    "partyRetrieveDetails"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGPartyRetrResponse
    extends DGResponseEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGPartyRetrDetails partyRetrieveDetails;

    /**
     * Gets the value of the partyRetrieveDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGPartyRetrDetails }
     *     
     */
    public DGPartyRetrDetails getPartyRetrieveDetails() {
        return partyRetrieveDetails;
    }

    /**
     * Sets the value of the partyRetrieveDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPartyRetrDetails }
     *     
     */
    public void setPartyRetrieveDetails(DGPartyRetrDetails value) {
        this.partyRetrieveDetails = value;
    }

}
