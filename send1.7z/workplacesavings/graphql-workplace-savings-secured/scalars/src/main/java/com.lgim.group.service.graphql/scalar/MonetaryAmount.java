package com.lgim.group.service.graphql.scalar;

import graphql.schema.Coercing;
import graphql.schema.CoercingParseValueException;
import graphql.schema.CoercingSerializeException;
import graphql.schema.GraphQLScalarType;

import java.math.BigDecimal;

public class MonetaryAmount extends GraphQLScalarType {
  public MonetaryAmount() {
    super("MonetaryAmount", "MonetaryAmount type", new Coercing<BigDecimal, String>() {
      private BigDecimal convertImpl(Object input) {
        if (input instanceof Float) {
          return new BigDecimal((Float) input).setScale(2);
        }

        return null;
      }


      public String serialize(Object input) {
        if (input instanceof BigDecimal) {
          return ((BigDecimal) input).toPlainString();
        } else {
          BigDecimal result = this.convertImpl(input);
          if (result == null) {
            throw new CoercingSerializeException("Invalid value '" + input + "' for Float");
          }
          return result.toPlainString();
        }
      }

      public BigDecimal parseValue(Object input) {
        BigDecimal result = this.convertImpl(input);
        if (result == null) {
          throw new CoercingParseValueException("Invalid value '" + input + "' for Float");
        } else {
          return result;
        }
      }

      public BigDecimal parseLiteral(Object input) {
        BigDecimal result = this.convertImpl(input);
        if (result == null) {
          throw new CoercingParseValueException("Invalid value '" + input + "' for Float");
        } else {
          return result;
        }
      }

    });
  }
}
