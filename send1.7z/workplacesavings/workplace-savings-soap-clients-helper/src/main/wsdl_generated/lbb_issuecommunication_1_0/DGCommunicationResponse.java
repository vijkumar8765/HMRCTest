
package lbb_issuecommunication_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGResponseEnvelope;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_CommunicationResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_CommunicationResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_ResponseEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="pdfStream" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_CommunicationResponse", propOrder = {
    "pdfStream"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGCommunicationResponse
    extends DGResponseEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected byte[] pdfStream;

    /**
     * Gets the value of the pdfStream property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getPdfStream() {
        return pdfStream;
    }

    /**
     * Sets the value of the pdfStream property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setPdfStream(byte[] value) {
        this.pdfStream = value;
    }

}
