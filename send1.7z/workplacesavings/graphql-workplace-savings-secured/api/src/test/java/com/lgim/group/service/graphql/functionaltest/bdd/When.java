package com.lgim.group.service.graphql.functionaltest.bdd;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgim.group.service.graphql.dto.versions.MicroServiceReportDto;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;

import static org.springframework.http.HttpMethod.POST;

public class When {

  private static volatile List<MicroServiceReportDto> versionResponse;
  private final String getVersionQuery = "{\"query\":\"{ getVersions {groupId,artifactId,version} }\"}";

  private final String url = "http://localhost:8011/graphql";

  private final ObjectMapper mapper = new ObjectMapper();
  private final RestTemplate client = new RestTemplate();

  public When() {
    List<HttpMessageConverter<?>> messageConverters = new ArrayList<>();
    MappingJackson2HttpMessageConverter jsonMessageConverter = new MappingJackson2HttpMessageConverter();
    jsonMessageConverter.setObjectMapper(mapper);
    messageConverters.add(jsonMessageConverter);
    client.setMessageConverters(messageConverters);
  }

  public static List<MicroServiceReportDto> theVersionResponseFromGraphQl() {
    List<MicroServiceReportDto> response = When.versionResponse;
    When.versionResponse = null;
    return response;
  }

  //This doesn't need to be changed for other services
  public void theGraphQLServerReceivesAGetVersionsRequest() throws InterruptedException, IOException {
    HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    headers.add(HttpHeaders.ACCEPT_CHARSET, StandardCharsets.UTF_8.name());
    RequestEntity requestEntity = new RequestEntity(mapper.readTree(getVersionQuery), headers, POST, URI.create(url));
    LinkedHashMap responseDto = (LinkedHashMap) ((LinkedHashMap) client.exchange(requestEntity, LinkedHashMap.class).getBody().get("data"));
    Collection dtoList = (Collection<MicroServiceReportDto>) responseDto.get("getVersions");
    When.versionResponse = mapper.convertValue(dtoList, new TypeReference<List<MicroServiceReportDto>>() {
    });
  }
}
