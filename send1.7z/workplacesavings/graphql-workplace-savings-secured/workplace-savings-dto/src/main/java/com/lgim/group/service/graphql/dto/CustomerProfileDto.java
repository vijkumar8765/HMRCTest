package com.lgim.group.service.graphql.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Style;

@Immutable
@Style(init = "with*")
@JsonSerialize(as = ImmutableCustomerProfileDto.class)
@JsonDeserialize(as = ImmutableCustomerProfileDto.class)
public interface CustomerProfileDto {

  String getTitle();

  String getForename();

  String getSurname();

  String getGender();

  String getDateOfBirth();
}
