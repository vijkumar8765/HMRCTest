package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class InvestmentStrategyDto implements java.io.Serializable {
  private String fundCode;
  private Float contributionPercentage;
  private String name;

  public InvestmentStrategyDto(String fundCode, Float contributionPercentage, String name) {
    this.fundCode = fundCode;
    this.contributionPercentage = contributionPercentage;
    this.name = name;
  }
}
