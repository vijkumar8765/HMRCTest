
package lbb_issuecommunication_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGRequestEnvelope;
import lbb_generatecommunication_1.DGRecipientData;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_CommunicationRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_CommunicationRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_RequestEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="recipientData" type="{http://LBB_GenerateCommunication_1}DG_RecipientData" minOccurs="0"/&gt;
 *         &lt;element name="payload" type="{http://LBB_IssueCommunication_1_0}DG_CommunicationPayload" minOccurs="0"/&gt;
 *         &lt;element name="requesterPartyID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="archiveFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="documentType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="lgUserId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="processName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_CommunicationRequest", propOrder = {
    "recipientData",
    "payload",
    "requesterPartyID",
    "archiveFlag",
    "documentType",
    "lgUserId",
    "processName"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGCommunicationRequest
    extends DGRequestEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGRecipientData recipientData;
    protected DGCommunicationPayload payload;
    protected String requesterPartyID;
    protected Boolean archiveFlag;
    protected String documentType;
    protected String lgUserId;
    protected String processName;

    /**
     * Gets the value of the recipientData property.
     * 
     * @return
     *     possible object is
     *     {@link DGRecipientData }
     *     
     */
    public DGRecipientData getRecipientData() {
        return recipientData;
    }

    /**
     * Sets the value of the recipientData property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGRecipientData }
     *     
     */
    public void setRecipientData(DGRecipientData value) {
        this.recipientData = value;
    }

    /**
     * Gets the value of the payload property.
     * 
     * @return
     *     possible object is
     *     {@link DGCommunicationPayload }
     *     
     */
    public DGCommunicationPayload getPayload() {
        return payload;
    }

    /**
     * Sets the value of the payload property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGCommunicationPayload }
     *     
     */
    public void setPayload(DGCommunicationPayload value) {
        this.payload = value;
    }

    /**
     * Gets the value of the requesterPartyID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequesterPartyID() {
        return requesterPartyID;
    }

    /**
     * Sets the value of the requesterPartyID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequesterPartyID(String value) {
        this.requesterPartyID = value;
    }

    /**
     * Gets the value of the archiveFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isArchiveFlag() {
        return archiveFlag;
    }

    /**
     * Sets the value of the archiveFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setArchiveFlag(Boolean value) {
        this.archiveFlag = value;
    }

    /**
     * Gets the value of the documentType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentType() {
        return documentType;
    }

    /**
     * Sets the value of the documentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentType(String value) {
        this.documentType = value;
    }

    /**
     * Gets the value of the lgUserId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLgUserId() {
        return lgUserId;
    }

    /**
     * Sets the value of the lgUserId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLgUserId(String value) {
        this.lgUserId = value;
    }

    /**
     * Gets the value of the processName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessName() {
        return processName;
    }

    /**
     * Sets the value of the processName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessName(String value) {
        this.processName = value;
    }

}
