
package lbb_organisationcommon_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lbb_partycommon_1_0.DGParty;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_Organisation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_Organisation"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LBB_PartyCommon_1_0}DG_Party"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="details" type="{http://LBB_OrganisationCommon_1_0}DG_OrganisationDetails" minOccurs="0"/&gt;
 *         &lt;element name="contactDetails" type="{http://LBB_OrganisationCommon_1_0}DG_OrgContactDetails" minOccurs="0"/&gt;
 *         &lt;element name="groupArrangements" type="{http://LBB_OrganisationCommon_1_0}DG_GroupArrangement" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_Organisation", propOrder = {
    "details",
    "contactDetails",
    "groupArrangements"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGOrganisation
    extends DGParty
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGOrganisationDetails details;
    protected DGOrgContactDetails contactDetails;
    protected List<DGGroupArrangement> groupArrangements;

    /**
     * Gets the value of the details property.
     * 
     * @return
     *     possible object is
     *     {@link DGOrganisationDetails }
     *     
     */
    public DGOrganisationDetails getDetails() {
        return details;
    }

    /**
     * Sets the value of the details property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGOrganisationDetails }
     *     
     */
    public void setDetails(DGOrganisationDetails value) {
        this.details = value;
    }

    /**
     * Gets the value of the contactDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGOrgContactDetails }
     *     
     */
    public DGOrgContactDetails getContactDetails() {
        return contactDetails;
    }

    /**
     * Sets the value of the contactDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGOrgContactDetails }
     *     
     */
    public void setContactDetails(DGOrgContactDetails value) {
        this.contactDetails = value;
    }

    /**
     * Gets the value of the groupArrangements property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the groupArrangements property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGroupArrangements().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGGroupArrangement }
     * 
     * 
     */
    public List<DGGroupArrangement> getGroupArrangements() {
        if (groupArrangements == null) {
            groupArrangements = new ArrayList<DGGroupArrangement>();
        }
        return this.groupArrangements;
    }

}
