package com.lgim.group.service.graphql.dto.versions;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class MicroServiceReportDto implements java.io.Serializable {

  private String groupId;
  private String artifactId;
  private String version;

  public MicroServiceReportDto(String groupId, String artifactId, String version) {
    this.groupId = groupId;
    this.artifactId = artifactId;
    this.version = version;
  }
}
