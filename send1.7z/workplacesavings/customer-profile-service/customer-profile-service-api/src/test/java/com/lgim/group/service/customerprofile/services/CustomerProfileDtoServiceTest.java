package com.lgim.group.service.customerprofile.services;

import com.lgim.group.service.customerprofile.audit.AuditHelper;
import com.lgim.group.service.customerprofile.dto.CustomerProfileDto;
import com.lgim.group.service.customerprofile.exception.CustomerNotFoundException;
import com.lgim.group.service.customerprofile.services.db.CustomerStoredProcedureCall;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CustomerProfileDtoServiceTest {

  private static final String CUSTOMER_ID = "Customer ID";
  @Mock
  private CustomerStoredProcedureCall customerStoredProcedureCall;
  @Mock
  private AuditHelper auditHelper;
  @InjectMocks
  private CustomerProfileService underTest;

  @Test
  public void getCustomerById() {
    final CustomerProfileDto mockCustomerProfileDto = mock(CustomerProfileDto.class);

    final List<CustomerProfileDto> profiles = new ArrayList<>();
    profiles.add(mockCustomerProfileDto);

    final Map<String, Object> results = new HashMap<>();
    results.put(CustomerProfileService.RETURN_CODE_KEY, 0);
    results.put(CustomerStoredProcedureCall.RESULT_SET_KEY, profiles);

    when(customerStoredProcedureCall.execute(anyString())).thenReturn(results);

    final CustomerProfileDto actual = underTest.getCustomerByPartyId(CUSTOMER_ID);

    assertEquals("Unexpected customer profile returned", mockCustomerProfileDto, actual);
  }

  @Test(expected = CustomerNotFoundException.class)
  public void getCustomerNoResultSet() {
    final Map<String, Object> results = new HashMap<>();
    results.put(CustomerProfileService.RETURN_CODE_KEY, 0);
    results.put(CustomerStoredProcedureCall.RESULT_SET_KEY, null);

    when(customerStoredProcedureCall.execute(anyString())).thenReturn(results);

    underTest.getCustomerByPartyId(CUSTOMER_ID);
  }

  @Test(expected = CustomerNotFoundException.class)
  public void getCustomerByIdErrorCodeReturned() {
    final Map<String, Object> results = new HashMap<>();
    results.put(CustomerProfileService.RETURN_CODE_KEY, -1);
    when(customerStoredProcedureCall.execute(anyString())).thenReturn(results);
    underTest.getCustomerByPartyId(CUSTOMER_ID);
  }

  @Test(expected = CustomerNotFoundException.class)
  public void hasErrorsIsNull() {
    when(customerStoredProcedureCall.execute(anyString())).thenReturn(null);
    underTest.getCustomerByPartyId("INVALID");
  }
}