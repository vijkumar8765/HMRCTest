package com.lgim.group.gatekeeper.processor;

import com.lgim.group.gatekeeper.exception.ProxyEndPointNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ProxyRequestProcessor implements Processor {

  @Autowired
  private Environment env;

  @Override
  public void process(Exchange exchange) throws Exception {

    //Lookup the url that was original passed in the REST request
    Object camelHttpUri = exchange.getIn().getHeader("CamelHttpUri");

    if (camelHttpUri == null) {
      exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, "404");
      return;
    }

    String camelHttpUriStr = (String)camelHttpUri;

    //extract the resource that was passed on the url
    String service = camelHttpUriStr.substring(camelHttpUriStr.lastIndexOf('/') + 1);

    //Look to see if the service has a valid property set for the endpoint url
    String proxyEndPoint = env.getProperty(String.format("proxy_service_%s_url", service));

    if (proxyEndPoint == null || proxyEndPoint.equals("")) {
      throw new ProxyEndPointNotFoundException("End point for found for service " + service);
    }

    //If we have found a valid end point set it as the value for the proxyEndPoint header
    exchange.getIn().setHeader("proxyEndPoint", proxyEndPoint );

  }
}
