package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
public class WorkplacePensionInputDto implements java.io.Serializable {
  private List<BenefitInputDto> benefitsHoldings;
  private List<BenefitInputDto> benefitsFutureContributions;
  private String emailAddress;

  public WorkplacePensionInputDto(List<BenefitInputDto> benefitsHoldings, List<BenefitInputDto> benefitsFutureContributions, String emailAddress) {
    this.benefitsHoldings = benefitsHoldings;
    this.benefitsFutureContributions = benefitsFutureContributions;
    this.emailAddress = emailAddress;
  }
}
