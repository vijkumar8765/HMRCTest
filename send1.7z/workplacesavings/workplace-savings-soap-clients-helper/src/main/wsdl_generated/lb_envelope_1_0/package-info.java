@javax.xml.bind.annotation.XmlSchema(namespace = "http://LB_Envelope_1_0")
package lb_envelope_1_0;
