package com.lgim.group.service.customerprofile.controllers;

import com.lgim.group.gatekeeper.exception.JwtAuthenticationException;
import com.lgim.group.service.customerprofile.audit.AuditHelper;
import com.lgim.group.service.customerprofile.authorization.AuthorizationHelper;
import com.lgim.group.service.customerprofile.dto.CustomerProfileDto;
import com.lgim.group.service.customerprofile.services.CustomerProfileService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customer-profile/")
public class CustomerController {

  private static final String BUSINESS_FUNCTION = "workplacesavings";
  private static final String MICRO_SERVICE_NAME = "CustomerProfileService";
  private static final String MICRO_SERVICE_METHOD = "getCustomerProfile";
  private CustomerProfileService customerProfileService;
  private AuthorizationHelper authorizationHelper;
  private AuditHelper auditHelper;

  public CustomerController(final CustomerProfileService customerProfileService, final AuthorizationHelper authorizationHelper, final AuditHelper auditHelper) {
    this.customerProfileService = customerProfileService;
    this.authorizationHelper = authorizationHelper;
    this.auditHelper = auditHelper;
  }

  @GetMapping
  public ResponseEntity<CustomerProfileDto> getCustomerProfile(@RequestHeader("Authorization") String authorizationHeader) throws JwtAuthenticationException {
    final String partyId = authorizationHelper.authorizeRequest(authorizationHeader);
    auditHelper.audit(partyId, BUSINESS_FUNCTION, MICRO_SERVICE_NAME, MICRO_SERVICE_METHOD);
    final CustomerProfileDto customerProfileDto = customerProfileService.getCustomerByPartyId(partyId);
    return ResponseEntity.status(HttpStatus.OK).body(customerProfileDto);
  }
}
