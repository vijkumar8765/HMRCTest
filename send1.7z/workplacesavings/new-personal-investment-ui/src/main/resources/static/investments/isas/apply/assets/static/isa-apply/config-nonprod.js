/* eslint-disable */
window.runtime_config = {
  APP_ID: 'b9acf210866838d9157c38f8f30a1338',
  REACT_APP_UNAUTH_PERSONAL_INVEST_LG_ENDPOINT:
    'https://api-u00.lgim.com/personal-investment-public/graphql',
  REACT_APP_AUTH_PERSONAL_INVEST_LG_ENDPOINT:
    'http://54.171.68.162:8484/graphql',
  REACT_APP_UNAUTH_WORKPLACE_SAVE_LG_ENDPOINT:
    'http://54.171.68.162:8484/graphql',
  REACT_APP_AUTH_WORKPLACE_SAVE_LG_ENDPOINT:
    'https://es-mock-api.herokuapp.com/switch-redirect-auth/graphql', // 'http://localhost:8080/switch-redirect-auth/graphql', //
  REACT_APP_ISA_APPLY_REDIRECT: '/consumer/investments/',
  REACT_APP_ISA_APPLY_PRIVACY_POLICY: '/UTMprivacy',
  REACT_APP_MIN_PAYMENT_LIMIT: 100,
  REACT_APP_MIN_REGULAR_PAYMENT_LIMIT: 20,
  REACT_APP_MAX_PAYMENT_LIMIT: 20000,
  REACT_APP_MAX_UNIT_TRUST_LIMIT: 999999,
  REACT_APP_TAX_YEAR: '2018/19',
  REACT_APP_EMERALD_QUIT: '/investments/',
  REACT_APP_SAPPHIRE_QUIT: '/pensions-retirement/',
  REACT_APP_SAPPHIRE_ALL_DONE: '/pensions-retirement/',
  REACT_APP_SAPPHIRE_WIP_ERROR: '/pensions-retirement/',
  REACT_APP_SAPPHIRE_MAX_FUND_EACH_BENEFIT: 50,
  REACT_APP_SAPPHIRE_MAX_DISTINCT_FUNDS: 100,
  REACT_APP_SAPPHIRE_SUSPENDED_FUND: '/suspendedFunds.json', //'https://www.legalandgeneral.com/web_resources/lgrs/assets/suspendedFunds.json'
  REACT_APP_ADOBE_DTM_JS:
    '//assets.adobedtm.com/launch-EN09d715d366ff4637840ff4345bbf80fb-staging.min.js',
  REACT_APP_SAPPHIRE_MAX_DISTINCT_FUNDS: 100,
  REACT_APP_ADOBE_DTM_JS: '//assets.adobedtm.com/launch-ENe888d205478d457ba3e2a66d45153653-development.min.js',
  REACT_APP_KEYCLOAK_URL: 'https://api-d02.lgim.com/auth',
  REACT_APP_KEYCLOAK_REALM_URL: 'dcp-d00',
  REACT_APP_KEYCLOAK_CLIENT_URL: 'dcp-sr-d00',
  REACT_APP_KEYCLOAK_LOGIN: true,
  REACT_APP_KEYCLOAK_EXPIRE_TIME: 60,
  REACT_APP_LOGOUT_TIME: '30',
  REACT_APP_NYA_SESSION_URL: 'https://www20.landg.com/FlexSvngsPlatformWeb/keepSessionAlive',
  REACT_APP_NYA_POLLING_SECOUNDS: 60,
};
