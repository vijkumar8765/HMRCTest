
package lbb_organisationcommon_1_0;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the lbb_organisationcommon_1_0 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: lbb_organisationcommon_1_0
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DGOrganisationEmailAddress }
     * 
     */
    public DGOrganisationEmailAddress createDGOrganisationEmailAddress() {
        return new DGOrganisationEmailAddress();
    }

    /**
     * Create an instance of {@link DGTaxDetails }
     * 
     */
    public DGTaxDetails createDGTaxDetails() {
        return new DGTaxDetails();
    }

    /**
     * Create an instance of {@link DGOrganisationNameDetails }
     * 
     */
    public DGOrganisationNameDetails createDGOrganisationNameDetails() {
        return new DGOrganisationNameDetails();
    }

    /**
     * Create an instance of {@link DGOrganisationName }
     * 
     */
    public DGOrganisationName createDGOrganisationName() {
        return new DGOrganisationName();
    }

    /**
     * Create an instance of {@link DGOrganisationDetails }
     * 
     */
    public DGOrganisationDetails createDGOrganisationDetails() {
        return new DGOrganisationDetails();
    }

    /**
     * Create an instance of {@link DGGroupArrangement }
     * 
     */
    public DGGroupArrangement createDGGroupArrangement() {
        return new DGGroupArrangement();
    }

    /**
     * Create an instance of {@link DGOrganisationAddress }
     * 
     */
    public DGOrganisationAddress createDGOrganisationAddress() {
        return new DGOrganisationAddress();
    }

    /**
     * Create an instance of {@link DGOrganisationTelephoneNumber }
     * 
     */
    public DGOrganisationTelephoneNumber createDGOrganisationTelephoneNumber() {
        return new DGOrganisationTelephoneNumber();
    }

    /**
     * Create an instance of {@link DGOrgContactDetails }
     * 
     */
    public DGOrgContactDetails createDGOrgContactDetails() {
        return new DGOrgContactDetails();
    }

    /**
     * Create an instance of {@link DGOrganisation }
     * 
     */
    public DGOrganisation createDGOrganisation() {
        return new DGOrganisation();
    }

    /**
     * Create an instance of {@link DGOpeningTimes }
     * 
     */
    public DGOpeningTimes createDGOpeningTimes() {
        return new DGOpeningTimes();
    }

    /**
     * Create an instance of {@link DGOrganisationalUnit }
     * 
     */
    public DGOrganisationalUnit createDGOrganisationalUnit() {
        return new DGOrganisationalUnit();
    }

    /**
     * Create an instance of {@link DGReturnAddress }
     * 
     */
    public DGReturnAddress createDGReturnAddress() {
        return new DGReturnAddress();
    }

}
