package com.lgim.group.service.graphql;

import com.lgim.group.service.graphql.util.JourneyIdExtractor;
import com.lgim.group.service.graphql.util.JourneyIdExtractorImpl;
import com.lgim.group.service.graphql.util.JwtTokenExtractorImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@TestPropertySource(locations = "classpath:test.properties")
public class GraphQLApplicationTest {

  @Autowired
  private ApplicationContext applicationContext;

  @Test
  public void testGraphiqlJwtTokenExtractorBeanIsNotLoadedForDefaultProfile() {

    assertTrue(applicationContext.getBean("jwtTokenExtractor") instanceof JwtTokenExtractorImpl);
    assertTrue(applicationContext.getBean("journeyIdExtractor") instanceof JourneyIdExtractorImpl);

  }
}