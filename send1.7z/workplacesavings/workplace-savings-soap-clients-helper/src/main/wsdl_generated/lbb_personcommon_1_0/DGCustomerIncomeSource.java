
package lbb_personcommon_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_CustomerIncomeSource complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_CustomerIncomeSource"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="incomeSourceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="startDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="endDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="mainEmploymentInd" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="pensionableSource" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="jobType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="retirementDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="controllingDirectorInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="occupationalSchemeMember" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="organisationPartyId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="certifiedEarnings" type="{http://LBB_PersonCommon_1_0}DG_CertifiedIncome" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="estimatedIncome" type="{http://LBB_PersonCommon_1_0}DG_EstimatedIncome" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_CustomerIncomeSource", propOrder = {
    "incomeSourceType",
    "startDate",
    "endDate",
    "mainEmploymentInd",
    "pensionableSource",
    "jobType",
    "retirementDate",
    "controllingDirectorInd",
    "occupationalSchemeMember",
    "organisationPartyId",
    "certifiedEarnings",
    "estimatedIncome"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGCustomerIncomeSource
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String incomeSourceType;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar startDate;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar endDate;
    protected Boolean mainEmploymentInd;
    protected Boolean pensionableSource;
    protected String jobType;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar retirementDate;
    protected String controllingDirectorInd;
    protected String occupationalSchemeMember;
    protected String organisationPartyId;
    protected List<DGCertifiedIncome> certifiedEarnings;
    protected List<DGEstimatedIncome> estimatedIncome;

    /**
     * Gets the value of the incomeSourceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncomeSourceType() {
        return incomeSourceType;
    }

    /**
     * Sets the value of the incomeSourceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncomeSourceType(String value) {
        this.incomeSourceType = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStartDate(XMLGregorianCalendar value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEndDate(XMLGregorianCalendar value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the mainEmploymentInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMainEmploymentInd() {
        return mainEmploymentInd;
    }

    /**
     * Sets the value of the mainEmploymentInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMainEmploymentInd(Boolean value) {
        this.mainEmploymentInd = value;
    }

    /**
     * Gets the value of the pensionableSource property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPensionableSource() {
        return pensionableSource;
    }

    /**
     * Sets the value of the pensionableSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPensionableSource(Boolean value) {
        this.pensionableSource = value;
    }

    /**
     * Gets the value of the jobType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobType() {
        return jobType;
    }

    /**
     * Sets the value of the jobType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobType(String value) {
        this.jobType = value;
    }

    /**
     * Gets the value of the retirementDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRetirementDate() {
        return retirementDate;
    }

    /**
     * Sets the value of the retirementDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRetirementDate(XMLGregorianCalendar value) {
        this.retirementDate = value;
    }

    /**
     * Gets the value of the controllingDirectorInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getControllingDirectorInd() {
        return controllingDirectorInd;
    }

    /**
     * Sets the value of the controllingDirectorInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setControllingDirectorInd(String value) {
        this.controllingDirectorInd = value;
    }

    /**
     * Gets the value of the occupationalSchemeMember property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOccupationalSchemeMember() {
        return occupationalSchemeMember;
    }

    /**
     * Sets the value of the occupationalSchemeMember property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOccupationalSchemeMember(String value) {
        this.occupationalSchemeMember = value;
    }

    /**
     * Gets the value of the organisationPartyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganisationPartyId() {
        return organisationPartyId;
    }

    /**
     * Sets the value of the organisationPartyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganisationPartyId(String value) {
        this.organisationPartyId = value;
    }

    /**
     * Gets the value of the certifiedEarnings property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the certifiedEarnings property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCertifiedEarnings().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGCertifiedIncome }
     * 
     * 
     */
    public List<DGCertifiedIncome> getCertifiedEarnings() {
        if (certifiedEarnings == null) {
            certifiedEarnings = new ArrayList<DGCertifiedIncome>();
        }
        return this.certifiedEarnings;
    }

    /**
     * Gets the value of the estimatedIncome property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the estimatedIncome property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEstimatedIncome().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGEstimatedIncome }
     * 
     * 
     */
    public List<DGEstimatedIncome> getEstimatedIncome() {
        if (estimatedIncome == null) {
            estimatedIncome = new ArrayList<DGEstimatedIncome>();
        }
        return this.estimatedIncome;
    }

}
