
package lbf_acct_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lbf_party_1_0.DGPartyRetrDetails;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_AcctPartyRole complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_AcctPartyRole"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="role" type="{http://LBF_Acct_1_0}DG_AcctRole" minOccurs="0"/&gt;
 *         &lt;element name="party" type="{http://LBF_Party_1_0}DG_PartyRetrDetails" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_AcctPartyRole", propOrder = {
    "role",
    "party"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGAcctPartyRole
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGAcctRole role;
    protected DGPartyRetrDetails party;

    /**
     * Gets the value of the role property.
     * 
     * @return
     *     possible object is
     *     {@link DGAcctRole }
     *     
     */
    public DGAcctRole getRole() {
        return role;
    }

    /**
     * Sets the value of the role property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGAcctRole }
     *     
     */
    public void setRole(DGAcctRole value) {
        this.role = value;
    }

    /**
     * Gets the value of the party property.
     * 
     * @return
     *     possible object is
     *     {@link DGPartyRetrDetails }
     *     
     */
    public DGPartyRetrDetails getParty() {
        return party;
    }

    /**
     * Sets the value of the party property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPartyRetrDetails }
     *     
     */
    public void setParty(DGPartyRetrDetails value) {
        this.party = value;
    }

}
