@javax.xml.bind.annotation.XmlSchema(namespace = "http://LBF_Party_1_0")
package lbf_party_1_0;
