package com.lgim.group.service.graphql.util;

import graphql.schema.DataFetchingEnvironment;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = GraphiqlConfig.class)
@TestPropertySource(properties = {"graphiql.jwt.token=Bearer sometoken"})
public class GraphiqlJwtTokenExtractorImplTest {

  @Autowired
  GraphiqlJwtTokenExtractorImpl jwtTokenExtractor;

  @Mock
  DataFetchingEnvironment environment;

  @Test
  public void testJwtTokenIsExtracted() {
    assertEquals("Bearer sometoken", jwtTokenExtractor.extractJwtToken(environment));
  }

}

@Configuration
class GraphiqlConfig {
  @Bean
  public GraphiqlJwtTokenExtractorImpl jwtTokenExtractor() {
    return new GraphiqlJwtTokenExtractorImpl();
  }

}
