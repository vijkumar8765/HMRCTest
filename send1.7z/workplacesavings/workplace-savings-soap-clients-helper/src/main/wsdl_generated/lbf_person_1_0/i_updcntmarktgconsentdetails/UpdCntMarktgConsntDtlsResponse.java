
package lbf_person_1_0.i_updcntmarktgconsentdetails;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import lbf_person_1_0.DGUpdCntMarktgConsntDtlsResp;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="resp" type="{http://LBF_Person_1_0}DG_UpdCntMarktgConsntDtlsResp"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "resp"
})
@XmlRootElement(name = "updCntMarktgConsntDtlsResponse")
@ToString
@EqualsAndHashCode
public class UpdCntMarktgConsntDtlsResponse implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(required = true, nillable = true)
    protected DGUpdCntMarktgConsntDtlsResp resp;

    /**
     * Gets the value of the resp property.
     * 
     * @return
     *     possible object is
     *     {@link DGUpdCntMarktgConsntDtlsResp }
     *     
     */
    public DGUpdCntMarktgConsntDtlsResp getResp() {
        return resp;
    }

    /**
     * Sets the value of the resp property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGUpdCntMarktgConsntDtlsResp }
     *     
     */
    public void setResp(DGUpdCntMarktgConsntDtlsResp value) {
        this.resp = value;
    }

}
