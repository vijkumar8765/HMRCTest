package com.lgim.group.gatekeeper.helpers;

import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.proc.BadJWTException;
import com.nimbusds.jwt.proc.JWTClaimsSetVerifier;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;

@Component
@Slf4j
/**
 * This class is used to store the rules used to validate a JWT token
 */
public class JwtValidator implements JWTClaimsSetVerifier {

  @Value("${public_key_valid_issuers}")
  private String publicKeyIssuers;

  @Value("${gatekeeper_date:#{null}}")
  private String gatekeeperDate;

  private HashSet<String> validIssuers = null;

  /**
   * Returns a hashset of valid Issuers, we need to  be able to support
   * multiple issues depending on whether the certificate was issued
   * from an external url via a reverse proxy or internally
   *
   * @return a hashset of valid issuers
   */

  private synchronized  HashSet<String> getValidIssuers() {
    if (validIssuers == null) {
      validIssuers = new HashSet<>();
      validIssuers.addAll(Arrays.asList(publicKeyIssuers.split(",")));
    }
    return validIssuers;
  }

  @Override
  /**
   * This method contains the checks that are performed on a JWT token
   */
  public synchronized void verify(JWTClaimsSet claimsSet, SecurityContext securityContext) throws BadJWTException {

    //Check that the JWT token has an Exiry time
    if (claimsSet.getExpirationTime() == null) {
      throw new BadJWTException("Missing token expiration claim");
    }

    //Check that the JWT token was issued by a valid issuer
    if (! getValidIssuers().contains(claimsSet.getIssuer())) {
      log.warn(String.format("Token issuer not accepted. received [%s]", claimsSet.getIssuer()));
      throw new BadJWTException("Token issuer not accepted");
    }

    Date validatationDate = new Date();
    if (gatekeeperDate != null) {
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      try {
        validatationDate = sdf.parse(gatekeeperDate);
        log.warn("******NOT CHECKING EXPIRY DATE******");
      } catch (ParseException parseException) {
        throw  new BadJWTException("Validation date is set but invalid");
      }
    }
    //Check that the JWT token hasn't expired
    if (validatationDate.after(claimsSet.getExpirationTime())) {
      log.warn("Token Expired");
      throw new BadJWTException("Token has Expired");
    }


  }
}
