package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
public class FundsInBasketDto implements java.io.Serializable {
  private List<BasketBenefitListDto> benefits;
  private BasketType basketType;

  public FundsInBasketDto(List<BasketBenefitListDto> benefits, BasketType basketType) {
    this.benefits = benefits;
    this.basketType = basketType;
  }
}
