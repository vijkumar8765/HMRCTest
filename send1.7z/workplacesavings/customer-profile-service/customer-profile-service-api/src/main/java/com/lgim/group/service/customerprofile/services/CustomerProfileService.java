package com.lgim.group.service.customerprofile.services;

import com.lgim.group.service.customerprofile.audit.AuditHelper;
import com.lgim.group.service.customerprofile.dto.CustomerProfileDto;
import com.lgim.group.service.customerprofile.exception.CustomerNotFoundException;
import com.lgim.group.service.customerprofile.services.db.CustomerStoredProcedureCall;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


@Slf4j
@Service
public class CustomerProfileService {

  static final String RETURN_CODE_KEY = "RETURN_CODE";

  private static final Integer RESULT_OK = 0;
  private static final String NO_CUSTOMER_PROFILE = "Stored procedure call successful but no customer profile found.";
  private static final String ERRORS_IN_RESULT = "Stored procedure call successful but contains errors.";

  private CustomerStoredProcedureCall customerStoredProcedureCall;


  public CustomerProfileService(CustomerStoredProcedureCall customerStoredProcedureCall) {
    this.customerStoredProcedureCall = customerStoredProcedureCall;
  }


  /**
   * Returns a customer profile for the given party ID.
   * Done by calling the GCD (Global Customer DB) stored
   * procedure named DB2SEC2.SP0027.
   *
   * @param partyId the party ID
   * @return the customer profile
   */
  public CustomerProfileDto getCustomerByPartyId(final String partyId) {
    log.info("Getting customer profile with party ID: {}", partyId);
    final CustomerProfileDto customerProfileDto = fetchCustomerByPartyId(partyId);
    log.info("Customer profile found: {}", customerProfileDto);
    return customerProfileDto;
  }

  private CustomerProfileDto fetchCustomerByPartyId(final String partyId) {
    final Map<String, Object> results = this.customerStoredProcedureCall.execute(partyId);
    if (!hasErrors(results)) {
      return getCustomerFromResults(results);
    } else {
      throw new CustomerNotFoundException(ERRORS_IN_RESULT);
    }
  }


  private boolean hasErrors(final Map<String, Object> results) {
    if (results == null) {
      return true;
    }

    final Integer returnCode = (Integer) results.get(RETURN_CODE_KEY);
    return !RESULT_OK.equals(returnCode);
  }

  private CustomerProfileDto getCustomerFromResults(final Map<String, Object> results) {
    final Object resultSet = results.get(CustomerStoredProcedureCall.RESULT_SET_KEY);
    if (resultSet instanceof List) {
      final List resultSetList = ((List) resultSet);

      if (!resultSetList.isEmpty()) {
        final Object customerProfileObj = resultSetList.get(0);

        if (customerProfileObj instanceof CustomerProfileDto) {
          return (CustomerProfileDto) customerProfileObj;
        }
      }
    }

    throw new CustomerNotFoundException(NO_CUSTOMER_PROFILE);
  }
}
