package com.lgim.group.service.graphql.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.lgim.group.service.graphql.dto.CustomerProfileDto;
import com.lgim.group.service.graphql.dto.ImmutableCustomerProfileDto;
import com.lgim.group.service.graphql.service.ManageYourAccountService;
import com.lgim.group.service.graphql.util.RestUtil;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.HttpServerErrorException;

import java.util.regex.Pattern;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource(properties = {"customer.profile.service.url=http://localhost:9090"})
@ContextConfiguration(classes = ManageYourAccountServiceImpl.class)
public class ManageYourAccountServiceImplTest {

  private static final Pattern UUID_PATTERN = Pattern.compile("[a-z0-9-]{36}");

  @Rule
  public WireMockRule wireMockRule = new WireMockRule(9090);

  @Rule
  public ExpectedException expectedException = ExpectedException.none();

  private static final String CUSTOMER_ID = "12345";
  private static final String JWT_TOKEN = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI5c0JRSTUtMDZLVldNUnJyMEg2dWdfaEhIbXA5a3VQUndQN3o4cGtUcWgwIn0.eyJqdGkiOiJmNmM3OGU2My1kZDAxLTRjY2ItODNkMy04NjhjMzUwM2U4ODkiLCJleHAiOjE1MjE4MDUyMjAsIm5iZiI6MCwiaWF0IjoxNTIxODA0OTIwLCJpc3MiOiJodHRwczovL3NlY3VyZS1zc28tYWpiLXJodC1zc28uYXBwcy5uYTEub3BlbnNoaWZ0Lm9wZW50bGMuY29tL2F1dGgvcmVhbG1zL3JodF9ncHRlXzNzY2FsZV9yZWFsbSIsImF1ZCI6ImN1cmxDbGllbnQiLCJzdWIiOiIzNmZiZTBiNi04OTI3LTQ4YzItOTc0NS1jZmY5MmFkODgwYTUiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJjdXJsQ2xpZW50IiwiYXV0aF90aW1lIjowLCJzZXNzaW9uX3N0YXRlIjoiOTI0YzgyNmMtZTJlZi00NDZhLTgyMzctZDY1NTczNDcyOTQ3IiwiYWNyIjoiMSIsImNsaWVudF9zZXNzaW9uIjoiM2Y2MDExNTMtMmY2YS00YjAzLWEzNTQtMTI4ODFjN2UwYzFmIiwiYWxsb3dlZC1vcmlnaW5zIjpbXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbInVtYV9hdXRob3JpemF0aW9uIiwic3dhcm1Sb2xlIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsInZpZXctcHJvZmlsZSJdfX0sIm5hbWUiOiIiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJzd2FybV9kZXYifQ.JkSg7CmTDreA-gEyS88LWcQbiEYRMZS869DiwcCHGxX9DM4AcSKFSbJa1gLhJYygaCNPZm69ySds35eDNyBJHnc5lfFA9rdvDAVFUz4ypxA0ZmpKJiFqsNYmoGSMlVhaCHZcUhbdcRBg6fMsAmkJJ_cQ0wrK1bBiUD03IGsuZW6ojG_RE99V5t3lI1x3T8ITAl7uFmbFYwtPvosZJoYhWazWwPQz0CxgyVLeLi-lNI0U79ZPfIg06h1KfXuIgM2nClOaO9zY1LY1u7H5bbOBbxdF-nTfyclQ5QIC4-dPKk2AZmQ7Djc6FUisPaRffyX1LxlzkrPYP4liVdTn2YEQVQ";

  private CustomerProfileDto customerProfileDto;

  @Autowired
  private ManageYourAccountService underTest;

  @Value("${customer.profile.service.url}")
  private String customerProfileServiceUrl;

  @After
  public void tearDown() {
    wireMockRule.shutdown();
  }

  @Before
  public void setUp() {
    customerProfileDto = ImmutableCustomerProfileDto.builder()
        .withTitle("Mr")
        .withForename("Forename")
        .withSurname("Surname")
        .withGender("M")
        .withDateOfBirth("1980-01-01")
        .build();
  }

  @Test
  public void shouldReturnCustomerProfile() throws JsonProcessingException {
    stubFor(get(urlPathEqualTo(filterUrl()))
        .withHeader(RestUtil.JWT_TOKEN_REST_HEADER_NAME, equalTo(JWT_TOKEN))
        .withHeader(RestUtil.JOURNEY_ID_REST_HEADER_NAME, matching(UUID_PATTERN.pattern()))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(new ObjectMapper().writeValueAsString(customerProfileDto))));

    final CustomerProfileDto result = underTest.getCustomerProfile(CUSTOMER_ID, JWT_TOKEN);

    assertEquals(customerProfileDto, result);
  }

  @Test
  public void shouldThrowExceptionWhenErrorOccurs() {
    expectedException.expect(HttpServerErrorException.class);

    stubFor(get(urlPathEqualTo(filterUrl()))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")
            .withBody("")));

    final CustomerProfileDto result = underTest.getCustomerProfile(CUSTOMER_ID, JWT_TOKEN);
    assertNull(result);
  }

  private String filterUrl() {
    return "/customers/" + CUSTOMER_ID;
  }
}