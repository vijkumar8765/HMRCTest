package com.lgim.group.service.graphql.audit;

import com.lgim.group.ws.utility.plugin.model.GroupDigitalMessage;
import graphql.execution.instrumentation.InstrumentationState;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Map;

public class AuditInstrumentationState implements InstrumentationState {

  @Getter
  @Setter
  private String graphqlMethod;

  @Getter
  @Setter
  private String journeyId;

}
