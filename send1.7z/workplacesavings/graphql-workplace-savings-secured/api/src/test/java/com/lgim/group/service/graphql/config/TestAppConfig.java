package com.lgim.group.service.graphql.config;

import com.lgim.group.service.graphql.mutation.MutationResolver;
import com.lgim.group.service.graphql.query.QueryResolver;
import com.lgim.group.service.graphql.service.WorkplaceSavingsService;
import com.lgim.group.service.graphql.service.impl.WorkplaceSavingsServiceImpl;
import com.lgim.group.service.graphql.util.JourneyIdExtractor;
import com.lgim.group.service.graphql.util.JourneyIdExtractorImpl;
import com.lgim.group.service.graphql.util.JwtTokenExtractor;
import com.lgim.group.service.graphql.util.JwtTokenExtractorImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;

@Configuration
public class TestAppConfig {

  @Bean
  public QueryResolver queryResolver() {
    return new QueryResolver();
  }

  @Bean
  public MutationResolver mutationResolver() {
    return new MutationResolver();
  }

  @Bean
  public WorkplaceSavingsService workplaceSavingsService() {
    return new WorkplaceSavingsServiceImpl();
  }

  @Bean
  public JwtTokenExtractor jwtTokenExtractorImpl() {
    return new JwtTokenExtractorImpl();
  }

  @Bean
  public JourneyIdExtractor journeyIdExtractorImpl() {return  new JourneyIdExtractorImpl();}
}
