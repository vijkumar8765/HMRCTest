
package lbf_person_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGRequestEnvelope;
import lbb_personcommon_1_0.DGUpdMarketingConsentDtls;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_UpdCntMarktgConsntDtlsReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_UpdCntMarktgConsntDtlsReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_RequestEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="partyId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="marketingConsentDtls" type="{http://LBB_PersonCommon_1_0}DG_UpdMarketingConsentDtls" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="contactDetails" type="{http://LBF_Person_1_0}DG_ContactDtls" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_UpdCntMarktgConsntDtlsReq", propOrder = {
    "partyId",
    "marketingConsentDtls",
    "contactDetails"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGUpdCntMarktgConsntDtlsReq
    extends DGRequestEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String partyId;
    protected List<DGUpdMarketingConsentDtls> marketingConsentDtls;
    protected DGContactDtls contactDetails;

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the marketingConsentDtls property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the marketingConsentDtls property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMarketingConsentDtls().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGUpdMarketingConsentDtls }
     * 
     * 
     */
    public List<DGUpdMarketingConsentDtls> getMarketingConsentDtls() {
        if (marketingConsentDtls == null) {
            marketingConsentDtls = new ArrayList<DGUpdMarketingConsentDtls>();
        }
        return this.marketingConsentDtls;
    }

    /**
     * Gets the value of the contactDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGContactDtls }
     *     
     */
    public DGContactDtls getContactDetails() {
        return contactDetails;
    }

    /**
     * Sets the value of the contactDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGContactDtls }
     *     
     */
    public void setContactDetails(DGContactDtls value) {
        this.contactDetails = value;
    }

}
