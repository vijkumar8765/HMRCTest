package com.lgim.group.service.graphql.service;

import com.lgim.group.service.graphql.dto.CustomerProfileDto;

public interface ManageYourAccountService {

  CustomerProfileDto getCustomerProfile(String customerID, String jwtToken);
}
