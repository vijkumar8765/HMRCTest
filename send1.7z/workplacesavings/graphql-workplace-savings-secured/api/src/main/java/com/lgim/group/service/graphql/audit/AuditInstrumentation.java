package com.lgim.group.service.graphql.audit;

import com.lgim.group.service.graphql.elasticsearch.ElasticSearchUtility;
import com.lgim.group.ws.utility.plugin.model.GroupDigitalMessage;
import graphql.ExecutionResult;
import graphql.execution.instrumentation.InstrumentationContext;
import graphql.execution.instrumentation.InstrumentationState;
import graphql.execution.instrumentation.SimpleInstrumentation;
import graphql.execution.instrumentation.SimpleInstrumentationContext;
import graphql.execution.instrumentation.parameters.InstrumentationExecutionParameters;
import graphql.execution.instrumentation.parameters.InstrumentationFieldFetchParameters;
import graphql.schema.DataFetcher;
import graphql.servlet.GraphQLContext;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RestHighLevelClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static com.lgim.group.service.graphql.elasticsearch.ElasticSearchUtility.getElasticSearchBaseMap;
import static com.lgim.group.service.graphql.elasticsearch.ElasticSearchUtility.getIndexId;
import static com.lgim.group.service.graphql.elasticsearch.ElasticSearchUtility.getIndexName;

@Slf4j
public class AuditInstrumentation extends SimpleInstrumentation {

  private static final String BUSINESS_FUNCTION = "Workplacesavings";
  private static final String MICROSERVICE_NAME = "graphql-workplace-saving-secured";

  private static Logger LOG = LoggerFactory.getLogger(AuditInstrumentation.class);

  private String jwtToken = "jwtToken";

  RestHighLevelClient esClient;

  public AuditInstrumentation(RestHighLevelClient esClient) {
    this.esClient = esClient;
  }

  @Override
  public InstrumentationState createState() {
    return new AuditInstrumentationState();
  }

  @Override
  public InstrumentationContext<ExecutionResult> beginExecution(InstrumentationExecutionParameters parameters) {
    
    GroupDigitalMessage gdMessageRequest = new GroupDigitalMessage();
    Map<String, String> requestPayload = gdMessageRequest.getPayloads();
    Map<String, String> requestTags = gdMessageRequest.getTags();

    ((GraphQLContext) parameters.getContext()).getRequest().ifPresent(request -> {

      final Object journeyId = generateUuid();
      jwtToken = request.getHeader("Authorization");

      log.info("Jwt Token: " + jwtToken);
      log.info("Journey Id: " + journeyId);
      log.info("Service url: ", request.getRequestURI());

      requestTags.put("service_url", request.getRequestURI());
      requestTags.put("is_framework_generated", "true");
      requestTags.put("is_request", "true");

      parameters.getVariables().forEach((variableName, variableValue) -> {
        requestTags.put("gql_var_" + variableName, variableValue.toString());
      });

      gdMessageRequest.setJourneyId(journeyId.toString());
      gdMessageRequest.setPayloads(requestPayload);
      gdMessageRequest.setBusinessFunction(BUSINESS_FUNCTION);
      gdMessageRequest.setMicroserviceName(MICROSERVICE_NAME);

      requestPayload.put("request_payload", parameters.getQuery());

      AuditInstrumentationState state = parameters.getInstrumentationState();

      request.setAttribute("journeyId", journeyId);
      state.setJourneyId(journeyId.toString());

    });

    long startNanos = System.nanoTime();

    return new SimpleInstrumentationContext<ExecutionResult>() {
      @Override
      public void onCompleted(ExecutionResult result, Throwable throwable) {

        AuditInstrumentationState state = parameters.getInstrumentationState();

        // Request
        requestTags.put("graphql_method", state.getGraphqlMethod());
        log.info("Request: " + gdMessageRequest.toString());

        try {
          Map<String, String> esData = getElasticSearchBaseMap(gdMessageRequest, true);

          IndexRequest request = new IndexRequest(getIndexName(gdMessageRequest), "generic", getIndexId());
          request.source(esData);
          esClient.index(request);
        } catch (Exception exception) {
          log.info("exception when request sending to kibana", exception.getMessage());

        }

        // Response
        GroupDigitalMessage gdMessageResponse = new GroupDigitalMessage();

        String responseTime = Long.toString(TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startNanos));

        log.info("Duration is in milli seconds: " + responseTime);
        log.info("response is :" + result.toString());

        Map<String, String> responseTags = gdMessageResponse.getTags();
        responseTags.put("is_response", "true");
        responseTags.put("service_request_response_duration_integer", responseTime);
        responseTags.put("is_framework_generated", "true");
        responseTags.put("graphql_method", state.getGraphqlMethod());

        Map<String, String> responsePayload = gdMessageResponse.getPayloads();
        responsePayload.put("response_payload", result.toString());

        if (!result.getErrors().isEmpty()) {
          responseTags.put("is_exception", "true");
          responsePayload.put("exception_message", result.toString());
        }

        gdMessageResponse.setJourneyId(state.getJourneyId());
        gdMessageResponse.setBusinessFunction(BUSINESS_FUNCTION);
        gdMessageResponse.setMicroserviceName(MICROSERVICE_NAME);

        // send however to Kibana
        log.info("Response: " + gdMessageResponse.toString());

        try {
          Map<String, String> esData = getElasticSearchBaseMap(gdMessageResponse, true);
          
          IndexRequest request = new IndexRequest(getIndexName(gdMessageResponse), "generic", getIndexId());
          request.source(esData);
          esClient.index(request);
          
        } catch (Exception exception) {
          log.info("exception when response sending to kibana", exception.getMessage());

        }

      }
    };
  }

  @Override
  public DataFetcher<?> instrumentDataFetcher(DataFetcher<?> dataFetcher, InstrumentationFieldFetchParameters parameters) {

    AuditInstrumentationState state = parameters.getInstrumentationState();
    state.setGraphqlMethod(parameters.getExecutionContext().getOperationDefinition().getName());

    return dataFetcher;
  }

  private String generateUuid() {
    return UUID.randomUUID().toString();
  }


}

