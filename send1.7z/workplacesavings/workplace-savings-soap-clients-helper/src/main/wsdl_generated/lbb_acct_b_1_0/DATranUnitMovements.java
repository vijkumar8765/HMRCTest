
package lbb_acct_b_1_0;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_TranUnitMovements complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_TranUnitMovements"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="transSeqNo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="tranTypeId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="actionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="nprTransInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="tranEffectiveDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="amountIn" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="amountOut" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="amountInOutUnit" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="fundId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fundLongName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="numUnitBought" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="numUnitSold" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="unitPrice" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_TranUnitMovements", propOrder = {
    "transSeqNo",
    "tranTypeId",
    "actionName",
    "nprTransInd",
    "tranEffectiveDate",
    "amountIn",
    "amountOut",
    "amountInOutUnit",
    "fundId",
    "fundLongName",
    "numUnitBought",
    "numUnitSold",
    "unitPrice"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DATranUnitMovements
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected Integer transSeqNo;
    protected String tranTypeId;
    protected String actionName;
    protected String nprTransInd;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar tranEffectiveDate;
    protected BigDecimal amountIn;
    protected BigDecimal amountOut;
    protected BigDecimal amountInOutUnit;
    protected String fundId;
    protected String fundLongName;
    protected BigDecimal numUnitBought;
    protected BigDecimal numUnitSold;
    protected BigDecimal unitPrice;

    /**
     * Gets the value of the transSeqNo property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTransSeqNo() {
        return transSeqNo;
    }

    /**
     * Sets the value of the transSeqNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTransSeqNo(Integer value) {
        this.transSeqNo = value;
    }

    /**
     * Gets the value of the tranTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranTypeId() {
        return tranTypeId;
    }

    /**
     * Sets the value of the tranTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranTypeId(String value) {
        this.tranTypeId = value;
    }

    /**
     * Gets the value of the actionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionName() {
        return actionName;
    }

    /**
     * Sets the value of the actionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionName(String value) {
        this.actionName = value;
    }

    /**
     * Gets the value of the nprTransInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNprTransInd() {
        return nprTransInd;
    }

    /**
     * Sets the value of the nprTransInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNprTransInd(String value) {
        this.nprTransInd = value;
    }

    /**
     * Gets the value of the tranEffectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTranEffectiveDate() {
        return tranEffectiveDate;
    }

    /**
     * Sets the value of the tranEffectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTranEffectiveDate(XMLGregorianCalendar value) {
        this.tranEffectiveDate = value;
    }

    /**
     * Gets the value of the amountIn property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmountIn() {
        return amountIn;
    }

    /**
     * Sets the value of the amountIn property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmountIn(BigDecimal value) {
        this.amountIn = value;
    }

    /**
     * Gets the value of the amountOut property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmountOut() {
        return amountOut;
    }

    /**
     * Sets the value of the amountOut property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmountOut(BigDecimal value) {
        this.amountOut = value;
    }

    /**
     * Gets the value of the amountInOutUnit property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmountInOutUnit() {
        return amountInOutUnit;
    }

    /**
     * Sets the value of the amountInOutUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmountInOutUnit(BigDecimal value) {
        this.amountInOutUnit = value;
    }

    /**
     * Gets the value of the fundId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundId() {
        return fundId;
    }

    /**
     * Sets the value of the fundId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundId(String value) {
        this.fundId = value;
    }

    /**
     * Gets the value of the fundLongName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundLongName() {
        return fundLongName;
    }

    /**
     * Sets the value of the fundLongName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundLongName(String value) {
        this.fundLongName = value;
    }

    /**
     * Gets the value of the numUnitBought property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNumUnitBought() {
        return numUnitBought;
    }

    /**
     * Sets the value of the numUnitBought property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNumUnitBought(BigDecimal value) {
        this.numUnitBought = value;
    }

    /**
     * Gets the value of the numUnitSold property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNumUnitSold() {
        return numUnitSold;
    }

    /**
     * Sets the value of the numUnitSold property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNumUnitSold(BigDecimal value) {
        this.numUnitSold = value;
    }

    /**
     * Gets the value of the unitPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    /**
     * Sets the value of the unitPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setUnitPrice(BigDecimal value) {
        this.unitPrice = value;
    }

}
