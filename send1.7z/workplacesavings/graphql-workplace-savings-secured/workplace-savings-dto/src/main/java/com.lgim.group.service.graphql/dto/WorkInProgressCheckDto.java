package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
public class WorkInProgressCheckDto implements java.io.Serializable {
  private Boolean wipSet;
  private Boolean wipExpiryDateIsIndefinite;
  private Date wipExpiryDate;

  public WorkInProgressCheckDto(Boolean wipSet, Boolean wipExpiryDateIsIndefinite, Date wipExpiryDate) {
    this.wipSet = wipSet;
    this.wipExpiryDateIsIndefinite = wipExpiryDateIsIndefinite;
    this.wipExpiryDate = wipExpiryDate;
  }
}
