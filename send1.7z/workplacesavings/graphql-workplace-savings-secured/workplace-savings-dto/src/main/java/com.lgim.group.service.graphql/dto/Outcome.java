package com.lgim.group.service.graphql.dto;

public enum Outcome {
  SUCCESS, FAILURE
}
