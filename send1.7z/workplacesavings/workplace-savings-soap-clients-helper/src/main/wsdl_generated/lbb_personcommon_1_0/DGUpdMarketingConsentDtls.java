
package lbb_personcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_UpdMarketingConsentDtls complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_UpdMarketingConsentDtls"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="commReasonType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="commChannelType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="eventTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="consentInd" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="sourceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="notificationChannelType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="createdBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_UpdMarketingConsentDtls", propOrder = {
    "commReasonType",
    "commChannelType",
    "eventTimeStamp",
    "consentInd",
    "sourceId",
    "notificationChannelType",
    "createdBy"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGUpdMarketingConsentDtls
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String commReasonType;
    protected String commChannelType;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar eventTimeStamp;
    protected Boolean consentInd;
    protected String sourceId;
    protected String notificationChannelType;
    protected String createdBy;

    /**
     * Gets the value of the commReasonType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommReasonType() {
        return commReasonType;
    }

    /**
     * Sets the value of the commReasonType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommReasonType(String value) {
        this.commReasonType = value;
    }

    /**
     * Gets the value of the commChannelType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommChannelType() {
        return commChannelType;
    }

    /**
     * Sets the value of the commChannelType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommChannelType(String value) {
        this.commChannelType = value;
    }

    /**
     * Gets the value of the eventTimeStamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEventTimeStamp() {
        return eventTimeStamp;
    }

    /**
     * Sets the value of the eventTimeStamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEventTimeStamp(XMLGregorianCalendar value) {
        this.eventTimeStamp = value;
    }

    /**
     * Gets the value of the consentInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isConsentInd() {
        return consentInd;
    }

    /**
     * Sets the value of the consentInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setConsentInd(Boolean value) {
        this.consentInd = value;
    }

    /**
     * Gets the value of the sourceId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceId() {
        return sourceId;
    }

    /**
     * Sets the value of the sourceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceId(String value) {
        this.sourceId = value;
    }

    /**
     * Gets the value of the notificationChannelType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNotificationChannelType() {
        return notificationChannelType;
    }

    /**
     * Sets the value of the notificationChannelType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNotificationChannelType(String value) {
        this.notificationChannelType = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

}
