
package lb_envelope_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import lbf_inv_1_0.DGConstructInvInstrResponse;
import lbf_inv_1_0.DGDtrmnTxEffctvDateResponse;
import lbf_inv_1_0.DGInsertInvInstrResponse;
import lbf_inv_1_0.DGRetrInvBeneDetsResponse;
import lbf_inv_1_0.DGValidateInvInstrResponse;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_ResponseEnvelope complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_ResponseEnvelope"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="inputStatus" type="{http://LB_Envelope_1_0}DG_InputStatus" minOccurs="0"/&gt;
 *         &lt;element name="technicalFailures" type="{http://LB_Envelope_1_0}DG_FailureList" minOccurs="0"/&gt;
 *         &lt;element name="businessFailures" type="{http://LB_Envelope_1_0}DG_FailureList" minOccurs="0"/&gt;
 *         &lt;element name="success" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_ResponseEnvelope", propOrder = {
    "inputStatus",
    "technicalFailures",
    "businessFailures",
    "success"
})
@XmlSeeAlso({
    DGValidateInvInstrResponse.class,
    DGInsertInvInstrResponse.class,
    DGRetrInvBeneDetsResponse.class,
    DGConstructInvInstrResponse.class,
    DGDtrmnTxEffctvDateResponse.class
})
@ToString
@EqualsAndHashCode
public class DGResponseEnvelope implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGInputStatus inputStatus;
    protected DGFailureList technicalFailures;
    protected DGFailureList businessFailures;
    protected Boolean success;

    /**
     * Gets the value of the inputStatus property.
     * 
     * @return
     *     possible object is
     *     {@link DGInputStatus }
     *     
     */
    public DGInputStatus getInputStatus() {
        return inputStatus;
    }

    /**
     * Sets the value of the inputStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGInputStatus }
     *     
     */
    public void setInputStatus(DGInputStatus value) {
        this.inputStatus = value;
    }

    /**
     * Gets the value of the technicalFailures property.
     * 
     * @return
     *     possible object is
     *     {@link DGFailureList }
     *     
     */
    public DGFailureList getTechnicalFailures() {
        return technicalFailures;
    }

    /**
     * Sets the value of the technicalFailures property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGFailureList }
     *     
     */
    public void setTechnicalFailures(DGFailureList value) {
        this.technicalFailures = value;
    }

    /**
     * Gets the value of the businessFailures property.
     * 
     * @return
     *     possible object is
     *     {@link DGFailureList }
     *     
     */
    public DGFailureList getBusinessFailures() {
        return businessFailures;
    }

    /**
     * Sets the value of the businessFailures property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGFailureList }
     *     
     */
    public void setBusinessFailures(DGFailureList value) {
        this.businessFailures = value;
    }

    /**
     * Gets the value of the success property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSuccess() {
        return success;
    }

    /**
     * Sets the value of the success property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSuccess(Boolean value) {
        this.success = value;
    }

}
