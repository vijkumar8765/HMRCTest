package com.lgim.group.gatekeeper.exception;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JwtAuthenticationException extends Exception {

  public JwtAuthenticationException(String message) {
    super(message);
    log.error(message);
  }

  public JwtAuthenticationException(String message, Throwable cause) {

    super(message, cause);
    log.error(message,cause);

  }
}
