
package lbb_acct_b_1_0;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the lbb_acct_b_1_0 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: lbb_acct_b_1_0
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DAInvestedHoldings }
     * 
     */
    public DAInvestedHoldings createDAInvestedHoldings() {
        return new DAInvestedHoldings();
    }

    /**
     * Create an instance of {@link DAInvestedHoldingGrp }
     * 
     */
    public DAInvestedHoldingGrp createDAInvestedHoldingGrp() {
        return new DAInvestedHoldingGrp();
    }

    /**
     * Create an instance of {@link DARetrSubAcctValtns }
     * 
     */
    public DARetrSubAcctValtns createDARetrSubAcctValtns() {
        return new DARetrSubAcctValtns();
    }

    /**
     * Create an instance of {@link DAUnInsuredAcctValtn }
     * 
     */
    public DAUnInsuredAcctValtn createDAUnInsuredAcctValtn() {
        return new DAUnInsuredAcctValtn();
    }

    /**
     * Create an instance of {@link DARetrAcctTransHistSrchCrit }
     * 
     */
    public DARetrAcctTransHistSrchCrit createDARetrAcctTransHistSrchCrit() {
        return new DARetrAcctTransHistSrchCrit();
    }

    /**
     * Create an instance of {@link DARetrAcctTransHistRequest }
     * 
     */
    public DARetrAcctTransHistRequest createDARetrAcctTransHistRequest() {
        return new DARetrAcctTransHistRequest();
    }

    /**
     * Create an instance of {@link DARetrAcctTransHistValReq }
     * 
     */
    public DARetrAcctTransHistValReq createDARetrAcctTransHistValReq() {
        return new DARetrAcctTransHistValReq();
    }

    /**
     * Create an instance of {@link DARetrFullAcctDtls }
     * 
     */
    public DARetrFullAcctDtls createDARetrFullAcctDtls() {
        return new DARetrFullAcctDtls();
    }

    /**
     * Create an instance of {@link DAAccountDirectDebit }
     * 
     */
    public DAAccountDirectDebit createDAAccountDirectDebit() {
        return new DAAccountDirectDebit();
    }

    /**
     * Create an instance of {@link DAAccountBillingSchedule }
     * 
     */
    public DAAccountBillingSchedule createDAAccountBillingSchedule() {
        return new DAAccountBillingSchedule();
    }

    /**
     * Create an instance of {@link DARetrAcctContrSmryValResp }
     * 
     */
    public DARetrAcctContrSmryValResp createDARetrAcctContrSmryValResp() {
        return new DARetrAcctContrSmryValResp();
    }

    /**
     * Create an instance of {@link DAAccountBankAcctDtls }
     * 
     */
    public DAAccountBankAcctDtls createDAAccountBankAcctDtls() {
        return new DAAccountBankAcctDtls();
    }

    /**
     * Create an instance of {@link DAAccountChequeDtls }
     * 
     */
    public DAAccountChequeDtls createDAAccountChequeDtls() {
        return new DAAccountChequeDtls();
    }

    /**
     * Create an instance of {@link DAAccountReceiptPosting }
     * 
     */
    public DAAccountReceiptPosting createDAAccountReceiptPosting() {
        return new DAAccountReceiptPosting();
    }

    /**
     * Create an instance of {@link DAAccountReceipt }
     * 
     */
    public DAAccountReceipt createDAAccountReceipt() {
        return new DAAccountReceipt();
    }

    /**
     * Create an instance of {@link DAAccountSelectedFund }
     * 
     */
    public DAAccountSelectedFund createDAAccountSelectedFund() {
        return new DAAccountSelectedFund();
    }

    /**
     * Create an instance of {@link DAInsuredAcctValtns }
     * 
     */
    public DAInsuredAcctValtns createDAInsuredAcctValtns() {
        return new DAInsuredAcctValtns();
    }

    /**
     * Create an instance of {@link DAAccountCommissionRcvrDtls }
     * 
     */
    public DAAccountCommissionRcvrDtls createDAAccountCommissionRcvrDtls() {
        return new DAAccountCommissionRcvrDtls();
    }

    /**
     * Create an instance of {@link DAAccountDeal }
     * 
     */
    public DAAccountDeal createDAAccountDeal() {
        return new DAAccountDeal();
    }

    /**
     * Create an instance of {@link DAAccountCommission }
     * 
     */
    public DAAccountCommission createDAAccountCommission() {
        return new DAAccountCommission();
    }

    /**
     * Create an instance of {@link DASmryOfContrForPeriod }
     * 
     */
    public DASmryOfContrForPeriod createDASmryOfContrForPeriod() {
        return new DASmryOfContrForPeriod();
    }

    /**
     * Create an instance of {@link DASmryOfLastRegContr }
     * 
     */
    public DASmryOfLastRegContr createDASmryOfLastRegContr() {
        return new DASmryOfLastRegContr();
    }

    /**
     * Create an instance of {@link DAAcctContrSmry }
     * 
     */
    public DAAcctContrSmry createDAAcctContrSmry() {
        return new DAAcctContrSmry();
    }

    /**
     * Create an instance of {@link DAPolicyTransaction }
     * 
     */
    public DAPolicyTransaction createDAPolicyTransaction() {
        return new DAPolicyTransaction();
    }

    /**
     * Create an instance of {@link DARetrAcctValtnList }
     * 
     */
    public DARetrAcctValtnList createDARetrAcctValtnList() {
        return new DARetrAcctValtnList();
    }

    /**
     * Create an instance of {@link DAAccountRetirementAge }
     * 
     */
    public DAAccountRetirementAge createDAAccountRetirementAge() {
        return new DAAccountRetirementAge();
    }

    /**
     * Create an instance of {@link DAAccountRole }
     * 
     */
    public DAAccountRole createDAAccountRole() {
        return new DAAccountRole();
    }

    /**
     * Create an instance of {@link DARetrAcctContrSmryResp }
     * 
     */
    public DARetrAcctContrSmryResp createDARetrAcctContrSmryResp() {
        return new DARetrAcctContrSmryResp();
    }

    /**
     * Create an instance of {@link DARetrSubAcctValtnSrchCrit }
     * 
     */
    public DARetrSubAcctValtnSrchCrit createDARetrSubAcctValtnSrchCrit() {
        return new DARetrSubAcctValtnSrchCrit();
    }

    /**
     * Create an instance of {@link DAAccountCommissionReceiver }
     * 
     */
    public DAAccountCommissionReceiver createDAAccountCommissionReceiver() {
        return new DAAccountCommissionReceiver();
    }

    /**
     * Create an instance of {@link DARetrAcctValtnSrchCrit }
     * 
     */
    public DARetrAcctValtnSrchCrit createDARetrAcctValtnSrchCrit() {
        return new DARetrAcctValtnSrchCrit();
    }

    /**
     * Create an instance of {@link DARetrAcctPortfolioValtnReq }
     * 
     */
    public DARetrAcctPortfolioValtnReq createDARetrAcctPortfolioValtnReq() {
        return new DARetrAcctPortfolioValtnReq();
    }

    /**
     * Create an instance of {@link DAAccountTransferDetail }
     * 
     */
    public DAAccountTransferDetail createDAAccountTransferDetail() {
        return new DAAccountTransferDetail();
    }

    /**
     * Create an instance of {@link DAAccountIndexation }
     * 
     */
    public DAAccountIndexation createDAAccountIndexation() {
        return new DAAccountIndexation();
    }

    /**
     * Create an instance of {@link DAAccountAltControl }
     * 
     */
    public DAAccountAltControl createDAAccountAltControl() {
        return new DAAccountAltControl();
    }

    /**
     * Create an instance of {@link DARetrAcctContrSmrySrchCrt }
     * 
     */
    public DARetrAcctContrSmrySrchCrt createDARetrAcctContrSmrySrchCrt() {
        return new DARetrAcctContrSmrySrchCrt();
    }

    /**
     * Create an instance of {@link DAAccountFundProvider }
     * 
     */
    public DAAccountFundProvider createDAAccountFundProvider() {
        return new DAAccountFundProvider();
    }

    /**
     * Create an instance of {@link DAAccountProduct }
     * 
     */
    public DAAccountProduct createDAAccountProduct() {
        return new DAAccountProduct();
    }

    /**
     * Create an instance of {@link DAAccountFund }
     * 
     */
    public DAAccountFund createDAAccountFund() {
        return new DAAccountFund();
    }

    /**
     * Create an instance of {@link DAAccountInvestmentStrategy }
     * 
     */
    public DAAccountInvestmentStrategy createDAAccountInvestmentStrategy() {
        return new DAAccountInvestmentStrategy();
    }

    /**
     * Create an instance of {@link DAAccountBillingGroup }
     * 
     */
    public DAAccountBillingGroup createDAAccountBillingGroup() {
        return new DAAccountBillingGroup();
    }

    /**
     * Create an instance of {@link DAAccountCollectionMethod }
     * 
     */
    public DAAccountCollectionMethod createDAAccountCollectionMethod() {
        return new DAAccountCollectionMethod();
    }

    /**
     * Create an instance of {@link DAAccountContribution }
     * 
     */
    public DAAccountContribution createDAAccountContribution() {
        return new DAAccountContribution();
    }

    /**
     * Create an instance of {@link DAAccountLifestyleFund }
     * 
     */
    public DAAccountLifestyleFund createDAAccountLifestyleFund() {
        return new DAAccountLifestyleFund();
    }

    /**
     * Create an instance of {@link DAAccountBenefit }
     * 
     */
    public DAAccountBenefit createDAAccountBenefit() {
        return new DAAccountBenefit();
    }

    /**
     * Create an instance of {@link DAAccountMembershipDtls }
     * 
     */
    public DAAccountMembershipDtls createDAAccountMembershipDtls() {
        return new DAAccountMembershipDtls();
    }

    /**
     * Create an instance of {@link DAAccountGroup }
     * 
     */
    public DAAccountGroup createDAAccountGroup() {
        return new DAAccountGroup();
    }

    /**
     * Create an instance of {@link DAAccountPolicyDetail }
     * 
     */
    public DAAccountPolicyDetail createDAAccountPolicyDetail() {
        return new DAAccountPolicyDetail();
    }

    /**
     * Create an instance of {@link DAFullAccountDetails }
     * 
     */
    public DAFullAccountDetails createDAFullAccountDetails() {
        return new DAFullAccountDetails();
    }

    /**
     * Create an instance of {@link DARetrAcctTransHistResponse }
     * 
     */
    public DARetrAcctTransHistResponse createDARetrAcctTransHistResponse() {
        return new DARetrAcctTransHistResponse();
    }

    /**
     * Create an instance of {@link DARetrAcctTransHistValResp }
     * 
     */
    public DARetrAcctTransHistValResp createDARetrAcctTransHistValResp() {
        return new DARetrAcctTransHistValResp();
    }

    /**
     * Create an instance of {@link DARetrFullAcctDtlsResponse }
     * 
     */
    public DARetrFullAcctDtlsResponse createDARetrFullAcctDtlsResponse() {
        return new DARetrFullAcctDtlsResponse();
    }

    /**
     * Create an instance of {@link DARetrFullAcctDtlValResponse }
     * 
     */
    public DARetrFullAcctDtlValResponse createDARetrFullAcctDtlValResponse() {
        return new DARetrFullAcctDtlValResponse();
    }

    /**
     * Create an instance of {@link DARetrFullAcctDtlsRequest }
     * 
     */
    public DARetrFullAcctDtlsRequest createDARetrFullAcctDtlsRequest() {
        return new DARetrFullAcctDtlsRequest();
    }

    /**
     * Create an instance of {@link DARetrFullAcctDtlValRequest }
     * 
     */
    public DARetrFullAcctDtlValRequest createDARetrFullAcctDtlValRequest() {
        return new DARetrFullAcctDtlValRequest();
    }

    /**
     * Create an instance of {@link DACommissionReceivers }
     * 
     */
    public DACommissionReceivers createDACommissionReceivers() {
        return new DACommissionReceivers();
    }

    /**
     * Create an instance of {@link DARetrAcctUnitTranHistSrchCrit }
     * 
     */
    public DARetrAcctUnitTranHistSrchCrit createDARetrAcctUnitTranHistSrchCrit() {
        return new DARetrAcctUnitTranHistSrchCrit();
    }

    /**
     * Create an instance of {@link DARetrAcctUnitTranHistReq }
     * 
     */
    public DARetrAcctUnitTranHistReq createDARetrAcctUnitTranHistReq() {
        return new DARetrAcctUnitTranHistReq();
    }

    /**
     * Create an instance of {@link DATranUnitMovements }
     * 
     */
    public DATranUnitMovements createDATranUnitMovements() {
        return new DATranUnitMovements();
    }

    /**
     * Create an instance of {@link DARetrAcctUnitTranHistResp }
     * 
     */
    public DARetrAcctUnitTranHistResp createDARetrAcctUnitTranHistResp() {
        return new DARetrAcctUnitTranHistResp();
    }

    /**
     * Create an instance of {@link DARetrAcctUnitTransHistValReq }
     * 
     */
    public DARetrAcctUnitTransHistValReq createDARetrAcctUnitTransHistValReq() {
        return new DARetrAcctUnitTransHistValReq();
    }

    /**
     * Create an instance of {@link DARetrAcctUnitTransHistValResp }
     * 
     */
    public DARetrAcctUnitTransHistValResp createDARetrAcctUnitTransHistValResp() {
        return new DARetrAcctUnitTransHistValResp();
    }

    /**
     * Create an instance of {@link DARetrAcctPortfolioValtnResp }
     * 
     */
    public DARetrAcctPortfolioValtnResp createDARetrAcctPortfolioValtnResp() {
        return new DARetrAcctPortfolioValtnResp();
    }

    /**
     * Create an instance of {@link DARetrAcctContrSmryReq }
     * 
     */
    public DARetrAcctContrSmryReq createDARetrAcctContrSmryReq() {
        return new DARetrAcctContrSmryReq();
    }

    /**
     * Create an instance of {@link DARetrAcctContrSmryValReq }
     * 
     */
    public DARetrAcctContrSmryValReq createDARetrAcctContrSmryValReq() {
        return new DARetrAcctContrSmryValReq();
    }

}
