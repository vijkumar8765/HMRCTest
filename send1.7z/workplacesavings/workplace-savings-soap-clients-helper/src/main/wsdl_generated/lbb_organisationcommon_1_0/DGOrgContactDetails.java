
package lbb_organisationcommon_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_OrgContactDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_OrgContactDetails"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="addresses" type="{http://LBB_OrganisationCommon_1_0}DG_OrganisationAddress" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="emailAddresses" type="{http://LBB_OrganisationCommon_1_0}DG_OrganisationEmailAddress" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="telephoneNumbers" type="{http://LBB_OrganisationCommon_1_0}DG_OrganisationTelephoneNumber" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_OrgContactDetails", propOrder = {
    "addresses",
    "emailAddresses",
    "telephoneNumbers"
})
@ToString
@EqualsAndHashCode
public class DGOrgContactDetails implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected List<DGOrganisationAddress> addresses;
    protected List<DGOrganisationEmailAddress> emailAddresses;
    protected List<DGOrganisationTelephoneNumber> telephoneNumbers;

    /**
     * Gets the value of the addresses property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addresses property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddresses().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGOrganisationAddress }
     * 
     * 
     */
    public List<DGOrganisationAddress> getAddresses() {
        if (addresses == null) {
            addresses = new ArrayList<DGOrganisationAddress>();
        }
        return this.addresses;
    }

    /**
     * Gets the value of the emailAddresses property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the emailAddresses property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmailAddresses().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGOrganisationEmailAddress }
     * 
     * 
     */
    public List<DGOrganisationEmailAddress> getEmailAddresses() {
        if (emailAddresses == null) {
            emailAddresses = new ArrayList<DGOrganisationEmailAddress>();
        }
        return this.emailAddresses;
    }

    /**
     * Gets the value of the telephoneNumbers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the telephoneNumbers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTelephoneNumbers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGOrganisationTelephoneNumber }
     * 
     * 
     */
    public List<DGOrganisationTelephoneNumber> getTelephoneNumbers() {
        if (telephoneNumbers == null) {
            telephoneNumbers = new ArrayList<DGOrganisationTelephoneNumber>();
        }
        return this.telephoneNumbers;
    }

}
