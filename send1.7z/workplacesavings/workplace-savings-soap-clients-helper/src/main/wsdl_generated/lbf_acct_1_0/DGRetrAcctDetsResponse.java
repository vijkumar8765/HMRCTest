
package lbf_acct_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGResponseEnvelope;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_RetrAcctDetsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_RetrAcctDetsResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_ResponseEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="account" type="{http://LBF_Acct_1_0}DG_Acct" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_RetrAcctDetsResponse", propOrder = {
    "account"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGRetrAcctDetsResponse
    extends DGResponseEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGAcct account;

    /**
     * Gets the value of the account property.
     * 
     * @return
     *     possible object is
     *     {@link DGAcct }
     *     
     */
    public DGAcct getAccount() {
        return account;
    }

    /**
     * Sets the value of the account property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGAcct }
     *     
     */
    public void setAccount(DGAcct value) {
        this.account = value;
    }

}
