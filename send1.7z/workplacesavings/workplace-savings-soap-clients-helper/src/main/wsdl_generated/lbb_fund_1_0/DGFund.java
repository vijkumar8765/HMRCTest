
package lbb_fund_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lbf_fund_1_0.DGBasicFund;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_Fund complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_Fund"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LBF_Fund_1_0}DG_BasicFund"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="cppiParentFundId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="cppiParentFundName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fundBlockIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_Fund", propOrder = {
    "cppiParentFundId",
    "cppiParentFundName",
    "fundBlockIndicator"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGFund
    extends DGBasicFund
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String cppiParentFundId;
    protected String cppiParentFundName;
    protected Boolean fundBlockIndicator;

    /**
     * Gets the value of the cppiParentFundId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCppiParentFundId() {
        return cppiParentFundId;
    }

    /**
     * Sets the value of the cppiParentFundId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCppiParentFundId(String value) {
        this.cppiParentFundId = value;
    }

    /**
     * Gets the value of the cppiParentFundName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCppiParentFundName() {
        return cppiParentFundName;
    }

    /**
     * Sets the value of the cppiParentFundName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCppiParentFundName(String value) {
        this.cppiParentFundName = value;
    }

    /**
     * Gets the value of the fundBlockIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFundBlockIndicator() {
        return fundBlockIndicator;
    }

    /**
     * Sets the value of the fundBlockIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFundBlockIndicator(Boolean value) {
        this.fundBlockIndicator = value;
    }

}
