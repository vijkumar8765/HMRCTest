package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
public class BenefitInputDto implements java.io.Serializable {
  // This is benefitId + sequence number as a string
  private String concatBenefitSequenceId;
  private List<FundInputDto> funds;

  public BenefitInputDto(String concatBenefitSequenceId, List<FundInputDto> funds) {
    this.concatBenefitSequenceId = concatBenefitSequenceId;
    this.funds = funds;
  }
}
