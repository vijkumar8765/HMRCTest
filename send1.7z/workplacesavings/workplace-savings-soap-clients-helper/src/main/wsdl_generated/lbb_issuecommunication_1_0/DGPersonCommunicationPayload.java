
package lbb_issuecommunication_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lbb_personcommon_1_0.DGPerson;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_PersonCommunicationPayload complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_PersonCommunicationPayload"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LBB_IssueCommunication_1_0}DG_CommunicationPayload"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="data" type="{http://LBB_PersonCommon_1_0}DG_Person" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_PersonCommunicationPayload", propOrder = {
    "data"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGPersonCommunicationPayload
    extends DGCommunicationPayload
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGPerson data;

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link DGPerson }
     *     
     */
    public DGPerson getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPerson }
     *     
     */
    public void setData(DGPerson value) {
        this.data = value;
    }

}
