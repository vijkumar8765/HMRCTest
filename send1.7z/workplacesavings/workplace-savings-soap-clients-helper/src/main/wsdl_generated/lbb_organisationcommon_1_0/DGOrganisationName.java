
package lbb_organisationcommon_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_OrganisationName complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_OrganisationName"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="registeredName" type="{http://LBB_OrganisationCommon_1_0}DG_OrganisationNameDetails" minOccurs="0"/&gt;
 *         &lt;element name="tradingName" type="{http://LBB_OrganisationCommon_1_0}DG_OrganisationNameDetails" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_OrganisationName", propOrder = {
    "registeredName",
    "tradingName"
})
@ToString
@EqualsAndHashCode
public class DGOrganisationName implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGOrganisationNameDetails registeredName;
    protected List<DGOrganisationNameDetails> tradingName;

    /**
     * Gets the value of the registeredName property.
     * 
     * @return
     *     possible object is
     *     {@link DGOrganisationNameDetails }
     *     
     */
    public DGOrganisationNameDetails getRegisteredName() {
        return registeredName;
    }

    /**
     * Sets the value of the registeredName property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGOrganisationNameDetails }
     *     
     */
    public void setRegisteredName(DGOrganisationNameDetails value) {
        this.registeredName = value;
    }

    /**
     * Gets the value of the tradingName property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tradingName property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTradingName().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGOrganisationNameDetails }
     * 
     * 
     */
    public List<DGOrganisationNameDetails> getTradingName() {
        if (tradingName == null) {
            tradingName = new ArrayList<DGOrganisationNameDetails>();
        }
        return this.tradingName;
    }

}
