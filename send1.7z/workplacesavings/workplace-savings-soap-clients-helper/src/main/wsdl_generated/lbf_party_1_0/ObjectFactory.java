
package lbf_party_1_0;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the lbf_party_1_0 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: lbf_party_1_0
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DGRetrOpenInvstgtnsCriteria }
     * 
     */
    public DGRetrOpenInvstgtnsCriteria createDGRetrOpenInvstgtnsCriteria() {
        return new DGRetrOpenInvstgtnsCriteria();
    }

    /**
     * Create an instance of {@link DGInvestigation }
     * 
     */
    public DGInvestigation createDGInvestigation() {
        return new DGInvestigation();
    }

    /**
     * Create an instance of {@link DGRetrInterPartyRelsSearchCriteria }
     * 
     */
    public DGRetrInterPartyRelsSearchCriteria createDGRetrInterPartyRelsSearchCriteria() {
        return new DGRetrInterPartyRelsSearchCriteria();
    }

    /**
     * Create an instance of {@link DGPartyDetails }
     * 
     */
    public DGPartyDetails createDGPartyDetails() {
        return new DGPartyDetails();
    }

    /**
     * Create an instance of {@link DGPartyRetrDetails }
     * 
     */
    public DGPartyRetrDetails createDGPartyRetrDetails() {
        return new DGPartyRetrDetails();
    }

    /**
     * Create an instance of {@link DGPartyRetrResponse }
     * 
     */
    public DGPartyRetrResponse createDGPartyRetrResponse() {
        return new DGPartyRetrResponse();
    }

    /**
     * Create an instance of {@link DGRetrRelsForAuthCheckSearchCriteria }
     * 
     */
    public DGRetrRelsForAuthCheckSearchCriteria createDGRetrRelsForAuthCheckSearchCriteria() {
        return new DGRetrRelsForAuthCheckSearchCriteria();
    }

    /**
     * Create an instance of {@link DGRetrRelsForAuthCheckRequest }
     * 
     */
    public DGRetrRelsForAuthCheckRequest createDGRetrRelsForAuthCheckRequest() {
        return new DGRetrRelsForAuthCheckRequest();
    }

    /**
     * Create an instance of {@link DGPartyRetrSearchCriteria }
     * 
     */
    public DGPartyRetrSearchCriteria createDGPartyRetrSearchCriteria() {
        return new DGPartyRetrSearchCriteria();
    }

    /**
     * Create an instance of {@link DGPartyRetrRequest }
     * 
     */
    public DGPartyRetrRequest createDGPartyRetrRequest() {
        return new DGPartyRetrRequest();
    }

    /**
     * Create an instance of {@link DGInterPartyRelationships }
     * 
     */
    public DGInterPartyRelationships createDGInterPartyRelationships() {
        return new DGInterPartyRelationships();
    }

    /**
     * Create an instance of {@link DGPartyDetailsPerson }
     * 
     */
    public DGPartyDetailsPerson createDGPartyDetailsPerson() {
        return new DGPartyDetailsPerson();
    }

    /**
     * Create an instance of {@link DGRetrInterPartyRelsResponse }
     * 
     */
    public DGRetrInterPartyRelsResponse createDGRetrInterPartyRelsResponse() {
        return new DGRetrInterPartyRelsResponse();
    }

    /**
     * Create an instance of {@link DGIndirectRelationships }
     * 
     */
    public DGIndirectRelationships createDGIndirectRelationships() {
        return new DGIndirectRelationships();
    }

    /**
     * Create an instance of {@link DGRetrRelsForAuthCheckResponse }
     * 
     */
    public DGRetrRelsForAuthCheckResponse createDGRetrRelsForAuthCheckResponse() {
        return new DGRetrRelsForAuthCheckResponse();
    }

    /**
     * Create an instance of {@link DGPartyDetailsOrganisation }
     * 
     */
    public DGPartyDetailsOrganisation createDGPartyDetailsOrganisation() {
        return new DGPartyDetailsOrganisation();
    }

    /**
     * Create an instance of {@link DGRetrOpenInvstgtnsResult }
     * 
     */
    public DGRetrOpenInvstgtnsResult createDGRetrOpenInvstgtnsResult() {
        return new DGRetrOpenInvstgtnsResult();
    }

    /**
     * Create an instance of {@link DGRetrOpenInvstgtnsRequest }
     * 
     */
    public DGRetrOpenInvstgtnsRequest createDGRetrOpenInvstgtnsRequest() {
        return new DGRetrOpenInvstgtnsRequest();
    }

    /**
     * Create an instance of {@link DGRetrInterPartyRelsRequest }
     * 
     */
    public DGRetrInterPartyRelsRequest createDGRetrInterPartyRelsRequest() {
        return new DGRetrInterPartyRelsRequest();
    }

    /**
     * Create an instance of {@link DGRetrOpenInvstgtnsResponse }
     * 
     */
    public DGRetrOpenInvstgtnsResponse createDGRetrOpenInvstgtnsResponse() {
        return new DGRetrOpenInvstgtnsResponse();
    }

}
