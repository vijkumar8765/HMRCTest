package com.lgim.group.smart.frontend;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class AssetTest {

  @Test
  public void isaApplyAssetIndexExist() {
    ClassLoader classLoader = this.getClass().getClassLoader();
    assertNotNull("Missing <static/investments/isas/apply/assets/static/isa-apply/index.html> file in resources", classLoader.getResource("static/investments/isas/apply/assets/static/isa-apply/index.html"));
  }

  @Test
  public void isaApplyAssetStaticCssExist() {
    ClassLoader classLoader = this.getClass().getClassLoader();
    assertNotNull("Missing <static/investments/isas/apply/assets/static/isa-apply/static/css> directory in resources", classLoader.getResource("static/investments/isas/apply/assets/static/isa-apply/static/css"));
  }

  @Test
  public void isaApplyAssetStaticJsExist() {
    ClassLoader classLoader = this.getClass().getClassLoader();
    assertNotNull("Missing <static/investments/isas/apply/assets/static/isa-apply/static/js> directory in resources", classLoader.getResource("static/investments/isas/apply/assets/static/isa-apply/static/js"));
  }

  @Test
  public void isaApplyAssetStaticMediaExist() {
    ClassLoader classLoader = this.getClass().getClassLoader();
    assertNotNull("Missing <static/investments/isas/apply/assets/static/isa-apply/static/media> directory in resources", classLoader.getResource("static/investments/isas/apply/assets/static/isa-apply/static/media"));
  }

}
