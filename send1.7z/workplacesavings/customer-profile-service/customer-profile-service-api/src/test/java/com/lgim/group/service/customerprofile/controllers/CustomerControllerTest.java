package com.lgim.group.service.customerprofile.controllers;

import com.lgim.group.gatekeeper.exception.JwtAuthenticationException;
import com.lgim.group.service.customerprofile.audit.AuditHelper;
import com.lgim.group.service.customerprofile.audit.AuditLogsService;
import com.lgim.group.service.customerprofile.authorization.AuthorizationHelper;
import com.lgim.group.service.customerprofile.dto.CustomerProfileDto;
import com.lgim.group.service.customerprofile.services.CustomerProfileService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CustomerControllerTest {

  @Mock
  private CustomerProfileService mockCustomerProfileService;

  @Mock
  private AuthorizationHelper mockAuthorizationHelper;

  @Mock
  private AuditHelper mockAuditHelper;

  @InjectMocks
  private CustomerController underTest;

  private static final String PARTY_ID = "party id";
  private static final String AUTHORIZATION_HEADER = "authorization header";

  @Test
  public void getCustomerProfile() throws JwtAuthenticationException {
    final CustomerProfileDto mockCustomerProfileDto = mock(CustomerProfileDto.class);
    when(mockCustomerProfileService.getCustomerByPartyId(PARTY_ID)).thenReturn(mockCustomerProfileDto);
    when(mockAuthorizationHelper.authorizeRequest(AUTHORIZATION_HEADER)).thenReturn(PARTY_ID);

    final ResponseEntity<CustomerProfileDto> expected = ResponseEntity.ok(mockCustomerProfileDto);
    final ResponseEntity<CustomerProfileDto> actual = underTest.getCustomerProfile(AUTHORIZATION_HEADER);

    assertEquals("Unexpected http status in response", actual.getStatusCode(), expected.getStatusCode());
    assertEquals("Unexpected customer profile dto in response entity", actual.getBody(), expected.getBody());
  }

  @Test(expected = JwtAuthenticationException.class)
  public void getCustomerProfileNotAuthorized() throws JwtAuthenticationException {
    doThrow(JwtAuthenticationException.class).when(mockAuthorizationHelper).authorizeRequest(AUTHORIZATION_HEADER);
    underTest.getCustomerProfile(AUTHORIZATION_HEADER);
  }
}