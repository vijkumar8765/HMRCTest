
package lbb_acct_b_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGResponseEnvelope;
import lbb_common_1_0.DGPagingControl;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_RetrAcctUnitTranHistResp complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_RetrAcctUnitTranHistResp"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_ResponseEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="tranUnitMovements" type="{http://LBB_Acct_B_1_0}DA_TranUnitMovements" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="pageControls" type="{http://LBB_Common_1_0}DG_PagingControl" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_RetrAcctUnitTranHistResp", propOrder = {
    "tranUnitMovements",
    "pageControls"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DARetrAcctUnitTranHistResp
    extends DGResponseEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected List<DATranUnitMovements> tranUnitMovements;
    protected DGPagingControl pageControls;

    /**
     * Gets the value of the tranUnitMovements property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tranUnitMovements property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTranUnitMovements().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DATranUnitMovements }
     * 
     * 
     */
    public List<DATranUnitMovements> getTranUnitMovements() {
        if (tranUnitMovements == null) {
            tranUnitMovements = new ArrayList<DATranUnitMovements>();
        }
        return this.tranUnitMovements;
    }

    /**
     * Gets the value of the pageControls property.
     * 
     * @return
     *     possible object is
     *     {@link DGPagingControl }
     *     
     */
    public DGPagingControl getPageControls() {
        return pageControls;
    }

    /**
     * Sets the value of the pageControls property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPagingControl }
     *     
     */
    public void setPageControls(DGPagingControl value) {
        this.pageControls = value;
    }

}
