
package lbb_acct_b_1_0;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_AccountReceipt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_AccountReceipt"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="receiptId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="receiptDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="receiptCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="processTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="grossNetIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="receiptAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="receiptComment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="receiptPostings" type="{http://LBB_Acct_B_1_0}DA_AccountReceiptPosting" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="chequeDetail" type="{http://LBB_Acct_B_1_0}DA_AccountChequeDtls" minOccurs="0"/&gt;
 *         &lt;element name="externalReceiptRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="externalBatchRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="receiptReservedReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="backDateReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="bankingAcronym" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_AccountReceipt", propOrder = {
    "receiptId",
    "receiptDate",
    "receiptCode",
    "processTypeCode",
    "grossNetIndicator",
    "currencyCode",
    "receiptAmount",
    "receiptComment",
    "receiptPostings",
    "chequeDetail",
    "externalReceiptRef",
    "externalBatchRef",
    "receiptReservedReasonCode",
    "backDateReason",
    "bankingAcronym"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAAccountReceipt
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String receiptId;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar receiptDate;
    protected String receiptCode;
    protected String processTypeCode;
    protected String grossNetIndicator;
    protected String currencyCode;
    protected BigDecimal receiptAmount;
    protected String receiptComment;
    protected List<DAAccountReceiptPosting> receiptPostings;
    protected DAAccountChequeDtls chequeDetail;
    protected String externalReceiptRef;
    protected String externalBatchRef;
    protected String receiptReservedReasonCode;
    protected String backDateReason;
    protected String bankingAcronym;

    /**
     * Gets the value of the receiptId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptId() {
        return receiptId;
    }

    /**
     * Sets the value of the receiptId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptId(String value) {
        this.receiptId = value;
    }

    /**
     * Gets the value of the receiptDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiptDate() {
        return receiptDate;
    }

    /**
     * Sets the value of the receiptDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReceiptDate(XMLGregorianCalendar value) {
        this.receiptDate = value;
    }

    /**
     * Gets the value of the receiptCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptCode() {
        return receiptCode;
    }

    /**
     * Sets the value of the receiptCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptCode(String value) {
        this.receiptCode = value;
    }

    /**
     * Gets the value of the processTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessTypeCode() {
        return processTypeCode;
    }

    /**
     * Sets the value of the processTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessTypeCode(String value) {
        this.processTypeCode = value;
    }

    /**
     * Gets the value of the grossNetIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGrossNetIndicator() {
        return grossNetIndicator;
    }

    /**
     * Sets the value of the grossNetIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGrossNetIndicator(String value) {
        this.grossNetIndicator = value;
    }

    /**
     * Gets the value of the currencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Sets the value of the currencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCode(String value) {
        this.currencyCode = value;
    }

    /**
     * Gets the value of the receiptAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getReceiptAmount() {
        return receiptAmount;
    }

    /**
     * Sets the value of the receiptAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setReceiptAmount(BigDecimal value) {
        this.receiptAmount = value;
    }

    /**
     * Gets the value of the receiptComment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptComment() {
        return receiptComment;
    }

    /**
     * Sets the value of the receiptComment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptComment(String value) {
        this.receiptComment = value;
    }

    /**
     * Gets the value of the receiptPostings property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the receiptPostings property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReceiptPostings().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DAAccountReceiptPosting }
     * 
     * 
     */
    public List<DAAccountReceiptPosting> getReceiptPostings() {
        if (receiptPostings == null) {
            receiptPostings = new ArrayList<DAAccountReceiptPosting>();
        }
        return this.receiptPostings;
    }

    /**
     * Gets the value of the chequeDetail property.
     * 
     * @return
     *     possible object is
     *     {@link DAAccountChequeDtls }
     *     
     */
    public DAAccountChequeDtls getChequeDetail() {
        return chequeDetail;
    }

    /**
     * Sets the value of the chequeDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link DAAccountChequeDtls }
     *     
     */
    public void setChequeDetail(DAAccountChequeDtls value) {
        this.chequeDetail = value;
    }

    /**
     * Gets the value of the externalReceiptRef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalReceiptRef() {
        return externalReceiptRef;
    }

    /**
     * Sets the value of the externalReceiptRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalReceiptRef(String value) {
        this.externalReceiptRef = value;
    }

    /**
     * Gets the value of the externalBatchRef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalBatchRef() {
        return externalBatchRef;
    }

    /**
     * Sets the value of the externalBatchRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalBatchRef(String value) {
        this.externalBatchRef = value;
    }

    /**
     * Gets the value of the receiptReservedReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptReservedReasonCode() {
        return receiptReservedReasonCode;
    }

    /**
     * Sets the value of the receiptReservedReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptReservedReasonCode(String value) {
        this.receiptReservedReasonCode = value;
    }

    /**
     * Gets the value of the backDateReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBackDateReason() {
        return backDateReason;
    }

    /**
     * Sets the value of the backDateReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBackDateReason(String value) {
        this.backDateReason = value;
    }

    /**
     * Gets the value of the bankingAcronym property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankingAcronym() {
        return bankingAcronym;
    }

    /**
     * Sets the value of the bankingAcronym property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankingAcronym(String value) {
        this.bankingAcronym = value;
    }

}
