package com.lgim.group.service.graphql.util;

import graphql.schema.DataFetchingEnvironment;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = GraphiqlConfigJourney.class)
@TestPropertySource(properties = {"graphiql.journey.id=Journey Id"})
public class GraphiqlJourneyIdExtractorImplTest {

  @Autowired
  GraphiqlJourneyIdExtractorImpl journeyIdExtractor;

  @Mock
  DataFetchingEnvironment environment;

  @Test
  public void testJourneyIdIsExtracted() {
    assertEquals("Journey Id", journeyIdExtractor.extractJourneyId(environment));
  }

}

@Configuration
class GraphiqlConfigJourney {
  @Bean
  public GraphiqlJourneyIdExtractorImpl journeyIdExtractor() {
    return new GraphiqlJourneyIdExtractorImpl();
  }

}
