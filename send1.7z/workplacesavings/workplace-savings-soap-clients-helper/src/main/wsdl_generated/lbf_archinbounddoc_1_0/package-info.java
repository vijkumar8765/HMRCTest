@javax.xml.bind.annotation.XmlSchema(namespace = "http://LBF_ArchInboundDoc_1_0")
package lbf_archinbounddoc_1_0;
