
package lbb_organisationcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lbb_communicationcommon_1_0.DGPostalAddress;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_OrganisationalUnit complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_OrganisationalUnit"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="orgUnitId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="orgUnitName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="address" type="{http://LBB_CommunicationCommon_1_0}DG_PostalAddress" minOccurs="0"/&gt;
 *         &lt;element name="telephoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="faxNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="emailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="weekdayOpeningTimes" type="{http://LBB_OrganisationCommon_1_0}DG_OpeningTimes" minOccurs="0"/&gt;
 *         &lt;element name="saturdayOpeningTimes" type="{http://LBB_OrganisationCommon_1_0}DG_OpeningTimes" minOccurs="0"/&gt;
 *         &lt;element name="referenceRoot" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_OrganisationalUnit", propOrder = {
    "orgUnitId",
    "orgUnitName",
    "address",
    "telephoneNumber",
    "faxNumber",
    "emailAddress",
    "weekdayOpeningTimes",
    "saturdayOpeningTimes",
    "referenceRoot"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGOrganisationalUnit
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String orgUnitId;
    protected String orgUnitName;
    protected DGPostalAddress address;
    protected String telephoneNumber;
    protected String faxNumber;
    protected String emailAddress;
    protected DGOpeningTimes weekdayOpeningTimes;
    protected DGOpeningTimes saturdayOpeningTimes;
    protected String referenceRoot;

    /**
     * Gets the value of the orgUnitId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgUnitId() {
        return orgUnitId;
    }

    /**
     * Sets the value of the orgUnitId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgUnitId(String value) {
        this.orgUnitId = value;
    }

    /**
     * Gets the value of the orgUnitName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgUnitName() {
        return orgUnitName;
    }

    /**
     * Sets the value of the orgUnitName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgUnitName(String value) {
        this.orgUnitName = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link DGPostalAddress }
     *     
     */
    public DGPostalAddress getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPostalAddress }
     *     
     */
    public void setAddress(DGPostalAddress value) {
        this.address = value;
    }

    /**
     * Gets the value of the telephoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    /**
     * Sets the value of the telephoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelephoneNumber(String value) {
        this.telephoneNumber = value;
    }

    /**
     * Gets the value of the faxNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaxNumber() {
        return faxNumber;
    }

    /**
     * Sets the value of the faxNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaxNumber(String value) {
        this.faxNumber = value;
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddress(String value) {
        this.emailAddress = value;
    }

    /**
     * Gets the value of the weekdayOpeningTimes property.
     * 
     * @return
     *     possible object is
     *     {@link DGOpeningTimes }
     *     
     */
    public DGOpeningTimes getWeekdayOpeningTimes() {
        return weekdayOpeningTimes;
    }

    /**
     * Sets the value of the weekdayOpeningTimes property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGOpeningTimes }
     *     
     */
    public void setWeekdayOpeningTimes(DGOpeningTimes value) {
        this.weekdayOpeningTimes = value;
    }

    /**
     * Gets the value of the saturdayOpeningTimes property.
     * 
     * @return
     *     possible object is
     *     {@link DGOpeningTimes }
     *     
     */
    public DGOpeningTimes getSaturdayOpeningTimes() {
        return saturdayOpeningTimes;
    }

    /**
     * Sets the value of the saturdayOpeningTimes property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGOpeningTimes }
     *     
     */
    public void setSaturdayOpeningTimes(DGOpeningTimes value) {
        this.saturdayOpeningTimes = value;
    }

    /**
     * Gets the value of the referenceRoot property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceRoot() {
        return referenceRoot;
    }

    /**
     * Sets the value of the referenceRoot property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceRoot(String value) {
        this.referenceRoot = value;
    }

}
