package com.lgim.group.ws.s448mock.service;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.common.ClasspathFileSource;
import com.github.tomakehurst.wiremock.common.FileSource;

public class Application {

  private static final String POLICY_SUCESS = "2691150031";
  private static final String FILE_FOR_TEST_01 = "resp_test01_success.json";
  private static final String POLICY_ERROR = "2508733030";
  private static final String FILE_FOR_ERROR = "resp_error.json";

  // patterns
  private static final String GROUP_ID_PRE_PATTERN = "\\s*\\{\\s*\"policyNumber\"\\s*:\\s*\"";
  private static final String GROUP_ID_POST_PATTERN = "\"\\s*\\}\\s*";

  // configure wiremock
  private static String URL = "/FlexSvngsPlatformRestfulService/services/RETRIEVE/account/1.0/funds";
  private static Integer PORT = 8081;
  private static Integer STATUS_500 = 500;

  public static void main(String[] args) {

    // Start the wire mock server
    WireMockServer wireMockServer = new WireMockServer(options().port(PORT).fileSource(new ClasspathFileSourceWithoutLeadingSlash()));
    wireMockServer.start();

    // Configure the stub
    configureFor(PORT);
    //System.out.println(GROUP_ID_PRE_PATTERN + GROUP_ID_TEST_01 + GROUP_ID_POST_PATTERN);
    /**
     * Default Stub Returns 500 if no request matches
     */
    stubFor(post(urlEqualTo(URL))
        .willReturn(aResponse()
            .withHeader("Content-Type", "text/plain")
            .withStatus(STATUS_500)
            .withBody("No Match found")));

    /**
     * Case #01 (Success Test)
     * Group Id: Test01GId
     *
     * All allowed
     */
    stubFor(post(urlEqualTo(URL))
        .withRequestBody(containing(POLICY_SUCESS))
        .willReturn(aResponse()
            .withHeader("Cache-Control", "no-cache, no-store, must-revalidate")
            .withHeader("Pragma", "no-cache")
            // TODO: check how the date header needs to be set
            //            .withHeader("Date", "Expires", 0)
            .withHeader("Content-Type", "application/json")
            .withBodyFile(FILE_FOR_TEST_01)));



    /**
     * Case Failed #02 (Failure Test)
     * Group Id: GenExceptionGId
     *
     * Generic Exception
     */
    stubFor(post(urlEqualTo(URL))
            .withRequestBody(containing(POLICY_ERROR))
            .willReturn(aResponse()
                    .withHeader("Cache-Control", "no-cache, no-store, must-revalidate")
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile( FILE_FOR_ERROR )));


    System.out.println("Server started on " + PORT + "..");
  }

  /**
   * Inner class to override the output directory
   */
  static class ClasspathFileSourceWithoutLeadingSlash extends ClasspathFileSource {

    ClasspathFileSourceWithoutLeadingSlash() {
      super("");
    }

    @Override
    public FileSource child(String subDirectoryName) {
      return new ClasspathFileSource(subDirectoryName);
    }
  }
}
