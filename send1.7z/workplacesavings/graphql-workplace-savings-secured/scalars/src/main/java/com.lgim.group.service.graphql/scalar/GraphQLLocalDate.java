package com.lgim.group.service.graphql.scalar;

import com.lgim.group.service.graphql.util.DateTimeHelper;
import graphql.language.StringValue;
import graphql.schema.Coercing;
import graphql.schema.CoercingParseValueException;
import graphql.schema.CoercingSerializeException;
import graphql.schema.GraphQLScalarType;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class GraphQLLocalDate extends GraphQLScalarType {

  public GraphQLLocalDate() {
    super("LocalDate", "Local Date type", new Coercing<LocalDate, String>() {
      private LocalDate convertImpl(Object input) {
        if (input instanceof String) {
          LocalDateTime localDateTime = DateTimeHelper.parseDate((String) input);

          if (localDateTime != null) {
            return localDateTime.toLocalDate();
          }
        }
        return null;
      }

      @Override
      public String serialize(Object input) {
        if (input instanceof LocalDate) {
          return DateTimeHelper.toISOString((LocalDate) input);
        } else {
          LocalDate result = convertImpl(input);
          if (result == null) {
            throw new CoercingSerializeException("Invalid value '" + input + "' for LocalDate");
          }
          return DateTimeHelper.toISOString(result);
        }
      }

      @Override
      public LocalDate parseValue(Object input) {
        LocalDate result = convertImpl(input);
        if (result == null) {
          throw new CoercingParseValueException("Invalid value '" + input + "' for LocalDate");
        }
        return result;
      }

      @Override
      public LocalDate parseLiteral(Object input) {
        if (!(input instanceof StringValue)) {
          return null;
        }
        String value = ((StringValue) input).getValue();
        LocalDate result = convertImpl(value);
        return result;
      }
    });
  }

}
