package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class LifestyleProfleFundDto implements java.io.Serializable {
  private String name;
  private String fundCode;
  private float percentage;

  public LifestyleProfleFundDto(String name, String fundCode, float percentage) {
    this.name = name;
    this.fundCode = fundCode;
    this.percentage = percentage;
  }
}
