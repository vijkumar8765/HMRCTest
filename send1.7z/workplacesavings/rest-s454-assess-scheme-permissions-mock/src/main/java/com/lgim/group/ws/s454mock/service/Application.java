package com.lgim.group.ws.s454mock.service;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.common.ClasspathFileSource;
import com.github.tomakehurst.wiremock.common.FileSource;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

public class Application {

  private static final String GROUP_ID_TEST_01 = "GF30795000";
  private static final String FILE_FOR_TEST_01 = "resp_test01_success.json";

  private static final String GROUP_ID_ALLOW_ALL = "AllowAllGId";
  private static final String FILE_FOR_ALLOW_ALL = "resp_all_allowed.json";

  private static final String GROUP_ID_ALL_EXCEPT_SAR = "NoSarGId";
  private static final String FILE_FOR_EXCEPT_SAR = "resp_all_except_switch_and_redirect.json";

  private static final String GROUP_ID_ALL_EXCEPT_CONTRIB = "NoConGId";
  private static final String FILE_FOR_ALL_EXCEPT_CONTRIB = "resp_all_except_contrib_changes.json";

  private static final String GROUP_ID_DENY_ALL = "DenyAllGId";
  private static final String FILE_FOR_DENY_ALL = "resp_deny_all.json";

  // **** failure scenario's
  private static final String GROUP_ID_NOT_AVAILABLE = "NotAvailGId";
  private static final String FILE_FOR_NOT_AVAILABLE = "resp_not_available_failed.json";

  private static final String GROUP_ID_GENERIC_EXCEPTION = "GenExceptionGId";
  private static final String FILE_FOR_GENERIC_EXCEPTION = "resp_generic_exception.json";

  // patterns
  private static final String GROUP_ID_PRE_PATTERN = "\\s*\\{\\s*\"groupId\"\\s*:\\s*\"";
  private static final String GROUP_ID_POST_PATTERN = "\"\\s*\\}\\s*";

  // configure wiremock
  private static String URL = "/FlexSvngsPlatformRestfulService/services/RETRIEVE/group/1.0/permissions";
  private static Integer PORT = 8081;
  private static Integer STATUS_500 = 500;

  public static void main(String[] args) {

    // Start the wire mock server
    WireMockServer wireMockServer = new WireMockServer(options().port(PORT).fileSource(new ClasspathFileSourceWithoutLeadingSlash()));
    wireMockServer.start();

    // Configure the stub
    configureFor(PORT);

    /**
     * Default Stub Returns 500 if no request matches
     */
    stubFor(post(urlEqualTo(URL))
        .willReturn(aResponse()
            .withHeader("Content-Type", "text/plain")
            .withStatus(STATUS_500)
            .withBody("No Match found")));

    /**
     * Case #01 (Success Test)
     * Group Id: Test01GId
     *
     * All allowed
     */
    stubFor(post(urlEqualTo(URL))
        .withRequestBody(matching(GROUP_ID_PRE_PATTERN + GROUP_ID_TEST_01 + GROUP_ID_POST_PATTERN))
        .willReturn(aResponse()
            .withHeader("Cache-Control", "no-cache, no-store, must-revalidate")
            .withHeader("Pragma", "no-cache")
            // TODO: check how the date header needs to be set
            //            .withHeader("Date", "Expires", 0)
            .withHeader("Content-Type", "application/json")
            .withBodyFile( FILE_FOR_TEST_01 )));

    /**
     * Case #02 (Success Test)
     * Group Id: NoSarGId
     *
     * No Switch and Redirect
     */
    stubFor(post(urlEqualTo(URL))
            .withRequestBody(matching(GROUP_ID_PRE_PATTERN + GROUP_ID_ALL_EXCEPT_SAR + GROUP_ID_POST_PATTERN))
            .willReturn(aResponse()
                    .withHeader("Cache-Control", "no-cache, no-store, must-revalidate")
                    .withHeader("Pragma", "no-cache")
                    // TODO: check how the date header needs to be set
                    //            .withHeader("Date", "Expires", 0)
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile(FILE_FOR_EXCEPT_SAR)));

    /**
     * Case #03 (Success Test)
     * Group Id: NoConGId
     *
     * No Switch and Redirect
     */
    stubFor(post(urlEqualTo(URL))
            .withRequestBody(matching(GROUP_ID_PRE_PATTERN + GROUP_ID_ALL_EXCEPT_CONTRIB + GROUP_ID_POST_PATTERN))
            .willReturn(aResponse()
                    .withHeader("Cache-Control", "no-cache, no-store, must-revalidate")
                    .withHeader("Pragma", "no-cache")
                    // TODO: check how the date header needs to be set
                    //            .withHeader("Date", "Expires", 0)
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile( FILE_FOR_ALL_EXCEPT_CONTRIB )));

    /**
     * Case #04 (Success Test)
     * Group Id: DenyAllGId
     *
     * Deny All
     */
    stubFor(post(urlEqualTo(URL))
            .withRequestBody(matching(GROUP_ID_PRE_PATTERN + GROUP_ID_DENY_ALL + GROUP_ID_POST_PATTERN))
            .willReturn(aResponse()
                    .withHeader("Cache-Control", "no-cache, no-store, must-revalidate")
                    .withHeader("Pragma", "no-cache")
                    // TODO: check how the date header needs to be set
                    //            .withHeader("Date", "Expires", 0)
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile( FILE_FOR_DENY_ALL )));

    /**
     * Case #05 (Success Test)
     * Group Id: AllowAllGId
     *
     * Allow All
     */
    stubFor(post(urlEqualTo(URL))
            .withRequestBody(matching(GROUP_ID_PRE_PATTERN + GROUP_ID_ALLOW_ALL + GROUP_ID_POST_PATTERN))
            .willReturn(aResponse()
                    .withHeader("Cache-Control", "no-cache, no-store, must-revalidate")
                    .withHeader("Pragma", "no-cache")
                    // TODO: check how the date header needs to be set
                    //            .withHeader("Date", "Expires", 0)
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile( FILE_FOR_ALLOW_ALL )));


    /**
     * Case Failed #01 (Failure Test)
     * Group Id: NotAvailGId
     *
     * Permission results not available
     */
    stubFor(post(urlEqualTo(URL))
            .withRequestBody(matching(GROUP_ID_PRE_PATTERN + GROUP_ID_NOT_AVAILABLE + GROUP_ID_POST_PATTERN))
            .willReturn(aResponse()
                    .withHeader("Cache-Control", "no-cache, no-store, must-revalidate")
                    .withHeader("Pragma", "no-cache")
                    // TODO: check how the date header needs to be set
                    //            .withHeader("Date", "Expires", 0)
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile( FILE_FOR_NOT_AVAILABLE )));

    /**
     * Case Failed #02 (Failure Test)
     * Group Id: GenExceptionGId
     *
     * Generic Exception
     */
    stubFor(post(urlEqualTo(URL))
            .withRequestBody(matching(GROUP_ID_PRE_PATTERN + GROUP_ID_GENERIC_EXCEPTION + GROUP_ID_POST_PATTERN))
            .willReturn(aResponse()
                    .withHeader("Cache-Control", "no-cache, no-store, must-revalidate")
                    .withHeader("Pragma", "no-cache")
                    // TODO: check how the date header needs to be set
                    //            .withHeader("Date", "Expires", 0)
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile( FILE_FOR_GENERIC_EXCEPTION )));


    System.out.println("Server started on " + PORT + "..");
  }

  /**
   * Inner class to override the output directory
   */
  static class ClasspathFileSourceWithoutLeadingSlash extends ClasspathFileSource {

    ClasspathFileSourceWithoutLeadingSlash() {
      super("");
    }

    @Override
    public FileSource child(String subDirectoryName) {
      return new ClasspathFileSource(subDirectoryName);
    }
  }
}
