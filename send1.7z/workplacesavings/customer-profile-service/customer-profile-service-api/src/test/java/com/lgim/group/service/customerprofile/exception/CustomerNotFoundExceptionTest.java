package com.lgim.group.service.customerprofile.exception;

import org.junit.Test;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

public class CustomerNotFoundExceptionTest {

    @Test
    public void constructor() throws Exception {
        Exception cause = mock(Exception.class);
        List<String> errors = Collections.singletonList("errors");
        CustomerNotFoundException exception = new CustomerNotFoundException("Message", errors, cause);

        assertEquals(exception.getLocalizedMessage(), "Message");
        assertEquals(exception.getErrors(), errors);
        assertEquals(exception.getCause(), cause);
    }

    @Test
    public void constructorWithNullErrors() throws Exception {
        Exception cause = mock(Exception.class);
        CustomerNotFoundException exception = new CustomerNotFoundException("Message", null, cause);

        assertEquals(exception.getLocalizedMessage(), "Message");
        assertTrue(exception.getErrors().isEmpty());
        assertEquals(exception.getCause(), cause);
    }

    @Test
    public void constructorWithNoErrors() throws Exception {
        Exception cause = mock(Exception.class);
        CustomerNotFoundException exception = new CustomerNotFoundException("Message", cause);

        assertEquals(exception.getLocalizedMessage(), "Message");
        assertTrue(exception.getErrors().isEmpty());
        assertEquals(exception.getCause(), cause);
    }

    @Test
    public void constructorWithNoErrorsNoCause() throws Exception {
        CustomerNotFoundException exception = new CustomerNotFoundException("Message");

        assertEquals(exception.getLocalizedMessage(), "Message");
        assertTrue(exception.getErrors().isEmpty());
        assertNull(exception.getCause());
    }
}