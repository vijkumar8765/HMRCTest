@javax.xml.bind.annotation.XmlSchema(namespace = "http://LBB_PersonCommon_1_0")
package lbb_personcommon_1_0;
