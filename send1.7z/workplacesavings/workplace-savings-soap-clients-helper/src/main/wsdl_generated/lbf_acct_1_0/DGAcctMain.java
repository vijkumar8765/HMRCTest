
package lbf_acct_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_AcctMain complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_AcctMain"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="mainSchemeID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="mainSchemeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_AcctMain", propOrder = {
    "mainSchemeID",
    "mainSchemeName"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGAcctMain
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String mainSchemeID;
    protected String mainSchemeName;

    /**
     * Gets the value of the mainSchemeID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMainSchemeID() {
        return mainSchemeID;
    }

    /**
     * Sets the value of the mainSchemeID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMainSchemeID(String value) {
        this.mainSchemeID = value;
    }

    /**
     * Gets the value of the mainSchemeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMainSchemeName() {
        return mainSchemeName;
    }

    /**
     * Sets the value of the mainSchemeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMainSchemeName(String value) {
        this.mainSchemeName = value;
    }

}
