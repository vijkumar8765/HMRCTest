package com.lgim.group.soap.s049mock.service;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.common.ClasspathFileSource;
import com.github.tomakehurst.wiremock.common.FileSource;

public class Application {

  private static String URL = "/MRF_Acct_1_0Web/sca/EXP_WS_RetrAcctDets";

  public static void main(String[] args) {
    System.err.println("Starting Server");
    // Start the wire mock server
    WireMockServer wireMockServer = new WireMockServer(options().port(8081).fileSource(new ClasspathFileSourceWithoutLeadingSlash()));
    wireMockServer.start();

    // Configure the stub
    configureFor(8081);

    // Default if no match
    stubFor(post(urlEqualTo(URL))
        .willReturn(aResponse()
            .withHeader("Content-Type", "text/plain")
            .withStatus(500)
            .withBody("No Match found")));

    // Test#01 - success response with 2691150031
    stubFor(post(urlEqualTo(URL))
        .withRequestBody(containing("<accountNumber>2691150031</accountNumber>"))
        .willReturn(aResponse()
            .withHeader("Content-Type", "text/plain")
            .withBodyFile("response_2691150031.xml")));

    // Test#02 - Business Failure with 2691150000
    stubFor(post(urlEqualTo(URL))
        .withRequestBody(containing("<accountNumber>2691150000</accountNumber>"))
        .willReturn(aResponse()
            .withHeader("Content-Type", "text/plain")
            .withBodyFile("bu_failure_2691150000.xml")));

    // Test#03 - Technical Failure with 000
    stubFor(post(urlEqualTo(URL))
        .withRequestBody(containing("<accountNumber>000</accountNumber>"))
        .willReturn(aResponse()
            .withHeader("Content-Type", "text/plain")
            .withBodyFile("technical_failure_000.xml")));

    System.out.println("Server started on 8081..");

  }


  static class ClasspathFileSourceWithoutLeadingSlash extends ClasspathFileSource {

    ClasspathFileSourceWithoutLeadingSlash() {
      super("");
    }

    @Override
    public FileSource child(String subDirectoryName) {
      return new ClasspathFileSource(subDirectoryName);
    }
  }

}
