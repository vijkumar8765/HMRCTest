package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class BasketFundsInputDto implements java.io.Serializable {
  private String fundCode;
  private Boolean fundTypeLifestyle;
  private String name;

  public BasketFundsInputDto(String fundCode, Boolean fundTypeLifestyle, String name) {
    this.fundCode = fundCode;
    this.fundTypeLifestyle = fundTypeLifestyle;
    this.name = name;
  }
}
