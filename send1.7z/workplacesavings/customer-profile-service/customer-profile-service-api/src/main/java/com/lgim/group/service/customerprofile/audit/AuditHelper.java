package com.lgim.group.service.customerprofile.audit;

import com.lgim.group.ws.utility.plugin.model.GroupDigitalMessage;
import com.lgim.group.ws.utility.plugin.util.AuditRouteHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.impl.DefaultCamelContext;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import java.util.UUID;

import static com.lgim.group.ws.utility.plugin.constants.ServiceUtilConstant.KEY_PARTY_ID;

@Slf4j
@Component
public class AuditHelper {

  private AuditLogsService auditLogsService;

  public AuditHelper(AuditLogsService auditLogsService) {
    this.auditLogsService = auditLogsService;
  }

  public void audit(String partyId, String businessFunction, String microserviceName, String microserviceMethod) {
    CamelContext camelContext = new DefaultCamelContext();
    ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
    AuditRouteHelper auditRouteHelper = new AuditRouteHelper();
    auditLogsService.setAuditRouteHelper(auditRouteHelper);
    auditLogsService.setCamelContext(camelContext);
    auditLogsService.setProducerTemplate(producerTemplate);

    GroupDigitalMessage gdMessage = new GroupDigitalMessage();
    gdMessage.setBusinessFunction(businessFunction);
    gdMessage.setMicroserviceName(microserviceName);
    gdMessage.setMicroserviceMethod(microserviceMethod);
    gdMessage.getTags().put(KEY_PARTY_ID, partyId);
    gdMessage.setJourneyId(getJourneyId());
    log.info("AuditHelper audit method created  group digital message");
    auditLogsService.audit(gdMessage);
  }

  public String getJourneyId() {
    return UUID.randomUUID().toString();
  }

}

