package com.lgim.group.service.customerprofile.health;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.actuate.health.Health;

import javax.sql.DataSource;

import java.sql.Connection;
import java.sql.SQLException;

@RunWith(MockitoJUnitRunner.class)
public class ServiceHealthTest {

  @Mock
  private DataSource mockDataSource;

  @InjectMocks
  private ServiceHealth underTest;

  @Test
  public void testDoHealthCheckUp() throws SQLException {
    final Connection mockConnection = Mockito.mock(Connection.class);
    final Health.Builder spyBuilder = Mockito.spy(Mockito.mock(Health.Builder.class));

    Mockito.when(mockDataSource.getConnection()).thenReturn(mockConnection);
    underTest.doHealthCheck(spyBuilder);

    Mockito.verify(spyBuilder).up();
  }

  @Test
  public void testDoHealthCheckDown() throws SQLException {
    final Health.Builder spyBuilder = Mockito.spy(Mockito.mock(Health.Builder.class));

    Mockito.when(mockDataSource.getConnection()).thenThrow(SQLException.class);
    underTest.doHealthCheck(spyBuilder);

    Mockito.verify(spyBuilder).down();
  }
}