
package lbf_acct_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_AssessAcctRespDets complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_AssessAcctRespDets"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="assessmentSuccessful" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="expectedAssessmentDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="caseCompleted" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="exceptionReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_AssessAcctRespDets", propOrder = {
    "assessmentSuccessful",
    "expectedAssessmentDate",
    "caseCompleted",
    "exceptionReasonCode"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGAssessAcctRespDets
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected Boolean assessmentSuccessful;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar expectedAssessmentDate;
    protected Boolean caseCompleted;
    protected List<String> exceptionReasonCode;

    /**
     * Gets the value of the assessmentSuccessful property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAssessmentSuccessful() {
        return assessmentSuccessful;
    }

    /**
     * Sets the value of the assessmentSuccessful property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAssessmentSuccessful(Boolean value) {
        this.assessmentSuccessful = value;
    }

    /**
     * Gets the value of the expectedAssessmentDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getExpectedAssessmentDate() {
        return expectedAssessmentDate;
    }

    /**
     * Sets the value of the expectedAssessmentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setExpectedAssessmentDate(XMLGregorianCalendar value) {
        this.expectedAssessmentDate = value;
    }

    /**
     * Gets the value of the caseCompleted property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCaseCompleted() {
        return caseCompleted;
    }

    /**
     * Sets the value of the caseCompleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCaseCompleted(Boolean value) {
        this.caseCompleted = value;
    }

    /**
     * Gets the value of the exceptionReasonCode property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the exceptionReasonCode property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExceptionReasonCode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getExceptionReasonCode() {
        if (exceptionReasonCode == null) {
            exceptionReasonCode = new ArrayList<String>();
        }
        return this.exceptionReasonCode;
    }

}
