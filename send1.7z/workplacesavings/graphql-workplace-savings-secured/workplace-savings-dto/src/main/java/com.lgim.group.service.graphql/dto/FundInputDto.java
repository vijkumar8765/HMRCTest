package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class FundInputDto implements java.io.Serializable {
  private String fundCode;
  private Float percentage;
  private Boolean fundTypeLifestyle;

  public FundInputDto(String fundCode, Float percentage, Boolean fundTypeLifestyle) {
    this.fundCode = fundCode;
    this.percentage = percentage;
    this.fundTypeLifestyle = fundTypeLifestyle;
  }
}
