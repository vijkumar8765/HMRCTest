
package lbb_acct_b_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGResponseEnvelope;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_RetrAcctContrSmryResp complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_RetrAcctContrSmryResp"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_ResponseEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="acctContributionSummary" type="{http://LBB_Acct_B_1_0}DA_AcctContrSmry" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_RetrAcctContrSmryResp", propOrder = {
    "acctContributionSummary"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DARetrAcctContrSmryResp
    extends DGResponseEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DAAcctContrSmry acctContributionSummary;

    /**
     * Gets the value of the acctContributionSummary property.
     * 
     * @return
     *     possible object is
     *     {@link DAAcctContrSmry }
     *     
     */
    public DAAcctContrSmry getAcctContributionSummary() {
        return acctContributionSummary;
    }

    /**
     * Sets the value of the acctContributionSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link DAAcctContrSmry }
     *     
     */
    public void setAcctContributionSummary(DAAcctContrSmry value) {
        this.acctContributionSummary = value;
    }

}
