
package lbb_acct_b_1_0;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_AcctContrSmry complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_AcctContrSmry"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accountId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="effectiveDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="totalNetContrAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="totalGrossContrAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="totalGrossRegContrAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="totalGrossSingContrAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="totalGrossNIRebateAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="totalGrosssISPayTrnsfrAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="totalGrosssISPayContrAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="totalGrossTrnsfrsInAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="lastRegContrSumm" type="{http://LBB_Acct_B_1_0}DA_SmryOfLastRegContr" minOccurs="0"/&gt;
 *         &lt;element name="periodContrSumm" type="{http://LBB_Acct_B_1_0}DA_SmryOfContrForPeriod" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_AcctContrSmry", propOrder = {
    "accountId",
    "effectiveDate",
    "totalNetContrAmt",
    "totalGrossContrAmt",
    "totalGrossRegContrAmt",
    "totalGrossSingContrAmt",
    "totalGrossNIRebateAmt",
    "totalGrosssISPayTrnsfrAmt",
    "totalGrosssISPayContrAmt",
    "totalGrossTrnsfrsInAmt",
    "lastRegContrSumm",
    "periodContrSumm"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAAcctContrSmry
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String accountId;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar effectiveDate;
    protected BigDecimal totalNetContrAmt;
    protected BigDecimal totalGrossContrAmt;
    protected BigDecimal totalGrossRegContrAmt;
    protected BigDecimal totalGrossSingContrAmt;
    protected BigDecimal totalGrossNIRebateAmt;
    protected BigDecimal totalGrosssISPayTrnsfrAmt;
    protected BigDecimal totalGrosssISPayContrAmt;
    protected BigDecimal totalGrossTrnsfrsInAmt;
    protected DASmryOfLastRegContr lastRegContrSumm;
    protected DASmryOfContrForPeriod periodContrSumm;

    /**
     * Gets the value of the accountId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Sets the value of the accountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountId(String value) {
        this.accountId = value;
    }

    /**
     * Gets the value of the effectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the value of the effectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEffectiveDate(XMLGregorianCalendar value) {
        this.effectiveDate = value;
    }

    /**
     * Gets the value of the totalNetContrAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalNetContrAmt() {
        return totalNetContrAmt;
    }

    /**
     * Sets the value of the totalNetContrAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalNetContrAmt(BigDecimal value) {
        this.totalNetContrAmt = value;
    }

    /**
     * Gets the value of the totalGrossContrAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalGrossContrAmt() {
        return totalGrossContrAmt;
    }

    /**
     * Sets the value of the totalGrossContrAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalGrossContrAmt(BigDecimal value) {
        this.totalGrossContrAmt = value;
    }

    /**
     * Gets the value of the totalGrossRegContrAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalGrossRegContrAmt() {
        return totalGrossRegContrAmt;
    }

    /**
     * Sets the value of the totalGrossRegContrAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalGrossRegContrAmt(BigDecimal value) {
        this.totalGrossRegContrAmt = value;
    }

    /**
     * Gets the value of the totalGrossSingContrAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalGrossSingContrAmt() {
        return totalGrossSingContrAmt;
    }

    /**
     * Sets the value of the totalGrossSingContrAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalGrossSingContrAmt(BigDecimal value) {
        this.totalGrossSingContrAmt = value;
    }

    /**
     * Gets the value of the totalGrossNIRebateAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalGrossNIRebateAmt() {
        return totalGrossNIRebateAmt;
    }

    /**
     * Sets the value of the totalGrossNIRebateAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalGrossNIRebateAmt(BigDecimal value) {
        this.totalGrossNIRebateAmt = value;
    }

    /**
     * Gets the value of the totalGrosssISPayTrnsfrAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalGrosssISPayTrnsfrAmt() {
        return totalGrosssISPayTrnsfrAmt;
    }

    /**
     * Sets the value of the totalGrosssISPayTrnsfrAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalGrosssISPayTrnsfrAmt(BigDecimal value) {
        this.totalGrosssISPayTrnsfrAmt = value;
    }

    /**
     * Gets the value of the totalGrosssISPayContrAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalGrosssISPayContrAmt() {
        return totalGrosssISPayContrAmt;
    }

    /**
     * Sets the value of the totalGrosssISPayContrAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalGrosssISPayContrAmt(BigDecimal value) {
        this.totalGrosssISPayContrAmt = value;
    }

    /**
     * Gets the value of the totalGrossTrnsfrsInAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalGrossTrnsfrsInAmt() {
        return totalGrossTrnsfrsInAmt;
    }

    /**
     * Sets the value of the totalGrossTrnsfrsInAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalGrossTrnsfrsInAmt(BigDecimal value) {
        this.totalGrossTrnsfrsInAmt = value;
    }

    /**
     * Gets the value of the lastRegContrSumm property.
     * 
     * @return
     *     possible object is
     *     {@link DASmryOfLastRegContr }
     *     
     */
    public DASmryOfLastRegContr getLastRegContrSumm() {
        return lastRegContrSumm;
    }

    /**
     * Sets the value of the lastRegContrSumm property.
     * 
     * @param value
     *     allowed object is
     *     {@link DASmryOfLastRegContr }
     *     
     */
    public void setLastRegContrSumm(DASmryOfLastRegContr value) {
        this.lastRegContrSumm = value;
    }

    /**
     * Gets the value of the periodContrSumm property.
     * 
     * @return
     *     possible object is
     *     {@link DASmryOfContrForPeriod }
     *     
     */
    public DASmryOfContrForPeriod getPeriodContrSumm() {
        return periodContrSumm;
    }

    /**
     * Sets the value of the periodContrSumm property.
     * 
     * @param value
     *     allowed object is
     *     {@link DASmryOfContrForPeriod }
     *     
     */
    public void setPeriodContrSumm(DASmryOfContrForPeriod value) {
        this.periodContrSumm = value;
    }

}
