
package lb_envelope_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_InputStatus complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_InputStatus"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="inputWasValid" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="validatedInput" type="{http://LB_Envelope_1_0}DG_RequestEnvelope" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_InputStatus", propOrder = {
    "inputWasValid",
    "validatedInput"
})
@ToString
@EqualsAndHashCode
public class DGInputStatus implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected Boolean inputWasValid;
    protected DGRequestEnvelope validatedInput;

    /**
     * Gets the value of the inputWasValid property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isInputWasValid() {
        return inputWasValid;
    }

    /**
     * Sets the value of the inputWasValid property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setInputWasValid(Boolean value) {
        this.inputWasValid = value;
    }

    /**
     * Gets the value of the validatedInput property.
     * 
     * @return
     *     possible object is
     *     {@link DGRequestEnvelope }
     *     
     */
    public DGRequestEnvelope getValidatedInput() {
        return validatedInput;
    }

    /**
     * Sets the value of the validatedInput property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGRequestEnvelope }
     *     
     */
    public void setValidatedInput(DGRequestEnvelope value) {
        this.validatedInput = value;
    }

}
