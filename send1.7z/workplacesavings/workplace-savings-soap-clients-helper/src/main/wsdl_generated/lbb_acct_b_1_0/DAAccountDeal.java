
package lbb_acct_b_1_0;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_AccountDeal complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_AccountDeal"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="sacrificeType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="enhancementType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="sacrificePercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="enhancementPercentage" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="authorisationStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_AccountDeal", propOrder = {
    "sacrificeType",
    "enhancementType",
    "sacrificePercentage",
    "enhancementPercentage",
    "authorisationStatus"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAAccountDeal
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String sacrificeType;
    protected String enhancementType;
    protected BigDecimal sacrificePercentage;
    protected BigDecimal enhancementPercentage;
    protected String authorisationStatus;

    /**
     * Gets the value of the sacrificeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSacrificeType() {
        return sacrificeType;
    }

    /**
     * Sets the value of the sacrificeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSacrificeType(String value) {
        this.sacrificeType = value;
    }

    /**
     * Gets the value of the enhancementType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnhancementType() {
        return enhancementType;
    }

    /**
     * Sets the value of the enhancementType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnhancementType(String value) {
        this.enhancementType = value;
    }

    /**
     * Gets the value of the sacrificePercentage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSacrificePercentage() {
        return sacrificePercentage;
    }

    /**
     * Sets the value of the sacrificePercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSacrificePercentage(BigDecimal value) {
        this.sacrificePercentage = value;
    }

    /**
     * Gets the value of the enhancementPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEnhancementPercentage() {
        return enhancementPercentage;
    }

    /**
     * Sets the value of the enhancementPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEnhancementPercentage(BigDecimal value) {
        this.enhancementPercentage = value;
    }

    /**
     * Gets the value of the authorisationStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthorisationStatus() {
        return authorisationStatus;
    }

    /**
     * Sets the value of the authorisationStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthorisationStatus(String value) {
        this.authorisationStatus = value;
    }

}
