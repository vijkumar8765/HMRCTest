
package lbb_acct_b_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGRequestEnvelope;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_RetrFullAcctDtlsRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_RetrFullAcctDtlsRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_RequestEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fullAcctDtlReq" type="{http://LBB_Acct_B_1_0}DA_RetrFullAcctDtls" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_RetrFullAcctDtlsRequest", propOrder = {
    "fullAcctDtlReq"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DARetrFullAcctDtlsRequest
    extends DGRequestEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DARetrFullAcctDtls fullAcctDtlReq;

    /**
     * Gets the value of the fullAcctDtlReq property.
     * 
     * @return
     *     possible object is
     *     {@link DARetrFullAcctDtls }
     *     
     */
    public DARetrFullAcctDtls getFullAcctDtlReq() {
        return fullAcctDtlReq;
    }

    /**
     * Sets the value of the fullAcctDtlReq property.
     * 
     * @param value
     *     allowed object is
     *     {@link DARetrFullAcctDtls }
     *     
     */
    public void setFullAcctDtlReq(DARetrFullAcctDtls value) {
        this.fullAcctDtlReq = value;
    }

}
