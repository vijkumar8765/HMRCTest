
package lbb_acct_b_1_0;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_SmryOfContrForPeriod complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_SmryOfContrForPeriod"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="prdStrtDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="prdEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="netContrTotalAmtforPrd" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="memberRegNetContrAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="employerRegNetContrAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="memberSingNetContrAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="employerSingNetContrAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="nIRebateNetAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="intraSchmPaymntTrnsfrNetAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="intraSchmPaymntContrNetAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="trnsfrsInNetAmt" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_SmryOfContrForPeriod", propOrder = {
    "prdStrtDate",
    "prdEndDate",
    "netContrTotalAmtforPrd",
    "memberRegNetContrAmt",
    "employerRegNetContrAmt",
    "memberSingNetContrAmt",
    "employerSingNetContrAmt",
    "niRebateNetAmt",
    "intraSchmPaymntTrnsfrNetAmt",
    "intraSchmPaymntContrNetAmt",
    "trnsfrsInNetAmt"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DASmryOfContrForPeriod
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar prdStrtDate;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar prdEndDate;
    protected BigDecimal netContrTotalAmtforPrd;
    protected BigDecimal memberRegNetContrAmt;
    protected BigDecimal employerRegNetContrAmt;
    protected BigDecimal memberSingNetContrAmt;
    protected BigDecimal employerSingNetContrAmt;
    @XmlElement(name = "nIRebateNetAmt")
    protected BigDecimal niRebateNetAmt;
    protected BigDecimal intraSchmPaymntTrnsfrNetAmt;
    protected BigDecimal intraSchmPaymntContrNetAmt;
    protected BigDecimal trnsfrsInNetAmt;

    /**
     * Gets the value of the prdStrtDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPrdStrtDate() {
        return prdStrtDate;
    }

    /**
     * Sets the value of the prdStrtDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPrdStrtDate(XMLGregorianCalendar value) {
        this.prdStrtDate = value;
    }

    /**
     * Gets the value of the prdEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPrdEndDate() {
        return prdEndDate;
    }

    /**
     * Sets the value of the prdEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPrdEndDate(XMLGregorianCalendar value) {
        this.prdEndDate = value;
    }

    /**
     * Gets the value of the netContrTotalAmtforPrd property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNetContrTotalAmtforPrd() {
        return netContrTotalAmtforPrd;
    }

    /**
     * Sets the value of the netContrTotalAmtforPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNetContrTotalAmtforPrd(BigDecimal value) {
        this.netContrTotalAmtforPrd = value;
    }

    /**
     * Gets the value of the memberRegNetContrAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMemberRegNetContrAmt() {
        return memberRegNetContrAmt;
    }

    /**
     * Sets the value of the memberRegNetContrAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMemberRegNetContrAmt(BigDecimal value) {
        this.memberRegNetContrAmt = value;
    }

    /**
     * Gets the value of the employerRegNetContrAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEmployerRegNetContrAmt() {
        return employerRegNetContrAmt;
    }

    /**
     * Sets the value of the employerRegNetContrAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEmployerRegNetContrAmt(BigDecimal value) {
        this.employerRegNetContrAmt = value;
    }

    /**
     * Gets the value of the memberSingNetContrAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMemberSingNetContrAmt() {
        return memberSingNetContrAmt;
    }

    /**
     * Sets the value of the memberSingNetContrAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMemberSingNetContrAmt(BigDecimal value) {
        this.memberSingNetContrAmt = value;
    }

    /**
     * Gets the value of the employerSingNetContrAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEmployerSingNetContrAmt() {
        return employerSingNetContrAmt;
    }

    /**
     * Sets the value of the employerSingNetContrAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEmployerSingNetContrAmt(BigDecimal value) {
        this.employerSingNetContrAmt = value;
    }

    /**
     * Gets the value of the niRebateNetAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNIRebateNetAmt() {
        return niRebateNetAmt;
    }

    /**
     * Sets the value of the niRebateNetAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNIRebateNetAmt(BigDecimal value) {
        this.niRebateNetAmt = value;
    }

    /**
     * Gets the value of the intraSchmPaymntTrnsfrNetAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getIntraSchmPaymntTrnsfrNetAmt() {
        return intraSchmPaymntTrnsfrNetAmt;
    }

    /**
     * Sets the value of the intraSchmPaymntTrnsfrNetAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setIntraSchmPaymntTrnsfrNetAmt(BigDecimal value) {
        this.intraSchmPaymntTrnsfrNetAmt = value;
    }

    /**
     * Gets the value of the intraSchmPaymntContrNetAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getIntraSchmPaymntContrNetAmt() {
        return intraSchmPaymntContrNetAmt;
    }

    /**
     * Sets the value of the intraSchmPaymntContrNetAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setIntraSchmPaymntContrNetAmt(BigDecimal value) {
        this.intraSchmPaymntContrNetAmt = value;
    }

    /**
     * Gets the value of the trnsfrsInNetAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTrnsfrsInNetAmt() {
        return trnsfrsInNetAmt;
    }

    /**
     * Sets the value of the trnsfrsInNetAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTrnsfrsInNetAmt(BigDecimal value) {
        this.trnsfrsInNetAmt = value;
    }

}
