package com.lgim.group.service.customerprofile.authorization;

import com.lgim.group.gatekeeper.exception.JwtAuthenticationException;
import com.lgim.group.gatekeeper.helpers.PublicKeyHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AuthorizationHelperTest {

  @Mock
  private PublicKeyHelper mockPublicKeyHelper;

  private AuthorizationHelper underTest;

  private static final String PARTY_ID = "party id";
  private static final String AUTHORIZATION_HEADER = "authorization header";

  @Before
  public void setup() throws JwtAuthenticationException {
    when(mockPublicKeyHelper.isPublicKeySet()).thenReturn(true);
    underTest = new AuthorizationHelper(mockPublicKeyHelper);
  }

  @Test
  public void authorizeRequest() throws JwtAuthenticationException {
    final Map<String, Object> jwtData = new HashMap<>();
    jwtData.put("partyId", PARTY_ID);

    when(mockPublicKeyHelper.validateToken(AUTHORIZATION_HEADER)).thenReturn(jwtData);
    underTest.authorizeRequest(AUTHORIZATION_HEADER);
  }

  @Test(expected = JwtAuthenticationException.class)
  public void authorizeRequestNoGatekeeperPublicKey() throws JwtAuthenticationException {
    when(mockPublicKeyHelper.isPublicKeySet()).thenReturn(false);
    underTest = new AuthorizationHelper(mockPublicKeyHelper);
  }

  @Test(expected = JwtAuthenticationException.class)
  public void authorizeRequestInvalidToken() throws JwtAuthenticationException {
    when(mockPublicKeyHelper.validateToken(AUTHORIZATION_HEADER)).thenThrow(JwtAuthenticationException.class);
    underTest.authorizeRequest(AUTHORIZATION_HEADER);
  }
}