package com.lgim.group.service.customerprofile.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.immutables.value.Value;
import org.springframework.http.HttpStatus;

import java.util.List;

@Value.Immutable
@Value.Style(init = "with*")
@JsonSerialize(as = ImmutableApiError.class)
@JsonDeserialize(as = ImmutableApiError.class)
public interface ApiError {

  HttpStatus getHttpStatus();

  String getMessage();

  List<String> getErrors();
}
