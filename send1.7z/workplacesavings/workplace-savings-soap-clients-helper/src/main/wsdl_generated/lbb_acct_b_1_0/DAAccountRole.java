
package lbb_acct_b_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_AccountRole complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_AccountRole"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="roleTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="partyId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="agentNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="roleReference" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="rino" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="thirdPartyTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="interimPartyRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="distrChannelId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_AccountRole", propOrder = {
    "roleTypeCode",
    "partyId",
    "agentNumber",
    "roleReference",
    "rino",
    "thirdPartyTypeCode",
    "interimPartyRef",
    "distrChannelId"
})
@XmlSeeAlso({
    DAAccountCommissionReceiver.class
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAAccountRole
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String roleTypeCode;
    protected String partyId;
    protected String agentNumber;
    protected String roleReference;
    protected String rino;
    protected String thirdPartyTypeCode;
    protected String interimPartyRef;
    protected String distrChannelId;

    /**
     * Gets the value of the roleTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoleTypeCode() {
        return roleTypeCode;
    }

    /**
     * Sets the value of the roleTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoleTypeCode(String value) {
        this.roleTypeCode = value;
    }

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the agentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentNumber() {
        return agentNumber;
    }

    /**
     * Sets the value of the agentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentNumber(String value) {
        this.agentNumber = value;
    }

    /**
     * Gets the value of the roleReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoleReference() {
        return roleReference;
    }

    /**
     * Sets the value of the roleReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoleReference(String value) {
        this.roleReference = value;
    }

    /**
     * Gets the value of the rino property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRino() {
        return rino;
    }

    /**
     * Sets the value of the rino property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRino(String value) {
        this.rino = value;
    }

    /**
     * Gets the value of the thirdPartyTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThirdPartyTypeCode() {
        return thirdPartyTypeCode;
    }

    /**
     * Sets the value of the thirdPartyTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThirdPartyTypeCode(String value) {
        this.thirdPartyTypeCode = value;
    }

    /**
     * Gets the value of the interimPartyRef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterimPartyRef() {
        return interimPartyRef;
    }

    /**
     * Sets the value of the interimPartyRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterimPartyRef(String value) {
        this.interimPartyRef = value;
    }

    /**
     * Gets the value of the distrChannelId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistrChannelId() {
        return distrChannelId;
    }

    /**
     * Sets the value of the distrChannelId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistrChannelId(String value) {
        this.distrChannelId = value;
    }

}
