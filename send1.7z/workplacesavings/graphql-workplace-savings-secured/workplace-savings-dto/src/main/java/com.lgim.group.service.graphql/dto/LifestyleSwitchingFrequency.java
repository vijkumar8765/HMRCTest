package com.lgim.group.service.graphql.dto;

public enum LifestyleSwitchingFrequency {
  MONTHLY,
  QUARTERLY,
  SIX_MONTHLY,
  ANNUALLY
}
