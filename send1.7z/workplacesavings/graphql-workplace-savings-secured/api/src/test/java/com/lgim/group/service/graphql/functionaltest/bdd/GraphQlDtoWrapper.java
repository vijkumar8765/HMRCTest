package com.lgim.group.service.graphql.functionaltest.bdd;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class GraphQlDtoWrapper<T extends Serializable> {
    private T data;

    @JsonCreator
    public GraphQlDtoWrapper(@JsonProperty("data") T data) {
      this.data = data;
    }

    public T getData() {
      return data;
    }
}
