package com.lgim.group.service.graphql.query;

import com.lgim.group.service.graphql.dto.CustomerProfileDto;
import com.lgim.group.service.graphql.dto.ImmutableCustomerProfileDto;
import com.lgim.group.service.graphql.dto.ManageYourAccountDetailsDto;
import com.lgim.group.service.graphql.service.ManageYourAccountService;
import com.lgim.group.service.graphql.util.JwtTokenExtractor;
import graphql.GraphQLException;
import graphql.schema.DataFetchingEnvironment;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.InputStream;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ManageYourAccountDetailsQueryResolverTest {

  @Rule
  public ExpectedException expectedException = ExpectedException.none();

  @InjectMocks
  private ManageYourAccountDetailsQueryResolver underTest = new ManageYourAccountDetailsQueryResolver();

  @Mock
  private DataFetchingEnvironment environment;

  @Mock
  private JwtTokenExtractor jwtTokenExtractor;

  @Mock
  private ManageYourAccountService manageYourAccountService;

  final private static String CUSTOMER_ID = "12345";
  final private static String JWT_TOKEN = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI5c0JRSTUtMDZLVldNUnJyMEg2dWdfaEhIbXA5a3VQUndQN3o4cGtUcWgwIn0.eyJqdGkiOiJmNmM3OGU2My1kZDAxLTRjY2ItODNkMy04NjhjMzUwM2U4ODkiLCJleHAiOjE1MjE4MDUyMjAsIm5iZiI6MCwiaWF0IjoxNTIxODA0OTIwLCJpc3MiOiJodHRwczovL3NlY3VyZS1zc28tYWpiLXJodC1zc28uYXBwcy5uYTEub3BlbnNoaWZ0Lm9wZW50bGMuY29tL2F1dGgvcmVhbG1zL3JodF9ncHRlXzNzY2FsZV9yZWFsbSIsImF1ZCI6ImN1cmxDbGllbnQiLCJzdWIiOiIzNmZiZTBiNi04OTI3LTQ4YzItOTc0NS1jZmY5MmFkODgwYTUiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJjdXJsQ2xpZW50IiwiYXV0aF90aW1lIjowLCJzZXNzaW9uX3N0YXRlIjoiOTI0YzgyNmMtZTJlZi00NDZhLTgyMzctZDY1NTczNDcyOTQ3IiwiYWNyIjoiMSIsImNsaWVudF9zZXNzaW9uIjoiM2Y2MDExNTMtMmY2YS00YjAzLWEzNTQtMTI4ODFjN2UwYzFmIiwiYWxsb3dlZC1vcmlnaW5zIjpbXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbInVtYV9hdXRob3JpemF0aW9uIiwic3dhcm1Sb2xlIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsInZpZXctcHJvZmlsZSJdfX0sIm5hbWUiOiIiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJzd2FybV9kZXYifQ.JkSg7CmTDreA-gEyS88LWcQbiEYRMZS869DiwcCHGxX9DM4AcSKFSbJa1gLhJYygaCNPZm69ySds35eDNyBJHnc5lfFA9rdvDAVFUz4ypxA0ZmpKJiFqsNYmoGSMlVhaCHZcUhbdcRBg6fMsAmkJJ_cQ0wrK1bBiUD03IGsuZW6ojG_RE99V5t3lI1x3T8ITAl7uFmbFYwtPvosZJoYhWazWwPQz0CxgyVLeLi-lNI0U79ZPfIg06h1KfXuIgM2nClOaO9zY1LY1u7H5bbOBbxdF-nTfyclQ5QIC4-dPKk2AZmQ7Djc6FUisPaRffyX1LxlzkrPYP4liVdTn2YEQVQ";

  private ManageYourAccountDetailsDto manageYourAccountDetailsDto;
  private CustomerProfileDto customerProfileDto;

  @Before
  public void setUp() {
    customerProfileDto = ImmutableCustomerProfileDto.builder()
        .withTitle("Mr")
        .withForename("Forename")
        .withSurname("Surname")
        .withGender("M")
        .withDateOfBirth("1980-01-01")
        .build();

    manageYourAccountDetailsDto = ManageYourAccountDetailsDto.builder()
        .customerProfile(customerProfileDto)
        .build();
  }

  @Test
  public void testInvalidVersionFile() {
    final InputStream mockInputStream = mock(InputStream.class);
    final ManageYourAccountDetailsQueryResolver spyUnderTest = spy(underTest);
    when(spyUnderTest.getVersionFileInputStream()).thenReturn(mockInputStream);

    expectedException.expect(RuntimeException.class);
    spyUnderTest.setMyaSchemaVersion();
  }

  @Test
  public void testGetHoldingsReturnsValue() {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(JWT_TOKEN);
    when(manageYourAccountService.getCustomerProfile(CUSTOMER_ID, JWT_TOKEN)).thenReturn(customerProfileDto);

    ManageYourAccountDetailsDto result = underTest.manageYourAccountDetails(CUSTOMER_ID, environment);
    Assert.assertEquals(manageYourAccountDetailsDto, result);
  }

  @Test
  public void shouldThrowGraphqlExceptionWhenGetHoldingsThrowsException() {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(JWT_TOKEN);
    when(manageYourAccountService.getCustomerProfile(CUSTOMER_ID, JWT_TOKEN)).thenThrow(new RuntimeException("Refused to connect!"));

    expectedException.expect(GraphQLException.class);

    ManageYourAccountDetailsDto result = underTest.manageYourAccountDetails(CUSTOMER_ID, environment);
    Assert.assertNull(result);
  }

  @Test
  public void testMyaVersion() {
    String version = underTest.myaVersion();
    Assert.assertEquals("Unexpected MYA version", "0.1.0", version);
  }
}