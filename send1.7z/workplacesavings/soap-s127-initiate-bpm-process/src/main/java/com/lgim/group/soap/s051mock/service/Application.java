package com.lgim.group.soap.s051mock.service;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.common.ClasspathFileSource;
import com.github.tomakehurst.wiremock.common.FileSource;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

public class Application {

  private static final String SUCCESS_RESPONSE = "success.xml";
  private static String URL = "/MRF_WorkMgmt_1_0Web/sca/EXP_WS_CreateExtranetReq";

  private static final int PORT = 8081;

  public static void main(String[] args) {

    System.out.println( "Starting Server" );
    // Start the wire mock server
    WireMockServer wireMockServer = new WireMockServer(options().port(PORT).fileSource(new ClasspathFileSourceWithoutLeadingSlash()));
    wireMockServer.start();

    // Configure the stub
    configureFor(PORT);

    System.out.println( "Server started on " + PORT + ".." );

    stubFor(post(urlPathMatching(URL))
        .willReturn(aResponse()
            .withHeader("Content-Type", "text/plain")
            .withBodyFile(SUCCESS_RESPONSE)));
  }

  static class ClasspathFileSourceWithoutLeadingSlash extends ClasspathFileSource {
    ClasspathFileSourceWithoutLeadingSlash() {
      super("");
    }

    @Override
    public FileSource child(String subDirectoryName) {
      return new ClasspathFileSource(subDirectoryName);
    }
  }

}
