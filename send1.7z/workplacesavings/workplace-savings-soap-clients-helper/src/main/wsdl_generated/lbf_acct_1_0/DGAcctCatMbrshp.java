
package lbf_acct_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_AcctCatMbrshp complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_AcctCatMbrshp"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="membershipEffectiveDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_AcctCatMbrshp", propOrder = {
    "membershipEffectiveDate"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGAcctCatMbrshp
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar membershipEffectiveDate;

    /**
     * Gets the value of the membershipEffectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getMembershipEffectiveDate() {
        return membershipEffectiveDate;
    }

    /**
     * Sets the value of the membershipEffectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMembershipEffectiveDate(XMLGregorianCalendar value) {
        this.membershipEffectiveDate = value;
    }

}
