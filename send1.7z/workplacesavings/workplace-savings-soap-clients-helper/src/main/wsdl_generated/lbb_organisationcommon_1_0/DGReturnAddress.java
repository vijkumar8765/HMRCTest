
package lbb_organisationcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_ReturnAddress complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_ReturnAddress"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="organisationalUnit" type="{http://LBB_OrganisationCommon_1_0}DG_OrganisationalUnit" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_ReturnAddress", propOrder = {
    "accountNumber",
    "organisationalUnit"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGReturnAddress
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String accountNumber;
    protected DGOrganisationalUnit organisationalUnit;

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the organisationalUnit property.
     * 
     * @return
     *     possible object is
     *     {@link DGOrganisationalUnit }
     *     
     */
    public DGOrganisationalUnit getOrganisationalUnit() {
        return organisationalUnit;
    }

    /**
     * Sets the value of the organisationalUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGOrganisationalUnit }
     *     
     */
    public void setOrganisationalUnit(DGOrganisationalUnit value) {
        this.organisationalUnit = value;
    }

}
