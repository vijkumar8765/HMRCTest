
package lbf_acct_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_Acct complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_Acct"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accountDetails" type="{http://LBF_Acct_1_0}DG_AcctDets" minOccurs="0"/&gt;
 *         &lt;element name="productDetails" type="{http://LBF_Acct_1_0}DG_AcctProd" minOccurs="0"/&gt;
 *         &lt;element name="groupDetails" type="{http://LBF_Acct_1_0}DG_AcctGroup" minOccurs="0"/&gt;
 *         &lt;element name="categoryDetails" type="{http://LBF_Acct_1_0}DG_AcctCat" minOccurs="0"/&gt;
 *         &lt;element name="catMemberDetails" type="{http://LBF_Acct_1_0}DG_AcctCatMbrshp" minOccurs="0"/&gt;
 *         &lt;element name="mainDetails" type="{http://LBF_Acct_1_0}DG_AcctMain" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_Acct", propOrder = {
    "accountDetails",
    "productDetails",
    "groupDetails",
    "categoryDetails",
    "catMemberDetails",
    "mainDetails"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGAcct
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGAcctDets accountDetails;
    protected DGAcctProd productDetails;
    protected DGAcctGroup groupDetails;
    protected DGAcctCat categoryDetails;
    protected DGAcctCatMbrshp catMemberDetails;
    protected DGAcctMain mainDetails;

    /**
     * Gets the value of the accountDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGAcctDets }
     *     
     */
    public DGAcctDets getAccountDetails() {
        return accountDetails;
    }

    /**
     * Sets the value of the accountDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGAcctDets }
     *     
     */
    public void setAccountDetails(DGAcctDets value) {
        this.accountDetails = value;
    }

    /**
     * Gets the value of the productDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGAcctProd }
     *     
     */
    public DGAcctProd getProductDetails() {
        return productDetails;
    }

    /**
     * Sets the value of the productDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGAcctProd }
     *     
     */
    public void setProductDetails(DGAcctProd value) {
        this.productDetails = value;
    }

    /**
     * Gets the value of the groupDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGAcctGroup }
     *     
     */
    public DGAcctGroup getGroupDetails() {
        return groupDetails;
    }

    /**
     * Sets the value of the groupDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGAcctGroup }
     *     
     */
    public void setGroupDetails(DGAcctGroup value) {
        this.groupDetails = value;
    }

    /**
     * Gets the value of the categoryDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGAcctCat }
     *     
     */
    public DGAcctCat getCategoryDetails() {
        return categoryDetails;
    }

    /**
     * Sets the value of the categoryDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGAcctCat }
     *     
     */
    public void setCategoryDetails(DGAcctCat value) {
        this.categoryDetails = value;
    }

    /**
     * Gets the value of the catMemberDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGAcctCatMbrshp }
     *     
     */
    public DGAcctCatMbrshp getCatMemberDetails() {
        return catMemberDetails;
    }

    /**
     * Sets the value of the catMemberDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGAcctCatMbrshp }
     *     
     */
    public void setCatMemberDetails(DGAcctCatMbrshp value) {
        this.catMemberDetails = value;
    }

    /**
     * Gets the value of the mainDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGAcctMain }
     *     
     */
    public DGAcctMain getMainDetails() {
        return mainDetails;
    }

    /**
     * Sets the value of the mainDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGAcctMain }
     *     
     */
    public void setMainDetails(DGAcctMain value) {
        this.mainDetails = value;
    }

}
