
package lbf_acct_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_AcctDets complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_AcctDets"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accountStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="memberStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountRiskDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="accountEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="accountRetirementAgeYears" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="accountRetirementAgeMonths" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="accountAnnualServicingDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="SIPPIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="productGroupingType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="SIPPSubStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="cofundsPlatformStatus" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_AcctDets", propOrder = {
    "accountStatus",
    "memberStatus",
    "accountRiskDate",
    "accountEndDate",
    "accountRetirementAgeYears",
    "accountRetirementAgeMonths",
    "accountAnnualServicingDate",
    "sippIndicator",
    "productGroupingType",
    "sippSubStatus",
    "cofundsPlatformStatus"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGAcctDets
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String accountStatus;
    protected String memberStatus;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar accountRiskDate;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar accountEndDate;
    protected Integer accountRetirementAgeYears;
    protected Integer accountRetirementAgeMonths;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar accountAnnualServicingDate;
    @XmlElement(name = "SIPPIndicator")
    protected Boolean sippIndicator;
    protected String productGroupingType;
    @XmlElement(name = "SIPPSubStatus")
    protected String sippSubStatus;
    protected Boolean cofundsPlatformStatus;

    /**
     * Gets the value of the accountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountStatus() {
        return accountStatus;
    }

    /**
     * Sets the value of the accountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountStatus(String value) {
        this.accountStatus = value;
    }

    /**
     * Gets the value of the memberStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberStatus() {
        return memberStatus;
    }

    /**
     * Sets the value of the memberStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberStatus(String value) {
        this.memberStatus = value;
    }

    /**
     * Gets the value of the accountRiskDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getAccountRiskDate() {
        return accountRiskDate;
    }

    /**
     * Sets the value of the accountRiskDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setAccountRiskDate(XMLGregorianCalendar value) {
        this.accountRiskDate = value;
    }

    /**
     * Gets the value of the accountEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getAccountEndDate() {
        return accountEndDate;
    }

    /**
     * Sets the value of the accountEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setAccountEndDate(XMLGregorianCalendar value) {
        this.accountEndDate = value;
    }

    /**
     * Gets the value of the accountRetirementAgeYears property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAccountRetirementAgeYears() {
        return accountRetirementAgeYears;
    }

    /**
     * Sets the value of the accountRetirementAgeYears property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAccountRetirementAgeYears(Integer value) {
        this.accountRetirementAgeYears = value;
    }

    /**
     * Gets the value of the accountRetirementAgeMonths property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAccountRetirementAgeMonths() {
        return accountRetirementAgeMonths;
    }

    /**
     * Sets the value of the accountRetirementAgeMonths property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAccountRetirementAgeMonths(Integer value) {
        this.accountRetirementAgeMonths = value;
    }

    /**
     * Gets the value of the accountAnnualServicingDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getAccountAnnualServicingDate() {
        return accountAnnualServicingDate;
    }

    /**
     * Sets the value of the accountAnnualServicingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setAccountAnnualServicingDate(XMLGregorianCalendar value) {
        this.accountAnnualServicingDate = value;
    }

    /**
     * Gets the value of the sippIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSIPPIndicator() {
        return sippIndicator;
    }

    /**
     * Sets the value of the sippIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSIPPIndicator(Boolean value) {
        this.sippIndicator = value;
    }

    /**
     * Gets the value of the productGroupingType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductGroupingType() {
        return productGroupingType;
    }

    /**
     * Sets the value of the productGroupingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductGroupingType(String value) {
        this.productGroupingType = value;
    }

    /**
     * Gets the value of the sippSubStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSIPPSubStatus() {
        return sippSubStatus;
    }

    /**
     * Sets the value of the sippSubStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSIPPSubStatus(String value) {
        this.sippSubStatus = value;
    }

    /**
     * Gets the value of the cofundsPlatformStatus property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCofundsPlatformStatus() {
        return cofundsPlatformStatus;
    }

    /**
     * Sets the value of the cofundsPlatformStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCofundsPlatformStatus(Boolean value) {
        this.cofundsPlatformStatus = value;
    }

}
