package com.lgim.group.service.graphql.service;

import com.lgim.group.service.graphql.dto.WorkplacePensionCustomerDetailsDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionFundDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionFunds;
import com.lgim.group.service.graphql.dto.WorkplacePensionHoldingsDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionInputDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionSwitchAndRedirectOrderResponseDto;

import java.util.List;

public interface WorkplaceSavingsService {
  WorkplacePensionHoldingsDto getWorkplacePensionHoldings(String policyNumber, String jwtToken, String journeyId);

  WorkplacePensionCustomerDetailsDto getWorkplacePensionCustomerDetails(String policyNumber, String jwtToken, String journeyId);

  WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto isSwitchAndRedirectAllowed(String policyNumber, String jwtToken, String journeyId);

  WorkplacePensionFunds retrieveAllowableFunds(String policyNumber, String schemeCategory, String schemeMembership, String productId, String jwtToken, String journeyId);

  List<WorkplacePensionFundDto> getWorkplacePensionFundDetails(List<String> fundCodes, String jwtToken, String journeyId) throws Exception;

  WorkplacePensionSwitchAndRedirectOrderResponseDto processWorkplacePensionSwitchAndRedirectOrder(
      String policyNumber, WorkplacePensionInputDto workplacePensionInputDto, String jwtToken, String journeyId) throws Exception;

  String unhashPolicyNumber(String hashedPolicyNumber, String jwtToken, String journeyId) throws Exception;
}
