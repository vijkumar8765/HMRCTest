package com.lgim.group.service.graphql.util;

import graphql.schema.DataFetchingEnvironment;
import graphql.servlet.GraphQLContext;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;

@Component(value = "journeyIdExtractor")
@Profile("!graphiql")
public class JourneyIdExtractorImpl implements JourneyIdExtractor {

  @Override
  public String extractJourneyId(DataFetchingEnvironment environment) {
    return ((GraphQLContext) environment.getContext()).getRequest()
        .map(request -> request.getAttribute("journeyId").toString())
        .filter(journeyId -> !StringUtils.isEmpty(journeyId))
        .orElseThrow(() -> new HttpServerErrorException(HttpStatus.BAD_REQUEST, " JourneyId is not provided or is empty!"));
  }
}


