
package lbb_acct_b_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_AccountFundProvider complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_AccountFundProvider"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fundProviderId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fundProviderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_AccountFundProvider", propOrder = {
    "fundProviderId",
    "fundProviderName"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAAccountFundProvider
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String fundProviderId;
    protected String fundProviderName;

    /**
     * Gets the value of the fundProviderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundProviderId() {
        return fundProviderId;
    }

    /**
     * Sets the value of the fundProviderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundProviderId(String value) {
        this.fundProviderId = value;
    }

    /**
     * Gets the value of the fundProviderName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundProviderName() {
        return fundProviderName;
    }

    /**
     * Sets the value of the fundProviderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundProviderName(String value) {
        this.fundProviderName = value;
    }

}
