package com.lgim.group.service.customerprofile.services.db;

import com.lgim.group.service.customerprofile.dto.CustomerProfileDto;
import com.lgim.group.service.customerprofile.dto.ImmutableCustomerProfileDto;
import com.lgim.group.service.customerprofile.exception.CustomerNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Date;
import java.util.Map;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CustomerStoredProcedureCall {

  // Database configuration
  private static final String SCHEMA_NAME = "DB2SEC2";
  private static final String CUSTOMER_DATA_SP = "SP0027";

  // Input column names for the stored procedure
  private static final String EMPTY_STRING = "";
  private static final String IN_FUNCTION_CODE = "FUNCTION_CODE";
  private static final String IN_LOGCL_RUN_DTE = "LOGCL_RUN_DTE";
  private static final String IN_SCHD_CMPNT_CDE = "SCHD_CMPNT_CDE";
  private static final String IN_ENV_TYPE_CDE = "ENV_TYPE_CDE";
  private static final String IN_USER_ID = "USER_ID";
  private static final String IN_PARTY_ID = "PARTY_ID";
  private static final String IN_EFFECTIVE_DATE = "EFFECTIVE_DATE";
  private static final String IN_SURNAME = "SURNAME";
  private static final String IN_FIRST_INITIAL = "FIRST_INITIAL";
  private static final String IN_SECOND_INITIAL = "SECOND_INITIAL";
  private static final String IN_THIRD_INITIAL = "THIRD_INITIAL";
  private static final String IN_GENDER = "GENDER";
  private static final String IN_DATE_OF_BIRTH = "DATE_OF_BIRTH";
  private static final String IN_POSTCODE = "POSTCODE";
  private static final String IN_NINO = "NINO";

  // Output column names returned from the customer profile cursor
  static final String OUT_FIRST_FORENAME = "PERS_FRST_FRNM";
  static final String OUT_SURNAME = "PERS_SRNM";
  static final String OUT_BIRTH_DATE = "PERS_BRTH_DATE";
  static final String OUT_GENDER = "PERS_SEX";
  static final String OUT_TITLE = "PERS_TITL";

  // These are map keys for the stored procedure result set
  public static final String RESULT_SET_KEY = "#result-set-1";

  private static final String ERRORS_EXECUTING = "Error executing stored procedure.";

  @Autowired
  private SimpleJdbcCall simpleJdbcCall;

  @Bean
  protected SimpleJdbcCall getSimpleJdbcCall(DataSource dataSource) {
    return new SimpleJdbcCall(dataSource)
          .withSchemaName(SCHEMA_NAME)
          .withProcedureName(CUSTOMER_DATA_SP)
          .returningResultSet(RESULT_SET_KEY, CustomerStoredProcedureCall::mapFrom);
  }

  public Map<String, Object> execute(final String partyId) {
    final SqlParameterSource sqlParams = createSqlParams(partyId);
    log.info("Calling stored procedure SP0027 with sql params: {}", sqlParams);

    try {
      return simpleJdbcCall.execute(sqlParams);
    } catch (DataAccessException dae) {
      throw new CustomerNotFoundException(ERRORS_EXECUTING, Collections.singletonList(dae.getLocalizedMessage()), dae);
    }
  }

  @SuppressWarnings("squid:S1172")
  static CustomerProfileDto mapFrom(final ResultSet rs, final int rowNum) throws SQLException {
    final String surname = rs.getString(OUT_SURNAME);
    final String forename = rs.getString(OUT_FIRST_FORENAME);
    final java.sql.Date dateOfBirth = rs.getDate(OUT_BIRTH_DATE);
    final String gender = rs.getString(OUT_GENDER);
    final String title = rs.getString(OUT_TITLE);

    return ImmutableCustomerProfileDto.builder()
          .withTitle(title.trim())
          .withForename(forename.trim())
          .withSurname(surname.trim())
          .withGender(gender.trim())
          .withDateOfBirth((java.util.Date)dateOfBirth)
          .build();
  }

  private SqlParameterSource createSqlParams(final String partyId) {
    return new MapSqlParameterSource()
          .addValue(IN_FUNCTION_CODE, EMPTY_STRING)
          .addValue(IN_LOGCL_RUN_DTE, EMPTY_STRING)
          .addValue(IN_SCHD_CMPNT_CDE, EMPTY_STRING)
          .addValue(IN_ENV_TYPE_CDE, EMPTY_STRING)
          .addValue(IN_USER_ID, EMPTY_STRING)
          .addValue(IN_EFFECTIVE_DATE, EMPTY_STRING)
          .addValue(IN_PARTY_ID, partyId)
          .addValue(IN_SURNAME, EMPTY_STRING)
          .addValue(IN_FIRST_INITIAL, EMPTY_STRING)
          .addValue(IN_SECOND_INITIAL, EMPTY_STRING)
          .addValue(IN_THIRD_INITIAL, EMPTY_STRING)
          .addValue(IN_GENDER, EMPTY_STRING)
          .addValue(IN_DATE_OF_BIRTH, EMPTY_STRING)
          .addValue(IN_POSTCODE, EMPTY_STRING)
          .addValue(IN_NINO, EMPTY_STRING);
  }
}
