package com.lgim.group.service.graphql.dto;

import java.math.BigDecimal;
import java.util.List;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class WorkplacePensionFundDto implements java.io.Serializable {

  private String fundCode;
  private String isin;
  private String sedol;
  private String mexcode;
  private String name;
  private String fundType;
  private String fundAim;
  private BigDecimal unitPrice;
  private Float managementCharge;
  private String managementType;
  private Boolean coreFund;
  private Boolean softClosed;
  private String managementCompany;
  private List<String> region;
  private String fundFactSheetUrl;
  private List<ChartDataDto> fundPerformanceData;
  private String benchmarkPerformanceName;
  private List<ChartDataDto> benchmarkPerformanceData;
  private LifestyleSwitchingFrequency lifestyleSwitchingFrequency;
  private List<LifestyleProfileDataDto> lifestyleProfileData;

  public WorkplacePensionFundDto(String fundCode, String isin, String sedol, String mexcode, String name, String fundType, String fundAim, BigDecimal unitPrice, Float managementCharge, String managementType, Boolean coreFund, Boolean softClosed, String managementCompany, List<String> region, String fundFactSheetUrl, List<ChartDataDto> fundPerformanceData, String benchmarkPerformanceName, List<ChartDataDto> benchmarkPerformanceData, LifestyleSwitchingFrequency lifestyleSwitchingFrequency, List<LifestyleProfileDataDto> lifestyleProfileData) {
    this.fundCode = fundCode;
    this.isin = isin;
    this.sedol = sedol;
    this.mexcode = mexcode;
    this.name = name;
    this.fundType = fundType;
    this.fundAim = fundAim;
    this.unitPrice = unitPrice;
    this.managementCharge = managementCharge;
    this.managementType = managementType;
    this.coreFund = coreFund;
    this.softClosed = softClosed;
    this.managementCompany = managementCompany;
    this.region = region;
    this.fundFactSheetUrl = fundFactSheetUrl;
    this.fundPerformanceData = fundPerformanceData;
    this.benchmarkPerformanceName = benchmarkPerformanceName;
    this.benchmarkPerformanceData = benchmarkPerformanceData;
    this.lifestyleSwitchingFrequency = lifestyleSwitchingFrequency;
    this.lifestyleProfileData = lifestyleProfileData;
  }
}
