
package lbb_personcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_PersonName complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_PersonName"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="forenames" type="{http://LBB_PersonCommon_1_0}DG_Forenames" minOccurs="0"/&gt;
 *         &lt;element name="surname" type="{http://LBB_PersonCommon_1_0}DG_Surname" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_PersonName", propOrder = {
    "forenames",
    "surname"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGPersonName
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGForenames forenames;
    protected DGSurname surname;

    /**
     * Gets the value of the forenames property.
     * 
     * @return
     *     possible object is
     *     {@link DGForenames }
     *     
     */
    public DGForenames getForenames() {
        return forenames;
    }

    /**
     * Sets the value of the forenames property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGForenames }
     *     
     */
    public void setForenames(DGForenames value) {
        this.forenames = value;
    }

    /**
     * Gets the value of the surname property.
     * 
     * @return
     *     possible object is
     *     {@link DGSurname }
     *     
     */
    public DGSurname getSurname() {
        return surname;
    }

    /**
     * Sets the value of the surname property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGSurname }
     *     
     */
    public void setSurname(DGSurname value) {
        this.surname = value;
    }

}
