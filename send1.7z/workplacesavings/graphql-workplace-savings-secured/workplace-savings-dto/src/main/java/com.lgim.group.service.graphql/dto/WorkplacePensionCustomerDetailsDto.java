package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class WorkplacePensionCustomerDetailsDto implements java.io.Serializable {
  private String emailAddress;
  private String schemeMembership;
  private String schemeCategory;
  private String pensionProductId;

  public WorkplacePensionCustomerDetailsDto(String emailAddress, String schemeMembership, String schemeCategory, String pensionProductId) {
    this.emailAddress = emailAddress;
    this.schemeMembership = schemeMembership;
    this.schemeCategory = schemeCategory;
    this.pensionProductId = pensionProductId;
  }
}
