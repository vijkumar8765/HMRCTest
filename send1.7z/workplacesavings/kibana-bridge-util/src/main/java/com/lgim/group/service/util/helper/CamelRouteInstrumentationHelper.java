package com.lgim.group.service.util.helper;


import com.lgim.group.gatekeeper.processor.ValidateJwtTokenProcessor;
import com.lgim.group.ws.utility.plugin.model.GroupDigitalMessage;
import com.lgim.group.ws.utility.plugin.util.AuditRouteHelper;
import java.net.URI;
import java.time.ZonedDateTime;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.CamelContextAware;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CamelRouteInstrumentationHelper implements CamelContextAware {

  public static final String GROUP_DIGITAL_MESSAGE_FOR_INCOMING_REST_PROPERTY_KEY = "groupDigitalMessageForIncomingREST";
  private CamelContext camelContext;
  private ProducerTemplate producerTemplate;

  @Autowired
  private ValidateJwtTokenProcessor validateJwtTokenProcessor;

  public void logSoapAndRestCalls(RouteBuilder rb, String microServiceBusinessFunction, String microserviceName) {
    rb.getContext().getManagementStrategy().addEventNotifier(new CxfSoapInstrumentingEventNotifier(producerTemplate));
    rb.interceptFrom("rest*")
        .log("Intercepted exchange entering REST route, going to log GroupDigitalMessage")
        .process((exchange -> {
          String journeyId = exchange.getIn().getHeader("Journeyid", String.class);
          String endpointUriActual = exchange.getIn().getHeader(Exchange.HTTP_URI, String.class);
          String endpointUriDefinition = exchange.getIn().getHeader(Exchange.INTERCEPTED_ENDPOINT, String.class);
          String endpointUriWithoutCamelComponent = endpointUriDefinition.substring(endpointUriDefinition.indexOf("://") + 1);
          String cleansedEndpoint;
          if (endpointUriWithoutCamelComponent.indexOf('{') > -1) {
            cleansedEndpoint = endpointUriWithoutCamelComponent.substring(1, endpointUriWithoutCamelComponent.indexOf('{'));
          } else {
            cleansedEndpoint = endpointUriWithoutCamelComponent;
          }
          if (cleansedEndpoint.endsWith("/")) {
            cleansedEndpoint = cleansedEndpoint.substring(1, cleansedEndpoint.length() - 1);
          }
          String path = new URI(cleansedEndpoint).getPath();
          GroupDigitalMessage gdm = new GroupDigitalMessage();
          gdm.setBusinessFunction(microServiceBusinessFunction);
          gdm.setMicroserviceName(microserviceName);
          gdm.setMicroserviceMethod(path);
          gdm.setJourneyId(journeyId);
          gdm.getTags().put("endpointUriActual", endpointUriActual);
          gdm.getTags().put("endpointUriCleansed", cleansedEndpoint);
          gdm.getTags().put("endpointUriDefinition", endpointUriDefinition);
          gdm.getTags().put("is_framework_generated", "true");
          gdm.getTags().put("is_request", "true");
          gdm.getTags().put("protocol", "rest");
          gdm.getTags().put("status", "Servicing incoming REST call on endpoint " + cleansedEndpoint);
          addClaimsToGroupDigitalMessage(exchange,gdm);
          gdm.getAuditData().setCurrentRoute(exchange.getUnitOfWork().getRouteContext().getRoute().getId());
          gdm.getAuditData().setCreatedAt(ZonedDateTime.now());
          gdm.getAuditData().setUpdatedAt(ZonedDateTime.now());
          new AuditRouteHelper().sendGroupDigitalMessageForAuditing(producerTemplate, gdm);
          log.info("Finished intercepting REST request");
          exchange.setProperty(GROUP_DIGITAL_MESSAGE_FOR_INCOMING_REST_PROPERTY_KEY, gdm);
        }))
    ;
  }

  private void addClaimsToGroupDigitalMessage(Exchange exchange, GroupDigitalMessage gdm) {
    try {
      validateJwtTokenProcessor.process(exchange);
      Map<String, Object> claims = (Map<String, Object>)exchange.getIn().getHeader("CLAIMS", Map.class);
      if (claims != null) {
        for (String key: claims.keySet()) {
          gdm.getTags().put("claims_" + key, claims.get(key).toString());
        }
      }
    } catch (Exception ex) {
      log.info("Unable to add claims due to:" +ex.getMessage());
    }
  }



  @Override
  public void setCamelContext(CamelContext camelContext) {
    this.camelContext = camelContext;
    //ProducerTemplate is thread safe
    this.producerTemplate = camelContext.createProducerTemplate();
  }

  @Override
  public CamelContext getCamelContext() {
    return camelContext;
  }
}
