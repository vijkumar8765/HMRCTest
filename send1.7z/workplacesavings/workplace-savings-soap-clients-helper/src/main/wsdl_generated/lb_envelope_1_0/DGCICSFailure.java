
package lb_envelope_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_CICSFailure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_CICSFailure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_Failure"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="errorPgmId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="serviceAdapterName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="sectionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="returnCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_CICSFailure", propOrder = {
    "errorPgmId",
    "serviceAdapterName",
    "sectionName",
    "returnCode"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGCICSFailure
    extends DGFailure
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String errorPgmId;
    protected String serviceAdapterName;
    protected String sectionName;
    protected Integer returnCode;

    /**
     * Gets the value of the errorPgmId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorPgmId() {
        return errorPgmId;
    }

    /**
     * Sets the value of the errorPgmId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorPgmId(String value) {
        this.errorPgmId = value;
    }

    /**
     * Gets the value of the serviceAdapterName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceAdapterName() {
        return serviceAdapterName;
    }

    /**
     * Sets the value of the serviceAdapterName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceAdapterName(String value) {
        this.serviceAdapterName = value;
    }

    /**
     * Gets the value of the sectionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSectionName() {
        return sectionName;
    }

    /**
     * Sets the value of the sectionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSectionName(String value) {
        this.sectionName = value;
    }

    /**
     * Gets the value of the returnCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getReturnCode() {
        return returnCode;
    }

    /**
     * Sets the value of the returnCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setReturnCode(Integer value) {
        this.returnCode = value;
    }

}
