
package lbb_acct_b_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_AccountCollectionMethod complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_AccountCollectionMethod"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="billingGroupId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="billingGroup" type="{http://LBB_Acct_B_1_0}DA_AccountBillingGroup" minOccurs="0"/&gt;
 *         &lt;element name="interimBillingGroupId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_AccountCollectionMethod", propOrder = {
    "billingGroupId",
    "billingGroup",
    "interimBillingGroupId"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAAccountCollectionMethod
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String billingGroupId;
    protected DAAccountBillingGroup billingGroup;
    protected String interimBillingGroupId;

    /**
     * Gets the value of the billingGroupId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingGroupId() {
        return billingGroupId;
    }

    /**
     * Sets the value of the billingGroupId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingGroupId(String value) {
        this.billingGroupId = value;
    }

    /**
     * Gets the value of the billingGroup property.
     * 
     * @return
     *     possible object is
     *     {@link DAAccountBillingGroup }
     *     
     */
    public DAAccountBillingGroup getBillingGroup() {
        return billingGroup;
    }

    /**
     * Sets the value of the billingGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link DAAccountBillingGroup }
     *     
     */
    public void setBillingGroup(DAAccountBillingGroup value) {
        this.billingGroup = value;
    }

    /**
     * Gets the value of the interimBillingGroupId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterimBillingGroupId() {
        return interimBillingGroupId;
    }

    /**
     * Sets the value of the interimBillingGroupId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterimBillingGroupId(String value) {
        this.interimBillingGroupId = value;
    }

}
