
package lbb_acct_b_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_AccountFund complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_AccountFund"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fundId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fundName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fundLongName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fundType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="externalFundIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="withProfitsIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="distributionFundCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="cppiParentFundId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="cppiParentFundName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="fundBlockIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="fundProvider" type="{http://LBB_Acct_B_1_0}DA_AccountFundProvider" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_AccountFund", propOrder = {
    "fundId",
    "fundName",
    "fundLongName",
    "fundType",
    "externalFundIndicator",
    "withProfitsIndicator",
    "distributionFundCode",
    "cppiParentFundId",
    "cppiParentFundName",
    "fundBlockIndicator",
    "fundProvider"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAAccountFund
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String fundId;
    protected String fundName;
    protected String fundLongName;
    protected String fundType;
    protected Boolean externalFundIndicator;
    protected String withProfitsIndicator;
    protected String distributionFundCode;
    protected String cppiParentFundId;
    protected String cppiParentFundName;
    protected Boolean fundBlockIndicator;
    protected DAAccountFundProvider fundProvider;

    /**
     * Gets the value of the fundId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundId() {
        return fundId;
    }

    /**
     * Sets the value of the fundId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundId(String value) {
        this.fundId = value;
    }

    /**
     * Gets the value of the fundName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundName() {
        return fundName;
    }

    /**
     * Sets the value of the fundName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundName(String value) {
        this.fundName = value;
    }

    /**
     * Gets the value of the fundLongName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundLongName() {
        return fundLongName;
    }

    /**
     * Sets the value of the fundLongName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundLongName(String value) {
        this.fundLongName = value;
    }

    /**
     * Gets the value of the fundType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundType() {
        return fundType;
    }

    /**
     * Sets the value of the fundType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundType(String value) {
        this.fundType = value;
    }

    /**
     * Gets the value of the externalFundIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExternalFundIndicator() {
        return externalFundIndicator;
    }

    /**
     * Sets the value of the externalFundIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExternalFundIndicator(Boolean value) {
        this.externalFundIndicator = value;
    }

    /**
     * Gets the value of the withProfitsIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWithProfitsIndicator() {
        return withProfitsIndicator;
    }

    /**
     * Sets the value of the withProfitsIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWithProfitsIndicator(String value) {
        this.withProfitsIndicator = value;
    }

    /**
     * Gets the value of the distributionFundCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistributionFundCode() {
        return distributionFundCode;
    }

    /**
     * Sets the value of the distributionFundCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistributionFundCode(String value) {
        this.distributionFundCode = value;
    }

    /**
     * Gets the value of the cppiParentFundId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCppiParentFundId() {
        return cppiParentFundId;
    }

    /**
     * Sets the value of the cppiParentFundId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCppiParentFundId(String value) {
        this.cppiParentFundId = value;
    }

    /**
     * Gets the value of the cppiParentFundName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCppiParentFundName() {
        return cppiParentFundName;
    }

    /**
     * Sets the value of the cppiParentFundName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCppiParentFundName(String value) {
        this.cppiParentFundName = value;
    }

    /**
     * Gets the value of the fundBlockIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFundBlockIndicator() {
        return fundBlockIndicator;
    }

    /**
     * Sets the value of the fundBlockIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFundBlockIndicator(Boolean value) {
        this.fundBlockIndicator = value;
    }

    /**
     * Gets the value of the fundProvider property.
     * 
     * @return
     *     possible object is
     *     {@link DAAccountFundProvider }
     *     
     */
    public DAAccountFundProvider getFundProvider() {
        return fundProvider;
    }

    /**
     * Sets the value of the fundProvider property.
     * 
     * @param value
     *     allowed object is
     *     {@link DAAccountFundProvider }
     *     
     */
    public void setFundProvider(DAAccountFundProvider value) {
        this.fundProvider = value;
    }

}
