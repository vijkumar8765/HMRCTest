
package lbf_party_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGResponseEnvelope;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_RetrInterPartyRelsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_RetrInterPartyRelsResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_ResponseEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="interPartyRelationships" type="{http://LBF_Party_1_0}DG_InterPartyRelationships" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="tooManyRows" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_RetrInterPartyRelsResponse", propOrder = {
    "interPartyRelationships",
    "tooManyRows"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGRetrInterPartyRelsResponse
    extends DGResponseEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected List<DGInterPartyRelationships> interPartyRelationships;
    protected Boolean tooManyRows;

    /**
     * Gets the value of the interPartyRelationships property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the interPartyRelationships property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInterPartyRelationships().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGInterPartyRelationships }
     * 
     * 
     */
    public List<DGInterPartyRelationships> getInterPartyRelationships() {
        if (interPartyRelationships == null) {
            interPartyRelationships = new ArrayList<DGInterPartyRelationships>();
        }
        return this.interPartyRelationships;
    }

    /**
     * Gets the value of the tooManyRows property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTooManyRows() {
        return tooManyRows;
    }

    /**
     * Sets the value of the tooManyRows property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTooManyRows(Boolean value) {
        this.tooManyRows = value;
    }

}
