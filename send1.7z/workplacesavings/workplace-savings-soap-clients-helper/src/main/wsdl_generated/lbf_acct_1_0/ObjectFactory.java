
package lbf_acct_1_0;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the lbf_acct_1_0 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: lbf_acct_1_0
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DGAcctLoc }
     * 
     */
    public DGAcctLoc createDGAcctLoc() {
        return new DGAcctLoc();
    }

    /**
     * Create an instance of {@link DGAcctCatMbrshp }
     * 
     */
    public DGAcctCatMbrshp createDGAcctCatMbrshp() {
        return new DGAcctCatMbrshp();
    }

    /**
     * Create an instance of {@link DGAssessAcctRespDets }
     * 
     */
    public DGAssessAcctRespDets createDGAssessAcctRespDets() {
        return new DGAssessAcctRespDets();
    }

    /**
     * Create an instance of {@link DGAssessAcctResp }
     * 
     */
    public DGAssessAcctResp createDGAssessAcctResp() {
        return new DGAssessAcctResp();
    }

    /**
     * Create an instance of {@link DGRetrAcctRolesSearchCriteria }
     * 
     */
    public DGRetrAcctRolesSearchCriteria createDGRetrAcctRolesSearchCriteria() {
        return new DGRetrAcctRolesSearchCriteria();
    }

    /**
     * Create an instance of {@link DGRetrAcctRolesRequest }
     * 
     */
    public DGRetrAcctRolesRequest createDGRetrAcctRolesRequest() {
        return new DGRetrAcctRolesRequest();
    }

    /**
     * Create an instance of {@link DGAcctRole }
     * 
     */
    public DGAcctRole createDGAcctRole() {
        return new DGAcctRole();
    }

    /**
     * Create an instance of {@link DGRetrAcctRolesResponse }
     * 
     */
    public DGRetrAcctRolesResponse createDGRetrAcctRolesResponse() {
        return new DGRetrAcctRolesResponse();
    }

    /**
     * Create an instance of {@link DGAcctCat }
     * 
     */
    public DGAcctCat createDGAcctCat() {
        return new DGAcctCat();
    }

    /**
     * Create an instance of {@link DGAcctDets }
     * 
     */
    public DGAcctDets createDGAcctDets() {
        return new DGAcctDets();
    }

    /**
     * Create an instance of {@link DGAcctMain }
     * 
     */
    public DGAcctMain createDGAcctMain() {
        return new DGAcctMain();
    }

    /**
     * Create an instance of {@link DGAcctGroup }
     * 
     */
    public DGAcctGroup createDGAcctGroup() {
        return new DGAcctGroup();
    }

    /**
     * Create an instance of {@link DGAcctProd }
     * 
     */
    public DGAcctProd createDGAcctProd() {
        return new DGAcctProd();
    }

    /**
     * Create an instance of {@link DGAcct }
     * 
     */
    public DGAcct createDGAcct() {
        return new DGAcct();
    }

    /**
     * Create an instance of {@link DGRetrAcctDetsResponse }
     * 
     */
    public DGRetrAcctDetsResponse createDGRetrAcctDetsResponse() {
        return new DGRetrAcctDetsResponse();
    }

    /**
     * Create an instance of {@link DGRetrAcctDetsRequest }
     * 
     */
    public DGRetrAcctDetsRequest createDGRetrAcctDetsRequest() {
        return new DGRetrAcctDetsRequest();
    }

    /**
     * Create an instance of {@link DGLocAcctRequest }
     * 
     */
    public DGLocAcctRequest createDGLocAcctRequest() {
        return new DGLocAcctRequest();
    }

    /**
     * Create an instance of {@link DGLocAcctResponse }
     * 
     */
    public DGLocAcctResponse createDGLocAcctResponse() {
        return new DGLocAcctResponse();
    }

    /**
     * Create an instance of {@link DGBusinessFunction }
     * 
     */
    public DGBusinessFunction createDGBusinessFunction() {
        return new DGBusinessFunction();
    }

    /**
     * Create an instance of {@link DGWIPSearchCriteria }
     * 
     */
    public DGWIPSearchCriteria createDGWIPSearchCriteria() {
        return new DGWIPSearchCriteria();
    }

    /**
     * Create an instance of {@link DGRetrWIPRequest }
     * 
     */
    public DGRetrWIPRequest createDGRetrWIPRequest() {
        return new DGRetrWIPRequest();
    }

    /**
     * Create an instance of {@link DGWIPSearchResult }
     * 
     */
    public DGWIPSearchResult createDGWIPSearchResult() {
        return new DGWIPSearchResult();
    }

    /**
     * Create an instance of {@link DGRetrWIPResponse }
     * 
     */
    public DGRetrWIPResponse createDGRetrWIPResponse() {
        return new DGRetrWIPResponse();
    }

    /**
     * Create an instance of {@link DGUnmtchdCashSearchCriteria }
     * 
     */
    public DGUnmtchdCashSearchCriteria createDGUnmtchdCashSearchCriteria() {
        return new DGUnmtchdCashSearchCriteria();
    }

    /**
     * Create an instance of {@link DGRetrUnmtchdCashRequest }
     * 
     */
    public DGRetrUnmtchdCashRequest createDGRetrUnmtchdCashRequest() {
        return new DGRetrUnmtchdCashRequest();
    }

    /**
     * Create an instance of {@link DGUnmtchdCashDetail }
     * 
     */
    public DGUnmtchdCashDetail createDGUnmtchdCashDetail() {
        return new DGUnmtchdCashDetail();
    }

    /**
     * Create an instance of {@link DGUnmtchdCashSearchResult }
     * 
     */
    public DGUnmtchdCashSearchResult createDGUnmtchdCashSearchResult() {
        return new DGUnmtchdCashSearchResult();
    }

    /**
     * Create an instance of {@link DGRetrUnmtchdCashResponse }
     * 
     */
    public DGRetrUnmtchdCashResponse createDGRetrUnmtchdCashResponse() {
        return new DGRetrUnmtchdCashResponse();
    }

    /**
     * Create an instance of {@link DGAssessAcctReqDets }
     * 
     */
    public DGAssessAcctReqDets createDGAssessAcctReqDets() {
        return new DGAssessAcctReqDets();
    }

    /**
     * Create an instance of {@link DGAssessAcctReq }
     * 
     */
    public DGAssessAcctReq createDGAssessAcctReq() {
        return new DGAssessAcctReq();
    }

    /**
     * Create an instance of {@link DGAcctPartyRole }
     * 
     */
    public DGAcctPartyRole createDGAcctPartyRole() {
        return new DGAcctPartyRole();
    }

}
