package com.lgim.group.ws.s341mock.service;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.common.ClasspathFileSource;
import com.github.tomakehurst.wiremock.common.FileSource;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

public class Application {

  private static String URL = "/MRF_Acct_1_0Web/sca/EXP_WS_RetrAcctContrSmry";
  private static Integer PORT = 8081;
  private static Integer STATUS_500 = 500;

  public static void main(String[] args) {

    // Start the wire mock server
    WireMockServer wireMockServer = new WireMockServer(options().port(PORT).fileSource(new ClasspathFileSourceWithoutLeadingSlash()));
    wireMockServer.start();

    // Configure the stub
    configureFor(PORT);

    /**
     * Default Stub Returns 500 if no request matches
     */
    stubFor(post(urlEqualTo(URL))
        .willReturn(aResponse()
        .withHeader("Content-Type", "text/plain")
        .withStatus(STATUS_500)
        .withBody("No Match found")));

    /**
     * Test#01 (Success Test)
     * Account No: 2691150031
     * effectiveDate: 2018-07-10
     */
    stubFor(post(urlEqualTo(URL))
        .withRequestBody(containing("<accountId>2691150031</accountId>"))
        .willReturn(aResponse()
            .withHeader("Content-Type", "text/plain")
            .withBodyFile("resp_accountnumber_2691150031.xml")));

    /**
     * Test#02 (Failure Test for invalid AccountNumber)
     * Account No: 2691150032
     * effectiveDate: 2018-07-10
     */
    stubFor(post(urlEqualTo(URL))
        .withRequestBody(containing("<accountId>2691150032</accountId>"))
        .willReturn(aResponse()
        .withHeader("Content-Type", "text/plain")
        .withBodyFile("resp_accountnumber_2691150032.xml")));

    System.out.println("Server started on " + PORT + "..");
  }

  /**
   * Inner class to override the output directory
   */
  static class ClasspathFileSourceWithoutLeadingSlash extends ClasspathFileSource {

    ClasspathFileSourceWithoutLeadingSlash() {
      super("");
    }

    @Override
    public FileSource child(String subDirectoryName) {
      return new ClasspathFileSource(subDirectoryName);
    }
  }
}
