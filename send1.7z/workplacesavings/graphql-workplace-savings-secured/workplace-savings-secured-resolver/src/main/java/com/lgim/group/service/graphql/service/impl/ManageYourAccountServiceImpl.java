package com.lgim.group.service.graphql.service.impl;

import com.lgim.group.service.graphql.dto.CustomerProfileDto;
import com.lgim.group.service.graphql.service.ManageYourAccountService;
import com.lgim.group.service.graphql.util.RestUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@Slf4j
public class ManageYourAccountServiceImpl implements ManageYourAccountService {

  @Value("${customer.profile.service.url}")
  private String customerProfileServiceUrl;

  @Override
  public CustomerProfileDto getCustomerProfile(String partyId, String jwtToken) {
    log.info("Received a request to get customer profile for customer ID {}", partyId);

    final String url = customerProfileServiceUrl + "/customers/" + partyId;
    final HttpEntity<String> entity = getHttpEntityWithHeadersSet(jwtToken);
    final ResponseEntity<CustomerProfileDto> responseEntity = RestUtil.REST_TEMPLATE.exchange(url, HttpMethod.GET, entity, CustomerProfileDto.class);
    final CustomerProfileDto customerProfileDto = responseEntity.getBody();

    log.info("Completed request to get Customer Profile for customer ID: {}", partyId);
    return customerProfileDto;
  }

  private HttpEntity<String> getHttpEntityWithHeadersSet(String jwtToken) {
    final HttpHeaders headers = new HttpHeaders();
    final String journeyId = generateUuid();

    headers.set(RestUtil.JWT_TOKEN_REST_HEADER_NAME, jwtToken);
    headers.set(RestUtil.JOURNEY_ID_REST_HEADER_NAME, journeyId);
    headers.set("Content-Type", "application/json");

    return new HttpEntity<>("parameters", headers);
  }

  private String generateUuid() {
    return UUID.randomUUID().toString();
  }
}