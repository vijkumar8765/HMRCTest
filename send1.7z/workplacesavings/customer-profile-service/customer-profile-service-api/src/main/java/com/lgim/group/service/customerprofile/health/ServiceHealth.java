package com.lgim.group.service.customerprofile.health;

import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health.Builder;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.SQLException;

@Component
public class ServiceHealth extends AbstractHealthIndicator {

  private DataSource dataSource;

  public ServiceHealth(DataSource dataSource) {
    this.dataSource = dataSource;
  }

  @Override
  protected void doHealthCheck(Builder builder) {
    try {
      dataSource.getConnection();
      builder.up();
    } catch (SQLException sqlException) {
      builder.down();
    }
  }
}
