package com.lgim.group.service.customerprofile.audit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AuditHelperTest {

  private static final String BUSINESS_FUNCTION = "GlobalCustomerDatabaseTest";
  private static final String MICRO_SERVICE_NAME = "GlobalCustomerDatabaseTest";
  private static final String MICRO_SEVRICE_METHOD = "GlobalCustomerDatabaseTest";
  private static final String PARTY_ID = "partyIdTest";

  @Mock
  private AuditLogsService auditLogsService;

  @Test
  public void auditTest() {
    AuditHelper auditHelper = new AuditHelper(auditLogsService);
    Mockito.doNothing().when(auditLogsService).audit(Mockito.any());
    auditHelper.audit(PARTY_ID, BUSINESS_FUNCTION, MICRO_SERVICE_NAME, MICRO_SEVRICE_METHOD);
  }


}
