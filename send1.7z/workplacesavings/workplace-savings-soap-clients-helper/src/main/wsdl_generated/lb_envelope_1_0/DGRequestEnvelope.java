
package lb_envelope_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import lb_servicecontext_1_0.DGServiceContext;
import lbf_inv_1_0.DGConstructInvInstrRequest;
import lbf_inv_1_0.DGDtrmnTxEffctvDateRequest;
import lbf_inv_1_0.DGInsertInvInstrRequest;
import lbf_inv_1_0.DGRetrInvBeneDetsRequest;
import lbf_inv_1_0.DGValidateInvInstrRequest;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_RequestEnvelope complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_RequestEnvelope"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="context" type="{http://LB_ServiceContext_1_0}DG_ServiceContext" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_RequestEnvelope", propOrder = {
    "context"
})
@XmlSeeAlso({
    DGInsertInvInstrRequest.class,
    DGValidateInvInstrRequest.class,
    DGConstructInvInstrRequest.class,
    DGRetrInvBeneDetsRequest.class,
    DGDtrmnTxEffctvDateRequest.class
})
@ToString
@EqualsAndHashCode
public class DGRequestEnvelope implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGServiceContext context;

    /**
     * Gets the value of the context property.
     * 
     * @return
     *     possible object is
     *     {@link DGServiceContext }
     *     
     */
    public DGServiceContext getContext() {
        return context;
    }

    /**
     * Sets the value of the context property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGServiceContext }
     *     
     */
    public void setContext(DGServiceContext value) {
        this.context = value;
    }

}
