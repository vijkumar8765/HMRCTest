package com.lgim.group.service.graphql.util;

import org.springframework.web.client.RestTemplate;

public class RestUtil {

  public static final String JWT_TOKEN_REST_HEADER_NAME = "Authorization";
  public static final String JOURNEY_ID_REST_HEADER_NAME = "journeyId";
  public static final String QUESTION_MARK = "?";
  public static final String AMPERSAND = "&";

  public static final RestTemplate REST_TEMPLATE = new RestTemplate();
}
