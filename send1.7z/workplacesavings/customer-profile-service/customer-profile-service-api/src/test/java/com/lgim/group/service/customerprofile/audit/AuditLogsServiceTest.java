package com.lgim.group.service.customerprofile.audit;

import com.lgim.group.ws.utility.plugin.model.GroupDigitalMessage;
import com.lgim.group.ws.utility.plugin.util.AuditRouteHelper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import static com.lgim.group.ws.utility.plugin.constants.ServiceUtilConstant.KEY_PARTY_ID;

@RunWith(MockitoJUnitRunner.class)
public class AuditLogsServiceTest {
  @Mock
  private AuditRouteHelper auditRouteHelper;

  @Test
  public void auditTest() {
    GroupDigitalMessage gdMessage = new GroupDigitalMessage();
    gdMessage.setBusinessFunction("GlobalCustomerDatabaseTest");
    gdMessage.setMicroserviceName("CustomerProfileServiceTest");
    gdMessage.setMicroserviceMethod("getCustomerProfileTest");
    gdMessage.getTags().put(KEY_PARTY_ID, "partyIdTest");
    AuditLogsService auditLogsService = new AuditLogsService();
    auditLogsService.setAuditRouteHelper(auditRouteHelper);
    Mockito.doNothing().when(auditRouteHelper).sendGroupDigitalMessageForAuditing(Mockito.any(), Mockito.any());
    auditLogsService.audit(gdMessage);
  }

}
