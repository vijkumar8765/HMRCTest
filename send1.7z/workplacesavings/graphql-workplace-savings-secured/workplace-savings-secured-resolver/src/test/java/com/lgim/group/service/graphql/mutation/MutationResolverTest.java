package com.lgim.group.service.graphql.mutation;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lgim.group.service.graphql.dto.*;
import com.lgim.group.service.graphql.service.WorkplaceSavingsService;
import com.lgim.group.service.graphql.util.JourneyIdExtractor;
import com.lgim.group.service.graphql.util.JwtTokenExtractor;
import graphql.GraphQLException;
import graphql.schema.DataFetchingEnvironment;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.UUID;

@RunWith(SpringRunner.class)
public class MutationResolverTest {

  @Rule
  public ExpectedException expectedException = ExpectedException.none();
  @InjectMocks
  private MutationResolver mutationResolver = new MutationResolver();
  private WorkplacePensionInputDto workplacePensionInputDto;
  private String policyNumber = "12345";
  private FundsInBasketInputDto fundsInBasketInputDto = new FundsInBasketInputDto();
  private String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI5c0JRSTUtMDZLVldNUnJyMEg2dWdfaEhIbXA5a3VQUndQN3o4cGtUcWgwIn0.eyJqdGkiOiJmNmM3OGU2My1kZDAxLTRjY2ItODNkMy04NjhjMzUwM2U4ODkiLCJleHAiOjE1MjE4MDUyMjAsIm5iZiI6MCwiaWF0IjoxNTIxODA0OTIwLCJpc3MiOiJodHRwczovL3NlY3VyZS1zc28tYWpiLXJodC1zc28uYXBwcy5uYTEub3BlbnNoaWZ0Lm9wZW50bGMuY29tL2F1dGgvcmVhbG1zL3JodF9ncHRlXzNzY2FsZV9yZWFsbSIsImF1ZCI6ImN1cmxDbGllbnQiLCJzdWIiOiIzNmZiZTBiNi04OTI3LTQ4YzItOTc0NS1jZmY5MmFkODgwYTUiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJjdXJsQ2xpZW50IiwiYXV0aF90aW1lIjowLCJzZXNzaW9uX3N0YXRlIjoiOTI0YzgyNmMtZTJlZi00NDZhLTgyMzctZDY1NTczNDcyOTQ3IiwiYWNyIjoiMSIsImNsaWVudF9zZXNzaW9uIjoiM2Y2MDExNTMtMmY2YS00YjAzLWEzNTQtMTI4ODFjN2UwYzFmIiwiYWxsb3dlZC1vcmlnaW5zIjpbXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbInVtYV9hdXRob3JpemF0aW9uIiwic3dhcm1Sb2xlIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsInZpZXctcHJvZmlsZSJdfX0sIm5hbWUiOiIiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJzd2FybV9kZXYifQ.JkSg7CmTDreA-gEyS88LWcQbiEYRMZS869DiwcCHGxX9DM4AcSKFSbJa1gLhJYygaCNPZm69ySds35eDNyBJHnc5lfFA9rdvDAVFUz4ypxA0ZmpKJiFqsNYmoGSMlVhaCHZcUhbdcRBg6fMsAmkJJ_cQ0wrK1bBiUD03IGsuZW6ojG_RE99V5t3lI1x3T8ITAl7uFmbFYwtPvosZJoYhWazWwPQz0CxgyVLeLi-lNI0U79ZPfIg06h1KfXuIgM2nClOaO9zY1LY1u7H5bbOBbxdF-nTfyclQ5QIC4-dPKk2AZmQ7Djc6FUisPaRffyX1LxlzkrPYP4liVdTn2YEQVQ";
  private String journeyId = generateUuid();

  @Mock
  private DataFetchingEnvironment environment;

  @Mock
  private JwtTokenExtractor jwtTokenExtractor;

  @Mock
  private JourneyIdExtractor journeyIdExtractor;

  @Mock
  private WorkplaceSavingsService workplaceSavingsService;

  private WorkplacePensionSwitchAndRedirectOrderResponseDto workplacePensionSwitchAndRedirectOrderResponseDto;

  @Before
  public void setUp() {
    workplacePensionInputDto = WorkplacePensionInputDto.builder()
        .benefitsFutureContributions(Arrays.asList(BenefitInputDto.builder().concatBenefitSequenceId("seq_123").build()))
        .benefitsHoldings(Arrays.asList(BenefitInputDto.builder().concatBenefitSequenceId("seq_456").build()))
        .emailAddress("abc.xyz.com").build();

    workplacePensionSwitchAndRedirectOrderResponseDto = WorkplacePensionSwitchAndRedirectOrderResponseDto.builder()
        .wipResponse(WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto.builder().permittedByScheme(false).noPostalAddress(true).build())
        .outcome(Outcome.SUCCESS)
        .build();
  }

  @Test
  public void testWorkplacePensionSwitchAndRedirectOrder() throws Exception {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.processWorkplacePensionSwitchAndRedirectOrder(policyNumber, workplacePensionInputDto, jwtToken,journeyId)).thenReturn(workplacePensionSwitchAndRedirectOrderResponseDto);

    WorkplacePensionSwitchAndRedirectOrderResponseDto result = mutationResolver.workplacePensionSwitchAndRedirectOrder(policyNumber, workplacePensionInputDto, environment);
    Assert.assertEquals(workplacePensionSwitchAndRedirectOrderResponseDto, result);
  }

  @Test
  public void shouldThrowExceptionForWorkplacePensionSwitchAndRedirectOrder() throws Exception {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.processWorkplacePensionSwitchAndRedirectOrder(policyNumber, workplacePensionInputDto, jwtToken,journeyId)).thenThrow(new RuntimeException("Refused to connect!"));
    expectedException.expect(GraphQLException.class);

    WorkplacePensionSwitchAndRedirectOrderResponseDto result = mutationResolver.workplacePensionSwitchAndRedirectOrder(policyNumber, workplacePensionInputDto, environment);
    Assert.assertNull(result);
  }

  @Test
  public void testForWorkplacePensionSaveBasketReturnSuccess() {

    Outcome result = mutationResolver.workplacePensionSaveBasket(policyNumber, BasketType.CONTRIBUTIONS, fundsInBasketInputDto);
    assertEquals(Outcome.SUCCESS.ordinal(), result.ordinal());
  }
  private String generateUuid() {
    return UUID.randomUUID().toString();
  }

}