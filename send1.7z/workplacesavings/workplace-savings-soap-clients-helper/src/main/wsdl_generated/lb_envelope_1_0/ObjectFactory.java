
package lb_envelope_1_0;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the lb_envelope_1_0 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: lb_envelope_1_0
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DGRequestEnvelope }
     * 
     */
    public DGRequestEnvelope createDGRequestEnvelope() {
        return new DGRequestEnvelope();
    }

    /**
     * Create an instance of {@link DGFailure }
     * 
     */
    public DGFailure createDGFailure() {
        return new DGFailure();
    }

    /**
     * Create an instance of {@link DGStackTrace }
     * 
     */
    public DGStackTrace createDGStackTrace() {
        return new DGStackTrace();
    }

    /**
     * Create an instance of {@link DGException }
     * 
     */
    public DGException createDGException() {
        return new DGException();
    }

    /**
     * Create an instance of {@link DGFailureList }
     * 
     */
    public DGFailureList createDGFailureList() {
        return new DGFailureList();
    }

    /**
     * Create an instance of {@link DGCICSFailure }
     * 
     */
    public DGCICSFailure createDGCICSFailure() {
        return new DGCICSFailure();
    }

    /**
     * Create an instance of {@link DGInputStatus }
     * 
     */
    public DGInputStatus createDGInputStatus() {
        return new DGInputStatus();
    }

    /**
     * Create an instance of {@link DGResponseEnvelope }
     * 
     */
    public DGResponseEnvelope createDGResponseEnvelope() {
        return new DGResponseEnvelope();
    }

    /**
     * Create an instance of {@link DGTSQControl }
     * 
     */
    public DGTSQControl createDGTSQControl() {
        return new DGTSQControl();
    }

}
