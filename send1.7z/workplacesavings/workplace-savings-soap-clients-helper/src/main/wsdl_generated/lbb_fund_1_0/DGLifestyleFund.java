
package lbb_fund_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_LifestyleFund complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_LifestyleFund"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="lifestyleFundId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="lifestyleFundName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_LifestyleFund", propOrder = {
    "lifestyleFundId",
    "lifestyleFundName"
})
@ToString
@EqualsAndHashCode
public class DGLifestyleFund implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String lifestyleFundId;
    protected String lifestyleFundName;

    /**
     * Gets the value of the lifestyleFundId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLifestyleFundId() {
        return lifestyleFundId;
    }

    /**
     * Sets the value of the lifestyleFundId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLifestyleFundId(String value) {
        this.lifestyleFundId = value;
    }

    /**
     * Gets the value of the lifestyleFundName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLifestyleFundName() {
        return lifestyleFundName;
    }

    /**
     * Sets the value of the lifestyleFundName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLifestyleFundName(String value) {
        this.lifestyleFundName = value;
    }

}
