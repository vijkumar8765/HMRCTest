package com.lgim.group.service.graphql.util;

import graphql.schema.DataFetchingEnvironment;
import graphql.servlet.GraphQLContext;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;

@Component(value = "jwtTokenExtractor")
@Profile("!graphiql")
public class JwtTokenExtractorImpl implements JwtTokenExtractor {

  @Override
  public String extractJwtToken(DataFetchingEnvironment environment) {
    return ((GraphQLContext) environment.getContext()).getRequest()
        .map(request -> request.getHeader(AUTHORISATION_HEADER_NAME))
        .filter(jwtToken -> !StringUtils.isEmpty(jwtToken) && jwtToken.startsWith("Bearer "))
        .orElseThrow(() -> new HttpServerErrorException(HttpStatus.UNAUTHORIZED, "UNAUTHORIZED: Jwt Token is not provided or is empty!"));
  }

}


