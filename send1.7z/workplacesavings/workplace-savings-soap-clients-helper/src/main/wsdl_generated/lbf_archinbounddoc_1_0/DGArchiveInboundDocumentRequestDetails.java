
package lbf_archinbounddoc_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lbb_communication_1.DGBusinessIndex;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_ArchiveInboundDocumentRequestDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_ArchiveInboundDocumentRequestDetails"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="businessIndicies" type="{http://LBB_Communication_1}DG_BusinessIndex" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="documents" type="{http://LBF_ArchInboundDoc_1_0}DG_ArchiveDocumentDetails" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_ArchiveInboundDocumentRequestDetails", propOrder = {
    "businessIndicies",
    "documents"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGArchiveInboundDocumentRequestDetails
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected List<DGBusinessIndex> businessIndicies;
    protected List<DGArchiveDocumentDetails> documents;

    /**
     * Gets the value of the businessIndicies property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the businessIndicies property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBusinessIndicies().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGBusinessIndex }
     * 
     * 
     */
    public List<DGBusinessIndex> getBusinessIndicies() {
        if (businessIndicies == null) {
            businessIndicies = new ArrayList<DGBusinessIndex>();
        }
        return this.businessIndicies;
    }

    /**
     * Gets the value of the documents property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documents property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocuments().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGArchiveDocumentDetails }
     * 
     * 
     */
    public List<DGArchiveDocumentDetails> getDocuments() {
        if (documents == null) {
            documents = new ArrayList<DGArchiveDocumentDetails>();
        }
        return this.documents;
    }

}
