
package lbb_acct_b_1_0;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_InvestedHoldings complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_InvestedHoldings"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="holdingClassCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="holdingClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="holdingManager" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="holdingName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="noOfUnits" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="unitCurrentPrice" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="valuation" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="valuationDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="mexCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="epiCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_InvestedHoldings", propOrder = {
    "holdingClassCode",
    "holdingClass",
    "holdingManager",
    "holdingName",
    "noOfUnits",
    "unitCurrentPrice",
    "valuation",
    "valuationDate",
    "mexCode",
    "epiCode"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAInvestedHoldings
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String holdingClassCode;
    protected String holdingClass;
    protected String holdingManager;
    protected String holdingName;
    protected BigDecimal noOfUnits;
    protected BigDecimal unitCurrentPrice;
    protected BigDecimal valuation;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar valuationDate;
    protected String mexCode;
    protected String epiCode;

    /**
     * Gets the value of the holdingClassCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldingClassCode() {
        return holdingClassCode;
    }

    /**
     * Sets the value of the holdingClassCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldingClassCode(String value) {
        this.holdingClassCode = value;
    }

    /**
     * Gets the value of the holdingClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldingClass() {
        return holdingClass;
    }

    /**
     * Sets the value of the holdingClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldingClass(String value) {
        this.holdingClass = value;
    }

    /**
     * Gets the value of the holdingManager property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldingManager() {
        return holdingManager;
    }

    /**
     * Sets the value of the holdingManager property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldingManager(String value) {
        this.holdingManager = value;
    }

    /**
     * Gets the value of the holdingName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldingName() {
        return holdingName;
    }

    /**
     * Sets the value of the holdingName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldingName(String value) {
        this.holdingName = value;
    }

    /**
     * Gets the value of the noOfUnits property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNoOfUnits() {
        return noOfUnits;
    }

    /**
     * Sets the value of the noOfUnits property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNoOfUnits(BigDecimal value) {
        this.noOfUnits = value;
    }

    /**
     * Gets the value of the unitCurrentPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getUnitCurrentPrice() {
        return unitCurrentPrice;
    }

    /**
     * Sets the value of the unitCurrentPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setUnitCurrentPrice(BigDecimal value) {
        this.unitCurrentPrice = value;
    }

    /**
     * Gets the value of the valuation property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getValuation() {
        return valuation;
    }

    /**
     * Sets the value of the valuation property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setValuation(BigDecimal value) {
        this.valuation = value;
    }

    /**
     * Gets the value of the valuationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getValuationDate() {
        return valuationDate;
    }

    /**
     * Sets the value of the valuationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setValuationDate(XMLGregorianCalendar value) {
        this.valuationDate = value;
    }

    /**
     * Gets the value of the mexCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMexCode() {
        return mexCode;
    }

    /**
     * Sets the value of the mexCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMexCode(String value) {
        this.mexCode = value;
    }

    /**
     * Gets the value of the epiCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEpiCode() {
        return epiCode;
    }

    /**
     * Sets the value of the epiCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEpiCode(String value) {
        this.epiCode = value;
    }

}
