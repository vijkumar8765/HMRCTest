
package lbb_communicationcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_UKPostalAddress complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_UKPostalAddress"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LBB_CommunicationCommon_1_0}DG_PostalAddress"&gt;
 *       &lt;sequence&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_UKPostalAddress")
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGUKPostalAddress
    extends DGPostalAddress
    implements Serializable
{

    private final static long serialVersionUID = 1L;

}
