
package lbb_personretrieve_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGResponseEnvelope;
import lbb_personcommon_1_0.DGPerson;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_PersonRetrieveResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_PersonRetrieveResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_ResponseEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="personDetails" type="{http://LBB_PersonCommon_1_0}DG_Person" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_PersonRetrieveResponse", propOrder = {
    "personDetails"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGPersonRetrieveResponse
    extends DGResponseEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGPerson personDetails;

    /**
     * Gets the value of the personDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGPerson }
     *     
     */
    public DGPerson getPersonDetails() {
        return personDetails;
    }

    /**
     * Sets the value of the personDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPerson }
     *     
     */
    public void setPersonDetails(DGPerson value) {
        this.personDetails = value;
    }

}
