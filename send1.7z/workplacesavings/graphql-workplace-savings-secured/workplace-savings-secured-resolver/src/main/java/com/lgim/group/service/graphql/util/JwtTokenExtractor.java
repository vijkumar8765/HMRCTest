package com.lgim.group.service.graphql.util;

import graphql.schema.DataFetchingEnvironment;

public interface JwtTokenExtractor {

  String AUTHORISATION_HEADER_NAME = "Authorization";

  String extractJwtToken(DataFetchingEnvironment environment);

}
