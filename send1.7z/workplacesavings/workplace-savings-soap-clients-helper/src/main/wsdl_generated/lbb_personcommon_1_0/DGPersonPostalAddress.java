
package lbb_personcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lbb_communicationcommon_1_0.DGPostalAddress;
import lbb_partycommon_1_0.DGPartyAddressUsage;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_PersonPostalAddress complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_PersonPostalAddress"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="address" type="{http://LBB_CommunicationCommon_1_0}DG_PostalAddress" minOccurs="0"/&gt;
 *         &lt;element name="mailingName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="mailingSalutation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="privateAndConfidential" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="ukIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="addressId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="addressType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="addressStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="partyAddressUsage" type="{http://LBB_PartyCommon_1_0}DG_PartyAddressUsage" minOccurs="0"/&gt;
 *         &lt;element name="applicableDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_PersonPostalAddress", propOrder = {
    "address",
    "mailingName",
    "mailingSalutation",
    "privateAndConfidential",
    "ukIndicator",
    "addressId",
    "addressType",
    "addressStatus",
    "partyAddressUsage",
    "applicableDate"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGPersonPostalAddress
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGPostalAddress address;
    protected String mailingName;
    protected String mailingSalutation;
    protected Boolean privateAndConfidential;
    protected Boolean ukIndicator;
    protected String addressId;
    protected String addressType;
    protected String addressStatus;
    protected DGPartyAddressUsage partyAddressUsage;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar applicableDate;

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link DGPostalAddress }
     *     
     */
    public DGPostalAddress getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPostalAddress }
     *     
     */
    public void setAddress(DGPostalAddress value) {
        this.address = value;
    }

    /**
     * Gets the value of the mailingName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailingName() {
        return mailingName;
    }

    /**
     * Sets the value of the mailingName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailingName(String value) {
        this.mailingName = value;
    }

    /**
     * Gets the value of the mailingSalutation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailingSalutation() {
        return mailingSalutation;
    }

    /**
     * Sets the value of the mailingSalutation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailingSalutation(String value) {
        this.mailingSalutation = value;
    }

    /**
     * Gets the value of the privateAndConfidential property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPrivateAndConfidential() {
        return privateAndConfidential;
    }

    /**
     * Sets the value of the privateAndConfidential property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPrivateAndConfidential(Boolean value) {
        this.privateAndConfidential = value;
    }

    /**
     * Gets the value of the ukIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isUkIndicator() {
        return ukIndicator;
    }

    /**
     * Sets the value of the ukIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setUkIndicator(Boolean value) {
        this.ukIndicator = value;
    }

    /**
     * Gets the value of the addressId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressId() {
        return addressId;
    }

    /**
     * Sets the value of the addressId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressId(String value) {
        this.addressId = value;
    }

    /**
     * Gets the value of the addressType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressType() {
        return addressType;
    }

    /**
     * Sets the value of the addressType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressType(String value) {
        this.addressType = value;
    }

    /**
     * Gets the value of the addressStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressStatus() {
        return addressStatus;
    }

    /**
     * Sets the value of the addressStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressStatus(String value) {
        this.addressStatus = value;
    }

    /**
     * Gets the value of the partyAddressUsage property.
     * 
     * @return
     *     possible object is
     *     {@link DGPartyAddressUsage }
     *     
     */
    public DGPartyAddressUsage getPartyAddressUsage() {
        return partyAddressUsage;
    }

    /**
     * Sets the value of the partyAddressUsage property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPartyAddressUsage }
     *     
     */
    public void setPartyAddressUsage(DGPartyAddressUsage value) {
        this.partyAddressUsage = value;
    }

    /**
     * Gets the value of the applicableDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getApplicableDate() {
        return applicableDate;
    }

    /**
     * Sets the value of the applicableDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setApplicableDate(XMLGregorianCalendar value) {
        this.applicableDate = value;
    }

}
