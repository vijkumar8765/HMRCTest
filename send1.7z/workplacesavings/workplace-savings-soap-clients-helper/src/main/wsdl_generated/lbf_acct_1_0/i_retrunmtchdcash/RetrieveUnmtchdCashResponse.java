
package lbf_acct_1_0.i_retrunmtchdcash;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import lbf_acct_1_0.DGRetrUnmtchdCashResponse;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="resp" type="{http://LBF_Acct_1_0}DG_RetrUnmtchdCashResponse"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "resp"
})
@XmlRootElement(name = "retrieveUnmtchdCashResponse")
@ToString
@EqualsAndHashCode
public class RetrieveUnmtchdCashResponse implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(required = true, nillable = true)
    protected DGRetrUnmtchdCashResponse resp;

    /**
     * Gets the value of the resp property.
     * 
     * @return
     *     possible object is
     *     {@link DGRetrUnmtchdCashResponse }
     *     
     */
    public DGRetrUnmtchdCashResponse getResp() {
        return resp;
    }

    /**
     * Sets the value of the resp property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGRetrUnmtchdCashResponse }
     *     
     */
    public void setResp(DGRetrUnmtchdCashResponse value) {
        this.resp = value;
    }

}
