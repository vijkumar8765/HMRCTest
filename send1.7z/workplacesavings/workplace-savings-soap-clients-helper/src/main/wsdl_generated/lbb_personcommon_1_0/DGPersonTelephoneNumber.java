
package lbb_personcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_PersonTelephoneNumber complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_PersonTelephoneNumber"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="telephoneNumber" type="{http://LBB_CommunicationCommon_1_0}DG_TelephoneNumber" minOccurs="0"/&gt;
 *         &lt;element name="telephoneNumberType" type="{http://LBB_PersonCommon_1_0}DG_TelephoneNumberType" minOccurs="0"/&gt;
 *         &lt;element name="occurance" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_PersonTelephoneNumber", propOrder = {
    "telephoneNumber",
    "telephoneNumberType",
    "occurance"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGPersonTelephoneNumber
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String telephoneNumber;
    protected String telephoneNumberType;
    protected Integer occurance;

    /**
     * Gets the value of the telephoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    /**
     * Sets the value of the telephoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelephoneNumber(String value) {
        this.telephoneNumber = value;
    }

    /**
     * Gets the value of the telephoneNumberType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelephoneNumberType() {
        return telephoneNumberType;
    }

    /**
     * Sets the value of the telephoneNumberType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelephoneNumberType(String value) {
        this.telephoneNumberType = value;
    }

    /**
     * Gets the value of the occurance property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getOccurance() {
        return occurance;
    }

    /**
     * Sets the value of the occurance property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setOccurance(Integer value) {
        this.occurance = value;
    }

}
