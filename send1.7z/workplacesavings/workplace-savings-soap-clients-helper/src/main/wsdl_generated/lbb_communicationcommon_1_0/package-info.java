@javax.xml.bind.annotation.XmlSchema(namespace = "http://LBB_CommunicationCommon_1_0")
package lbb_communicationcommon_1_0;
