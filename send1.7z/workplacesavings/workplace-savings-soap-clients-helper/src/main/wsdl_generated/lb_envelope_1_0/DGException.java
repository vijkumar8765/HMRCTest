
package lb_envelope_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_Exception complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_Exception"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_Failure"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="cause" type="{http://LB_Envelope_1_0}DG_Exception" minOccurs="0"/&gt;
 *         &lt;element name="stackTrace" type="{http://LB_Envelope_1_0}DG_StackTrace" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_Exception", propOrder = {
    "cause",
    "stackTrace"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGException
    extends DGFailure
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGException cause;
    protected List<DGStackTrace> stackTrace;

    /**
     * Gets the value of the cause property.
     * 
     * @return
     *     possible object is
     *     {@link DGException }
     *     
     */
    public DGException getCause() {
        return cause;
    }

    /**
     * Sets the value of the cause property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGException }
     *     
     */
    public void setCause(DGException value) {
        this.cause = value;
    }

    /**
     * Gets the value of the stackTrace property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stackTrace property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStackTrace().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGStackTrace }
     * 
     * 
     */
    public List<DGStackTrace> getStackTrace() {
        if (stackTrace == null) {
            stackTrace = new ArrayList<DGStackTrace>();
        }
        return this.stackTrace;
    }

}
