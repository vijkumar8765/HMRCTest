
package lbf_party_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_RetrRelsForAuthCheckSearchCriteria complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_RetrRelsForAuthCheckSearchCriteria"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="partyId1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="partyId2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_RetrRelsForAuthCheckSearchCriteria", propOrder = {
    "partyId1",
    "partyId2"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGRetrRelsForAuthCheckSearchCriteria
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String partyId1;
    protected String partyId2;

    /**
     * Gets the value of the partyId1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId1() {
        return partyId1;
    }

    /**
     * Sets the value of the partyId1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId1(String value) {
        this.partyId1 = value;
    }

    /**
     * Gets the value of the partyId2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId2() {
        return partyId2;
    }

    /**
     * Sets the value of the partyId2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId2(String value) {
        this.partyId2 = value;
    }

}
