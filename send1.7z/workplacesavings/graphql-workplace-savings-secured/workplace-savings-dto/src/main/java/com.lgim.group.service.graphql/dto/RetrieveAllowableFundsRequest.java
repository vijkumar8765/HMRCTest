package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class RetrieveAllowableFundsRequest implements java.io.Serializable {

  private String policyNumber;

  private String schemeCategory;

  private String schemeId;

  private String productId;

  public RetrieveAllowableFundsRequest(String policyNumber, String schemeCategory, String schemeId, String productId) {
    this.policyNumber = policyNumber;
    this.schemeCategory = schemeCategory;
    this.schemeId = schemeId;
    this.productId = productId;
  }
}
