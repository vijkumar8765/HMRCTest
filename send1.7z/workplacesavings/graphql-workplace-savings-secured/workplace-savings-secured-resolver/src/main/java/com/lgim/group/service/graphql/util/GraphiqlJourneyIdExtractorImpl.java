package com.lgim.group.service.graphql.util;

import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component(value = "journeyIdExtractor")
@Profile("graphiql")
public class GraphiqlJourneyIdExtractorImpl implements JourneyIdExtractor {

  @Value("${graphiql.journey.id}")
  private String graphiqlJourneyId;

  @Override
  public String extractJourneyId(DataFetchingEnvironment environment) {
    return graphiqlJourneyId;
  }
}
