package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
public class BenefitDto implements java.io.Serializable {
  // This is benefitId + sequence number as a string
  private String concatBenefitSequenceId;
  private List<WorkplacePensionHoldingDto> holdings;
  private BenefitType type;

  public BenefitDto(String concatBenefitSequenceId, List<WorkplacePensionHoldingDto> holdings, BenefitType type) {
    this.concatBenefitSequenceId = concatBenefitSequenceId;
    this.holdings = holdings;
    this.type = type;
  }
}
