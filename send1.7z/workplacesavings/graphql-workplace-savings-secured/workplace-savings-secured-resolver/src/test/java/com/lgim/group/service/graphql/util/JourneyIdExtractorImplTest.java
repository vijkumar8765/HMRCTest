package com.lgim.group.service.graphql.util;

import graphql.schema.DataFetchingEnvironment;
import graphql.servlet.GraphQLContext;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpServerErrorException;

import javax.servlet.http.HttpServletRequest;
import java.util.Optional;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class JourneyIdExtractorImplTest {


  @InjectMocks
  JourneyIdExtractor journeyIdExtractor = new JourneyIdExtractorImpl();

  @Mock
  DataFetchingEnvironment environment;

  @Mock
  GraphQLContext graphQLContext;

  @Mock
  HttpServletRequest request;

  String journeyId = generateUuid();

  @Rule
  public ExpectedException expectedException = ExpectedException.none();

  @Before
  public void setUp() throws Exception {

  }

  @Test
  public void testJourneyIdIsExtractedWhenPresent() {
    when(environment.getContext()).thenReturn(graphQLContext);
    when(graphQLContext.getRequest()).thenReturn(Optional.of(request));
    when(request.getAttribute("journeyId")).thenReturn(journeyId);

    assertEquals(journeyId, journeyIdExtractor.extractJourneyId(environment));
  }

  @Test
  public void testExceptionThrownWhenRequestNotPresent() {
    when(environment.getContext()).thenReturn(graphQLContext);
    when(graphQLContext.getRequest()).thenReturn(Optional.of(request));
    when(request.getAttribute("journeyId")).thenReturn("");

    expectedException.expect(HttpServerErrorException.class);

    expectedException.expectMessage(HttpStatus.BAD_REQUEST + "  JourneyId is not provided or is empty!");

    assertNull(journeyIdExtractor.extractJourneyId(environment));
  }

  @Test
  public void testExceptionThrownWhenJourneyIdIsNull() {
    when(environment.getContext()).thenReturn(graphQLContext);
    when(graphQLContext.getRequest()).thenReturn(Optional.of(request));
    when(request.getAttribute("journeyId")).thenReturn("");

    expectedException.expect(HttpServerErrorException.class);

    expectedException.expectMessage(HttpStatus.BAD_REQUEST + "  JourneyId is not provided or is empty!");

    assertNull(journeyIdExtractor.extractJourneyId(environment));
  }

  @Test
  public void testExceptionThrownWhenJourneyIdTokenIsEmpty() {
    when(environment.getContext()).thenReturn(graphQLContext);
    when(graphQLContext.getRequest()).thenReturn(Optional.of(request));
    when(request.getAttribute("journeyId")).thenReturn("");

    expectedException.expect(HttpServerErrorException.class);

    expectedException.expectMessage(HttpStatus.BAD_REQUEST + "  JourneyId is not provided or is empty!");

    assertNull(journeyIdExtractor.extractJourneyId(environment));
  }


  private String generateUuid() {
    return UUID.randomUUID().toString();
  }

}

