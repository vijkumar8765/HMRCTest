
package lbf_person_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGResponseEnvelope;
import lbb_personlocate_1_0.DGLocatedPerson;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_RetrPersonSmryResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_RetrPersonSmryResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_ResponseEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="locatedPerson" type="{http://LBB_PersonLocate_1_0}DG_LocatedPerson" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="tooManyRows" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_RetrPersonSmryResponse", propOrder = {
    "locatedPerson",
    "tooManyRows"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGRetrPersonSmryResponse
    extends DGResponseEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected List<DGLocatedPerson> locatedPerson;
    protected Boolean tooManyRows;

    /**
     * Gets the value of the locatedPerson property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the locatedPerson property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLocatedPerson().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGLocatedPerson }
     * 
     * 
     */
    public List<DGLocatedPerson> getLocatedPerson() {
        if (locatedPerson == null) {
            locatedPerson = new ArrayList<DGLocatedPerson>();
        }
        return this.locatedPerson;
    }

    /**
     * Gets the value of the tooManyRows property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTooManyRows() {
        return tooManyRows;
    }

    /**
     * Sets the value of the tooManyRows property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTooManyRows(Boolean value) {
        this.tooManyRows = value;
    }

}
