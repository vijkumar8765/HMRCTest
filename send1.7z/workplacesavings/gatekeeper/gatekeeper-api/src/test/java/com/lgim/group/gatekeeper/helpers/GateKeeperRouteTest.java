package com.lgim.group.gatekeeper.helpers;

import com.lgim.group.gatekeeper.exception.JwtAuthenticationException;
import com.lgim.group.gatekeeper.processor.ProxyRequestProcessor;
import com.lgim.group.gatekeeper.route.PublicKeyCollectorRoute;
import org.apache.camel.Exchange;
import org.apache.camel.builder.NotifyBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import com.lgim.group.gatekeeper.route.GatekeeperRoute;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.common.ClasspathFileSource;
import com.github.tomakehurst.wiremock.common.FileSource;
import com.github.tomakehurst.wiremock.junit.WireMockRule;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource(locations = "classpath:functionalTest.properties")
public class GateKeeperRouteTest extends CamelTestSupport {

    private final String URL = "/auth/realms/dcp-d00/.well-known/openid-configuration";

    private final String FILE_FOR_TEST_01 = "resp_test01_success.json";

    private final String AUTHORIZATION_HEADER = "Authorization";

    private final String USER1_TOKEN="Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIxUWhMOEVUOFVBNXhYSGlkSVVuZ3JIbWFIOTdYNTdrNm9INGpDZW9TRkRVIn0.eyJqdGkiOiIxNmQ3N2ExOC05MzNhLTQ5MGEtOWRmZC04Mzk2NTY4MmVlYTMiLCJleHAiOjE1NDE0MTM4MzIsIm5iZiI6MCwiaWF0IjoxNTQxNDEwMjMyLCJpc3MiOiJodHRwczovL2xnaW0tc3NvLW5vbnByb2QubnAub3BlbnNoaWZ0Lmludi5hZHJvb3QubGdpbS5jb20vYXV0aC9yZWFsbXMvZGNwLWQwMCIsImF1ZCI6ImIyZjc2ZGVkIiwic3ViIjoiN2M4MjVhZDItNDRjMy00NTczLWI5NmEtNjcyYjZjZjIwYTE0IiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiYjJmNzZkZWQiLCJhdXRoX3RpbWUiOjAsInNlc3Npb25fc3RhdGUiOiIzOTQ2OTc0Zi1jMWViLTQzNzgtYmU1Ny0xOGM3NjYzMjBjZTEiLCJhY3IiOiIxIiwiYWxsb3dlZC1vcmlnaW5zIjpbIioiXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbInVtYV9hdXRob3JpemF0aW9uIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fSwicHJlZmVycmVkX3VzZXJuYW1lIjoidGVzdDIwNDk0NTYwMzEiLCJwYXJ0eUlkIjoiQkJRWTNOWlkwIn0.BwqIE30EH9umYZpY8C-GSWhcnLe2TbudHchGZTN6NyGq2dv3Q5XHc3sdLYW3Em0mX5DMdI4ctlUjyE8yW8iScQB0R0LhLVySa2YR7XcIItA50RPeTCx-udTurB4RTyZYpHlMQhrYHwvQkZqordSdcWE79q1C9YtR0Vk9nDqHSNPnx1LpHSdXcCm9_nftdlbAwK-qmXnaiP1qkUTJQnS9y0d1ysLZZThYZwCKkTgBunK7GFHG3b4ADEkvh-03Xvzi-w-VcSuV5KJv1MB5DBr-xUv-HOcKoiYcCBsStE89p1pNuFg7BaSsWJxUQJl9vBQfvnj_GClE9KSgU1siIlJqgQ";

    private final String USER1_PARTY_ID="BBQY3NZY0";

    private final String EXPIRED_TOKEN="Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIxUWhMOEVUOFVBNXhYSGlkSVVuZ3JIbWFIOTdYNTdrNm9INGpDZW9TRkRVIn0.eyJqdGkiOiI2M2JlMDk5ZC03ZGE4LTRhMWEtOGY1MS1kNGY0ZGQ5MzliZDUiLCJleHAiOjE1MzQ5NDkxNDUsIm5iZiI6MCwiaWF0IjoxNTM0OTQ2MTQ1LCJpc3MiOiJodHRwczovL2xnaW0tc3NvLW5vbnByb2QubnAub3BlbnNoaWZ0Lmludi5hZHJvb3QubGdpbS5jb20vYXV0aC9yZWFsbXMvZGNwLWQwMCIsImF1ZCI6ImIyZjc2ZGVkIiwic3ViIjoiOTcwM2NlNWMtNjE0OS00ZmU4LWE0NDctZGQwNGJjNWQ0MjMzIiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiYjJmNzZkZWQiLCJhdXRoX3RpbWUiOjAsInNlc3Npb25fc3RhdGUiOiI1NTY2OWY0Ni0xYTIxLTQ0YmEtOTk4Ni0xZTY3ZDBlOGU3ZDUiLCJhY3IiOiIxIiwiYWxsb3dlZC1vcmlnaW5zIjpbIioiXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbInVtYV9hdXRob3JpemF0aW9uIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fSwibmFtZSI6ImFhYSBhYWEiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJkY3Atc3ItdGVzdC11c2VyLTEiLCJnaXZlbl9uYW1lIjoiYWFhIiwiZmFtaWx5X25hbWUiOiJhYWEifQ.cCO2CbFQOjonScmkdDoSGrWVKLxoBLerZCqDopNgWYJv0k_plmhQ_sMi4OUQGfPXHiQORGJaDNVL980JKsgExWxVyihq00e-Y8qXg_1wAJT8QPNoPSymqIFvJTIWNJlMNLZaT4GUqO1VfpzZYoX30lfrPfFFUgtw6fE2_v9RcKUGl3vD92y9mDbxaT_dVp5WYlPnz2hJjv7zkB7vqgmzRi5oJWuISar4x1XeHjABQVObzAxyIsnX3mSXZ3ix4LqLn8KmUaHoIrEUfUuVWypWuuGNBK3mg30z43_22CF6EgYe_wBV7L8lhZ0ui5xE5393vlgSlTwQL-jeVnqXmHroWg";

    private final String INVALID_ISSUER="Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICIxUWhMOEVUOFVBNXhYSGlkSVVuZ3JIbWFIOTdYNTdrNm9INGpDZW9TRkRVIn0.eyJqdGkiOiJjNzU5MDJhNi1kYzc5LTQ3YjgtYTJmOC1kMTU0M2YwMDA0OWIiLCJleHAiOjE1NDE0MzQzMjksIm5iZiI6MCwiaWF0IjoxNTQxNDMwNzI5LCJpc3MiOiJodHRwOi8vc3NvLWludGVybmFsLm5wLm9wZW5zaGlmdC5pbnYuYWRyb290LmxnaW0uY29tL2F1dGgvcmVhbG1zL2RjcC1kMDAiLCJhdWQiOiJiMmY3NmRlZCIsInN1YiI6IjNjNWY5MjA2LTIxNDctNGJmOC1hNjY0LTNlNWU5YjNhZjkxZSIsInR5cCI6IkJlYXJlciIsImF6cCI6ImIyZjc2ZGVkIiwiYXV0aF90aW1lIjowLCJzZXNzaW9uX3N0YXRlIjoiMDY2N2M2NGItYzNmZi00MDJiLWE0MTItMjJhZTg0ZTBlMDI5IiwiYWNyIjoiMSIsImFsbG93ZWQtb3JpZ2lucyI6WyIqIl0sInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJ1bWFfYXV0aG9yaXphdGlvbiJdfSwicmVzb3VyY2VfYWNjZXNzIjp7ImFjY291bnQiOnsicm9sZXMiOlsibWFuYWdlLWFjY291bnQiLCJtYW5hZ2UtYWNjb3VudC1saW5rcyIsInZpZXctcHJvZmlsZSJdfX0sInByZWZlcnJlZF91c2VybmFtZSI6InRlc3QyNDIzNTU2MDMxIiwicGFydHlJZCI6IkJCUVk4NFJZMCJ9.QAHS1LpN7vqJGNnCqUjw1vIwlZ9rx25QQ2pG8ndgErLfidUAY9c3_nHnmt0ITBKLtNRLTyleBT30t8wlAy_QIiVxZAzAszoHYySdjwoqZz1n-kYF0ipSQdni_O7fb-anvO4Fm2nF0yefqWCqZN2od1LmCC1TCsj2DOtMHtGTXoUoJx9F4CPI8-Vo-amPTTzrwwFCB_oC4kETqV1axdfTfH03lT-hWw2bI6w5F_w0ZxXtdeM3gTzIjEeVqGnuOuJjvsoVd3AcKR47jvdShLEzWrn_R4vw3IKOnBYWwRlEIgngAtqU5hxFYDx4pWSLKReSYd0jVw3jayU1Yaa2p09fFg";


    @Autowired
    private TestRestTemplate restTemplate;


    @Rule
    public final WireMockRule wireMockRule = new WireMockRule(8083);

    @Before
    public void setup() {

        wireMockRule.resetAll();

        stubFor(post(urlEqualTo(URL))
                .willReturn(aResponse()
                        .withHeader("Cache-Control", "no-cache, no-store, must-revalidate")
                        .withHeader("Pragma", "no-cache")
                        .withHeader("Content-Type", "application/json")
                        .withBodyFile(FILE_FOR_TEST_01)));

        stubFor(get(urlEqualTo(URL))
                .willReturn(aResponse()
                        .withHeader("Cache-Control", "no-cache, no-store, must-revalidate")
                        .withHeader("Pragma", "no-cache")
                        .withHeader("Content-Type", "application/json")
                        .withBodyFile(FILE_FOR_TEST_01)));


    }


    @Test
    public void TestValidGatekeeperRequest()
    {
        NotifyBuilder notify = new NotifyBuilder(context).fromRoute(PublicKeyCollectorRoute.ROUTE_ID).whenDone(1).create();
        boolean done = notify.matches(5, TimeUnit.SECONDS);

        HttpHeaders headers = new HttpHeaders();
        headers.set(AUTHORIZATION_HEADER,USER1_TOKEN);

        HttpEntity<String> entity = new HttpEntity<>("parameters",headers);

        ResponseEntity<String> response =  restTemplate.exchange("http://localhost:9111/graphql", HttpMethod.POST,entity,String.class);
        assertEquals(200,response.getStatusCode().value());
        assertTrue(response.getBody().startsWith("{\"keys\":"));
    }

    @Test
    public void TestInvalidURLRequest()
    {
        NotifyBuilder notify = new NotifyBuilder(context).fromRoute(PublicKeyCollectorRoute.ROUTE_ID).whenDone(1).create();
        boolean done = notify.matches(5, TimeUnit.SECONDS);

        HttpHeaders headers = new HttpHeaders();
        headers.set(AUTHORIZATION_HEADER,USER1_TOKEN);

        HttpEntity<String> entity = new HttpEntity<>("parameters",headers);

        ResponseEntity<String> response =  restTemplate.exchange("http://localhost:9111/doesNotExist", HttpMethod.POST,entity,String.class);
        assertEquals(404,response.getStatusCode().value());
    }

    @Test
    public void TestExpiredTokenRequest()
    {
        NotifyBuilder notify = new NotifyBuilder(context).fromRoute(PublicKeyCollectorRoute.ROUTE_ID).whenDone(1).create();
        boolean done = notify.matches(5, TimeUnit.SECONDS);

        HttpHeaders headers = new HttpHeaders();
        headers.set(AUTHORIZATION_HEADER,EXPIRED_TOKEN);

        HttpEntity<String> entity = new HttpEntity<>("parameters",headers);

        ResponseEntity<String> response =  restTemplate.exchange("http://localhost:9111/graphql", HttpMethod.POST,entity,String.class);
        assertEquals(401,response.getStatusCode().value());
    }

    @Test
    public void TestInvalidIssuerRequest()
    {
        NotifyBuilder notify = new NotifyBuilder(context).fromRoute(PublicKeyCollectorRoute.ROUTE_ID).whenDone(1).create();
        boolean done = notify.matches(5, TimeUnit.SECONDS);

        HttpHeaders headers = new HttpHeaders();
        headers.set(AUTHORIZATION_HEADER,INVALID_ISSUER);

        HttpEntity<String> entity = new HttpEntity<>("parameters",headers);

        ResponseEntity<String> response =  restTemplate.exchange("http://localhost:9111/graphql", HttpMethod.POST,entity,String.class);
        assertEquals(401,response.getStatusCode().value());
    }

}
