
package lbb_customeralterationorchestration_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGRequestEnvelope;
import lbb_authorise_1_0.DGDataPermission;
import lbb_authorise_1_0.DGDocumentType;
import lbb_authorise_1_0.DGProcessPermission;
import lbb_personcommon_1_0.DGPerson;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_CustomerAlterationOrchestration_Request complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_CustomerAlterationOrchestration_Request"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_RequestEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="subjectPartyId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="requestorPartyId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="userId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="channel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="alteredPerson" type="{http://LBB_PersonCommon_1_0}DG_Person" minOccurs="0"/&gt;
 *         &lt;element name="documentTypes" type="{http://LBB_Authorise_1_0}DG_DocumentType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="dataPermissions" type="{http://LBB_Authorise_1_0}DG_DataPermission" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="processPermissions" type="{http://LBB_Authorise_1_0}DG_ProcessPermission" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_CustomerAlterationOrchestration_Request", propOrder = {
    "subjectPartyId",
    "requestorPartyId",
    "userId",
    "channel",
    "alteredPerson",
    "documentTypes",
    "dataPermissions",
    "processPermissions"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGCustomerAlterationOrchestrationRequest
    extends DGRequestEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String subjectPartyId;
    protected String requestorPartyId;
    protected String userId;
    protected String channel;
    protected DGPerson alteredPerson;
    protected List<DGDocumentType> documentTypes;
    protected List<DGDataPermission> dataPermissions;
    protected List<DGProcessPermission> processPermissions;

    /**
     * Gets the value of the subjectPartyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubjectPartyId() {
        return subjectPartyId;
    }

    /**
     * Sets the value of the subjectPartyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubjectPartyId(String value) {
        this.subjectPartyId = value;
    }

    /**
     * Gets the value of the requestorPartyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestorPartyId() {
        return requestorPartyId;
    }

    /**
     * Sets the value of the requestorPartyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestorPartyId(String value) {
        this.requestorPartyId = value;
    }

    /**
     * Gets the value of the userId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserId(String value) {
        this.userId = value;
    }

    /**
     * Gets the value of the channel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannel() {
        return channel;
    }

    /**
     * Sets the value of the channel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannel(String value) {
        this.channel = value;
    }

    /**
     * Gets the value of the alteredPerson property.
     * 
     * @return
     *     possible object is
     *     {@link DGPerson }
     *     
     */
    public DGPerson getAlteredPerson() {
        return alteredPerson;
    }

    /**
     * Sets the value of the alteredPerson property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPerson }
     *     
     */
    public void setAlteredPerson(DGPerson value) {
        this.alteredPerson = value;
    }

    /**
     * Gets the value of the documentTypes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documentTypes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumentTypes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGDocumentType }
     * 
     * 
     */
    public List<DGDocumentType> getDocumentTypes() {
        if (documentTypes == null) {
            documentTypes = new ArrayList<DGDocumentType>();
        }
        return this.documentTypes;
    }

    /**
     * Gets the value of the dataPermissions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dataPermissions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDataPermissions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGDataPermission }
     * 
     * 
     */
    public List<DGDataPermission> getDataPermissions() {
        if (dataPermissions == null) {
            dataPermissions = new ArrayList<DGDataPermission>();
        }
        return this.dataPermissions;
    }

    /**
     * Gets the value of the processPermissions property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the processPermissions property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProcessPermissions().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGProcessPermission }
     * 
     * 
     */
    public List<DGProcessPermission> getProcessPermissions() {
        if (processPermissions == null) {
            processPermissions = new ArrayList<DGProcessPermission>();
        }
        return this.processPermissions;
    }

}
