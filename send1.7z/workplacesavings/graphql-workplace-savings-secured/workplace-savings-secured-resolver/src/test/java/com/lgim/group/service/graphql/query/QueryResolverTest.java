package com.lgim.group.service.graphql.query;

import static org.mockito.Mockito.when;

import com.google.common.collect.Lists;
import com.lgim.group.service.graphql.dto.BasketType;
import com.lgim.group.service.graphql.dto.BenefitDto;
import com.lgim.group.service.graphql.dto.BenefitType;
import com.lgim.group.service.graphql.dto.FundsInBasketDto;
import com.lgim.group.service.graphql.dto.InvestmentStrategyDto;
import com.lgim.group.service.graphql.dto.LastRegularContributionFrequencyCode;
import com.lgim.group.service.graphql.dto.WorkplacePensionCustomerDetailsDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionFundDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionHoldingDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionHoldingsDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto;
import com.lgim.group.service.graphql.service.WorkplaceSavingsService;
import com.lgim.group.service.graphql.util.JourneyIdExtractor;
import com.lgim.group.service.graphql.util.JwtTokenExtractor;
import graphql.GraphQLException;
import graphql.schema.DataFetchingEnvironment;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpServerErrorException;

@RunWith(MockitoJUnitRunner.class)
public class QueryResolverTest {

  @Rule
  public ExpectedException expectedException = ExpectedException.none();
  @InjectMocks
  QueryResolver queryResolver = new QueryResolver();
  String policyNumber = "12345";
  String schemeCategory = "sCategory";
  String schemeMembership = "sMembership";
  String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI5c0JRSTUtMDZLVldNUnJyMEg2dWdfaEhIbXA5a3VQUndQN3o4cGtUcWgwIn0.eyJqdGkiOiJmNmM3OGU2My1kZDAxLTRjY2ItODNkMy04NjhjMzUwM2U4ODkiLCJleHAiOjE1MjE4MDUyMjAsIm5iZiI6MCwiaWF0IjoxNTIxODA0OTIwLCJpc3MiOiJodHRwczovL3NlY3VyZS1zc28tYWpiLXJodC1zc28uYXBwcy5uYTEub3BlbnNoaWZ0Lm9wZW50bGMuY29tL2F1dGgvcmVhbG1zL3JodF9ncHRlXzNzY2FsZV9yZWFsbSIsImF1ZCI6ImN1cmxDbGllbnQiLCJzdWIiOiIzNmZiZTBiNi04OTI3LTQ4YzItOTc0NS1jZmY5MmFkODgwYTUiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJjdXJsQ2xpZW50IiwiYXV0aF90aW1lIjowLCJzZXNzaW9uX3N0YXRlIjoiOTI0YzgyNmMtZTJlZi00NDZhLTgyMzctZDY1NTczNDcyOTQ3IiwiYWNyIjoiMSIsImNsaWVudF9zZXNzaW9uIjoiM2Y2MDExNTMtMmY2YS00YjAzLWEzNTQtMTI4ODFjN2UwYzFmIiwiYWxsb3dlZC1vcmlnaW5zIjpbXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbInVtYV9hdXRob3JpemF0aW9uIiwic3dhcm1Sb2xlIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsInZpZXctcHJvZmlsZSJdfX0sIm5hbWUiOiIiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJzd2FybV9kZXYifQ.JkSg7CmTDreA-gEyS88LWcQbiEYRMZS869DiwcCHGxX9DM4AcSKFSbJa1gLhJYygaCNPZm69ySds35eDNyBJHnc5lfFA9rdvDAVFUz4ypxA0ZmpKJiFqsNYmoGSMlVhaCHZcUhbdcRBg6fMsAmkJJ_cQ0wrK1bBiUD03IGsuZW6ojG_RE99V5t3lI1x3T8ITAl7uFmbFYwtPvosZJoYhWazWwPQz0CxgyVLeLi-lNI0U79ZPfIg06h1KfXuIgM2nClOaO9zY1LY1u7H5bbOBbxdF-nTfyclQ5QIC4-dPKk2AZmQ7Djc6FUisPaRffyX1LxlzkrPYP4liVdTn2YEQVQ";

  @Mock
  DataFetchingEnvironment environment;

  @Mock
  JwtTokenExtractor jwtTokenExtractor;

  @Mock
  private JourneyIdExtractor journeyIdExtractor;

  @Mock
  WorkplaceSavingsService workplaceSavingsService;

  private String journeyId = generateUuid();

  WorkplacePensionHoldingsDto workplacePensionHoldingsDto;

  WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto workplacePensionSwitchRedirectCheckAllowedResponseDto;
  WorkplacePensionCustomerDetailsDto customerDetailsDto;
  WorkplacePensionFundDto workplacePensionFundDto;

  @Before
  public void setUp() {
    workplacePensionHoldingsDto = WorkplacePensionHoldingsDto.builder()
        .lastRegularContribution(new BigDecimal(100))
        .lastRegularContributionFrequencyCode(LastRegularContributionFrequencyCode.FOUR_WEEKLY)
        .benefits(Arrays.asList(BenefitDto.builder()
            .concatBenefitSequenceId("concat ben id")
            .type(BenefitType.REGULAR)
            .holdings(Arrays.asList(WorkplacePensionHoldingDto.builder()
                .unitPriceDate(new Date())
                .unitsHeld(675f)
                .name("Holdings in insurance")
                .fundTypeLifestyle(false)
                .fundCode("IE4455667788")
                .build()))
            .build()))
        .future(Arrays.asList(InvestmentStrategyDto.builder()
            .name("Strategy da new")
            .contributionPercentage(5.5f)
            .fundCode("IE3344332211")
            .build()))
        .build();

    workplacePensionSwitchRedirectCheckAllowedResponseDto = WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto.builder().permittedByScheme(true).build();

    customerDetailsDto = WorkplacePensionCustomerDetailsDto.builder()
        .emailAddress("someone@aol.com")
        .schemeCategory("scheme-category")
        .schemeMembership("scheme-membership")
        .build();
  }

  @Test
  public void testGetHoldingsReturnsValue() {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.getWorkplacePensionHoldings(policyNumber, jwtToken,journeyId)).thenReturn(workplacePensionHoldingsDto);

    WorkplacePensionHoldingsDto result = queryResolver.workplacePensionHoldings(policyNumber, environment);
    Assert.assertEquals(workplacePensionHoldingsDto, result);
  }

  @Test
  public void shouldThrowGraphqlExceptionWhenGetHoldingsThrowsException() {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.getWorkplacePensionHoldings(policyNumber, jwtToken,journeyId)).thenThrow(new RuntimeException("Refused to connect!"));

    expectedException.expect(GraphQLException.class);

    WorkplacePensionHoldingsDto result = queryResolver.workplacePensionHoldings(policyNumber, environment);
    Assert.assertNull(result);

  }

  @Test
  public void testSwitchAndRedirectCheckReturnsValue() {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.isSwitchAndRedirectAllowed(policyNumber, jwtToken,journeyId)).thenReturn(workplacePensionSwitchRedirectCheckAllowedResponseDto);

    WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto result = queryResolver.workplacePensionSwitchAndRedirectCheckAllowed(policyNumber, environment);
    Assert.assertEquals(workplacePensionSwitchRedirectCheckAllowedResponseDto, result);
  }

  @Test
  public void shouldThrowGraphqlExceptionWhenSwitchAndRedirectCheckThrowsException() {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.isSwitchAndRedirectAllowed(policyNumber, jwtToken,journeyId)).thenThrow(new RuntimeException("Connection refused!"));

    expectedException.expect(GraphQLException.class);

    WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto result = queryResolver.workplacePensionSwitchAndRedirectCheckAllowed(policyNumber, environment);
    Assert.assertNull(result);

  }

  @Test
  public void shouldReturnCustomerDetailsWhenPresent() {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.getWorkplacePensionCustomerDetails(policyNumber, jwtToken,journeyId)).thenReturn(customerDetailsDto);

    WorkplacePensionCustomerDetailsDto result = queryResolver.workplacePensionCustomerDetails(policyNumber, environment);
    Assert.assertEquals(customerDetailsDto, result);
  }

  @Test
  public void shouldThrowGraphqlExceptionWhenCustomerDetailsThrowsException() {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.getWorkplacePensionCustomerDetails(policyNumber, jwtToken,journeyId)).thenThrow(new RuntimeException("Connection refused!"));

    expectedException.expect(GraphQLException.class);

    WorkplacePensionCustomerDetailsDto result = queryResolver.workplacePensionCustomerDetails(policyNumber, environment);
    Assert.assertEquals(customerDetailsDto, result);

  }

  @Test
  public void shouldThrowExceptionWhenJwtTokenNotPresent() {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenThrow(new HttpServerErrorException(HttpStatus.UNAUTHORIZED));
    expectedException.expect(GraphQLException.class);

    WorkplacePensionHoldingsDto result = queryResolver.workplacePensionHoldings(policyNumber, environment);
    Assert.assertNull(result);

  }

  @Test
  public void shouldThrowExceptionForWorkplacePensionFundUniverseSchemeAndCategory() {
    expectedException.expect(RuntimeException.class);
    expectedException.expectMessage("Error while retrieving allowable funds for policy 12345");

    List<WorkplacePensionFundDto> result = queryResolver.workplacePensionFundUniverseSchemeAndCategory(policyNumber, schemeCategory, schemeMembership, null, environment);
    Assert.assertNull(result);

  }

  @Test
  public void shouldThrowExceptionForWorkplacePensionFundDetails() throws Exception {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.getWorkplacePensionFundDetails(Lists.newArrayList("dbau"), jwtToken,journeyId)).thenThrow(new RuntimeException("Refused to connect!"));

    expectedException.expect(GraphQLException.class);
    List<WorkplacePensionFundDto> result = queryResolver.workplacePensionFundDetails(Lists.newArrayList("dbau"), environment);
    Assert.assertNull(result);
  }

  @Test
  public void shouldReturnResponseForWorkplacePensionFundDetails() throws Exception {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.getWorkplacePensionFundDetails(Lists.newArrayList("dbau"), jwtToken,journeyId)).thenReturn(Lists.newArrayList(new WorkplacePensionFundDto()));
    List<WorkplacePensionFundDto> result = queryResolver.workplacePensionFundDetails(Lists.newArrayList("dbau"), environment);
    Assert.assertEquals(1, result.size());
  }

  @Test
  public void testWorkplacePensionFundBasketReturnsEmptyBasket() {

    FundsInBasketDto result = queryResolver.workplacePensionFundBasket(policyNumber, BasketType.HOLDINGS);
    Assert.assertEquals(0, result.getBenefits().size());

  }

  @Test
  public void testUnhashPolicyNumber() throws Exception {
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.unhashPolicyNumber(policyNumber, jwtToken,journeyId)).thenReturn(policyNumber);
    String capturedNumber = queryResolver.unhashPolicyNumber(policyNumber, environment);
    Assert.assertEquals("Query Resolver handles valid data returned", policyNumber, capturedNumber);
  }

  @Test
  public void testFailedUnhashPolicyNumber() throws Exception {
    expectedException.expect(GraphQLException.class);
    when(jwtTokenExtractor.extractJwtToken(environment)).thenReturn(jwtToken);
    when(journeyIdExtractor.extractJourneyId(environment)).thenReturn(journeyId);
    when(workplaceSavingsService.unhashPolicyNumber(policyNumber, jwtToken,journeyId)).thenThrow(GraphQLException.class);
    queryResolver.unhashPolicyNumber(policyNumber, environment);
  }

  @Test
  public void testVersion() {
    String version = queryResolver.version();
    Assert.assertTrue(version.equals("0.2.18"));
  }

  private String generateUuid() {
    return UUID.randomUUID().toString();
  }

}