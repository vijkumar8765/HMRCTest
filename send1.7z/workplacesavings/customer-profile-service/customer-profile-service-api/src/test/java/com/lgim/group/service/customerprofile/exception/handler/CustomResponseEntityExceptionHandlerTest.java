package com.lgim.group.service.customerprofile.exception.handler;

import com.lgim.group.gatekeeper.exception.JwtAuthenticationException;
import com.lgim.group.service.customerprofile.dto.ApiError;
import com.lgim.group.service.customerprofile.dto.ImmutableApiError;
import com.lgim.group.service.customerprofile.exception.CustomerNotFoundException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
//import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.TypeMismatchException;
import org.springframework.core.MethodParameter;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.lang.reflect.Executable;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CustomResponseEntityExceptionHandlerTest {

    @Mock
    private Environment environment;

    @InjectMocks
    private CustomResponseEntityExceptionHandler exceptionHandler;

//    @Test
//    public void handleMethodArgumentNotValidException() throws Exception {
//        when(environment.getActiveProfiles()).thenReturn(new String[]{});
//
//        MethodParameter methodParameter = mock(MethodParameter.class);
//        Executable executable = mock(Executable.class);
//        when(methodParameter.getExecutable()).thenReturn(executable);
//
//        BindingResult bindingResult = mock(BindingResult.class);
//
//        FieldError fieldError = new FieldError("FieldObject", "Field", "Field null");
//        when(bindingResult.getFieldErrors()).thenReturn(Collections.singletonList(fieldError));
//        ObjectError objectError = new ObjectError("Object", "Object null");
//        when(bindingResult.getGlobalErrors()).thenReturn(Collections.singletonList(objectError));
//        when(bindingResult.getAllErrors()).thenReturn(Arrays.asList(fieldError, objectError));
//        when(bindingResult.getErrorCount()).thenReturn(2);
//
//        MethodArgumentNotValidException exception = new MethodArgumentNotValidException(methodParameter, bindingResult);
//
//        ApiError expectedApiError =
//                ImmutableApiError
//                        .builder()
//                        .withHttpStatus(HttpStatus.BAD_REQUEST)
//                        .withMessage("Validation failed for argument at index 0 in method: null, with 2 error(s): [Field error in object 'FieldObject' on field 'Field': rejected value [null]; codes []; arguments []; default message [Field null]] [Error in object 'Object': codes []; arguments []; default message [Object null]] ")
//                        .withErrors(Arrays.asList(
//                                "Field: Field null", "Object: Object null"))
//                        .build();
//
//        ResponseEntity expectedResponse = ResponseEntity.badRequest().body(expectedApiError);
//        ResponseEntity actualResponse = exceptionHandler.handleMethodArgumentNotValidException(exception);
//
//        assertEquals(expectedResponse, actualResponse);
//    }

    @Test
    public void handleMethodArgumentNotValidExceptionQuietMode() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{"prod"});
        MethodParameter methodParameter = mock(MethodParameter.class);
        BindingResult bindingResult = mock(BindingResult.class);

        MethodArgumentNotValidException exception = new MethodArgumentNotValidException(methodParameter, bindingResult);

        ResponseEntity expectedResponse = ResponseEntity.badRequest().build();
        ResponseEntity actualResponse = exceptionHandler.handleMethodArgumentNotValidException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleBindException() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{});

        BindException exception = mock(BindException.class);

        FieldError fieldError = new FieldError("FieldObject", "Field", "Field null");
        when(exception.getFieldErrors()).thenReturn(Collections.singletonList(fieldError));
        ObjectError objectError = new ObjectError("Object", "Object null");
        when(exception.getGlobalErrors()).thenReturn(Collections.singletonList(objectError));
        when(exception.getLocalizedMessage()).thenReturn("Exception when binding");

        ApiError expectedApiError =
                ImmutableApiError
                        .builder()
                        .withHttpStatus(HttpStatus.BAD_REQUEST)
                        .withMessage("Exception when binding")
                        .withErrors(Arrays.asList(
                                "Field: Field null", "Object: Object null"))
                        .build();

        ResponseEntity expectedResponse = ResponseEntity.badRequest().body(expectedApiError);
        ResponseEntity actualResponse = exceptionHandler.handleBindException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleBindExceptionQuietMode() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{"prod"});
        BindingResult bindingResult = mock(BindingResult.class);

        BindException exception = new BindException(bindingResult, "ObjectName");

        ResponseEntity expectedResponse = ResponseEntity.badRequest().build();
        ResponseEntity actualResponse = exceptionHandler.handleBindException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleHttpMessageNotReadableException() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{});

        HttpMessageNotReadableException exception = mock(HttpMessageNotReadableException.class);
        when(exception.getLocalizedMessage()).thenReturn("Could not read document: Can not map JSON");

        ApiError expectedApiError =
                ImmutableApiError
                        .builder()
                        .withHttpStatus(HttpStatus.BAD_REQUEST)
                        .withMessage("The request is badly formatted and could not be read")
                        .withErrors(Collections.singletonList("Could not read document: Can not map JSON"))
                        .build();

        ResponseEntity expectedResponse = ResponseEntity.badRequest().body(expectedApiError);
        ResponseEntity actualResponse = exceptionHandler.handleHttpMessageNotReadableException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleHttpMessageNotReadableExceptionQuietMode() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{"prod"});
        HttpMessageNotReadableException exception = mock(HttpMessageNotReadableException.class);

        ResponseEntity expectedResponse = ResponseEntity.badRequest().build();
        ResponseEntity actualResponse = exceptionHandler.handleHttpMessageNotReadableException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleTypeMismatchException() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{});

        TypeMismatchException exception = mock(TypeMismatchException.class);
        when(exception.getLocalizedMessage()).thenReturn("Validation of types failed");
        when(exception.getValue()).thenReturn("123");
        when(exception.getPropertyName()).thenReturn("TotallyNotANumber");
        when(exception.getRequiredType()).thenReturn((Class) String.class);


        ApiError expectedApiError =
                ImmutableApiError
                        .builder()
                        .withHttpStatus(HttpStatus.BAD_REQUEST)
                        .withMessage("Validation of types failed")
                        .withErrors(Collections.singletonList("123 value for TotallyNotANumber should be of type class java.lang.String"))
                        .build();

        ResponseEntity expectedResponse = ResponseEntity.badRequest().body(expectedApiError);
        ResponseEntity actualResponse = exceptionHandler.handleTypeMismatchException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleTypeMismatchExceptionQuietMode() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{"prod"});
        TypeMismatchException exception = mock(TypeMismatchException.class);

        ResponseEntity expectedResponse = ResponseEntity.badRequest().build();
        ResponseEntity actualResponse = exceptionHandler.handleTypeMismatchException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleMethodArgumentTypeMismatchException() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{});

        MethodArgumentTypeMismatchException exception = mock(MethodArgumentTypeMismatchException.class);
        when(exception.getLocalizedMessage()).thenReturn("Validation of method argument types failed");
        when(exception.getName()).thenReturn("Name");
        when(exception.getRequiredType()).thenReturn((Class) String.class);


        ApiError expectedApiError =
                ImmutableApiError
                        .builder()
                        .withHttpStatus(HttpStatus.BAD_REQUEST)
                        .withMessage("Validation of method argument types failed")
                        .withErrors(Collections.singletonList("Name should be of type java.lang.String"))
                        .build();

        ResponseEntity expectedResponse = ResponseEntity.badRequest().body(expectedApiError);
        ResponseEntity actualResponse = exceptionHandler.handleMethodArgumentTypeMismatchException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleMethodArgumentTypeMismatchExceptionQuietMode() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{"prod"});
        MethodArgumentTypeMismatchException exception = mock(MethodArgumentTypeMismatchException.class);

        ResponseEntity expectedResponse = ResponseEntity.badRequest().build();
        ResponseEntity actualResponse = exceptionHandler.handleMethodArgumentTypeMismatchException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleJwtAuthenticationException() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{});

        JwtAuthenticationException exception = mock(JwtAuthenticationException.class);
        when(exception.getLocalizedMessage()).thenReturn("JWT Authentication Exception");

        ApiError expectedApiError =
            ImmutableApiError
                .builder()
                .withHttpStatus(HttpStatus.UNAUTHORIZED)
                .withMessage("JWT Authentication Exception")
                .build();

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(expectedApiError);
        ResponseEntity actualResponse = exceptionHandler.handleJwtAuthenticationException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleJwtAuthenticationExceptionQuietMode() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{"prod"});
        JwtAuthenticationException exception = mock(JwtAuthenticationException.class);

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        ResponseEntity actualResponse = exceptionHandler.handleJwtAuthenticationException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleCustomerNotFoundException() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{});

        CustomerNotFoundException exception = mock(CustomerNotFoundException.class);
        when(exception.getLocalizedMessage()).thenReturn("Customer not found");
        when(exception.getErrors()).thenReturn(Collections.singletonList("123: Customer ID is not valid"));

        ApiError expectedApiError =
                ImmutableApiError
                        .builder()
                        .withHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR)
                        .withMessage("Customer not found")
                        .withErrors(Collections.singletonList("123: Customer ID is not valid"))
                        .build();

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(expectedApiError);
        ResponseEntity actualResponse = exceptionHandler.handleCustomerNotFoundException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleCustomerNotFoundExceptionQuietMode() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{"prod"});
        CustomerNotFoundException exception = mock(CustomerNotFoundException.class);

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        ResponseEntity actualResponse = exceptionHandler.handleCustomerNotFoundException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleNoHandlerFoundException() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{});

        NoHandlerFoundException exception = mock(NoHandlerFoundException.class);
        when(exception.getLocalizedMessage()).thenReturn("No handler like that");

        ApiError expectedApiError =
                ImmutableApiError
                        .builder()
                        .withHttpStatus(HttpStatus.NOT_FOUND)
                        .withMessage("No handler like that")
                        .build();

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.NOT_FOUND).body(expectedApiError);
        ResponseEntity actualResponse = exceptionHandler.handleNotFoundException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleNoHandlerFoundExceptionQuietMode() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{"prod"});
        NoHandlerFoundException exception = mock(NoHandlerFoundException.class);

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        ResponseEntity actualResponse = exceptionHandler.handleNotFoundException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleHttpRequestMethodNotSupportedException() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{});

        HttpRequestMethodNotSupportedException exception = mock(HttpRequestMethodNotSupportedException.class);
        when(exception.getLocalizedMessage()).thenReturn("Unsupported HTTP request method");
        when(exception.getMethod()).thenReturn("PUT");
        when(exception.getSupportedHttpMethods()).thenReturn(new HashSet<>(Collections.singletonList(HttpMethod.GET)));

        ApiError expectedApiError =
                ImmutableApiError
                        .builder()
                        .withHttpStatus(HttpStatus.METHOD_NOT_ALLOWED)
                        .withMessage("Unsupported HTTP request method")
                        .withErrors(Collections.singletonList("PUT method is not supported for this request. Supported methods are: GET"))
                        .build();

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(expectedApiError);
        ResponseEntity actualResponse = exceptionHandler.handleHttpRequestMethodNotSupportedException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleHttpRequestMethodNotSupportedExceptionQuietMode() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{"prod"});
        HttpRequestMethodNotSupportedException exception = mock(HttpRequestMethodNotSupportedException.class);

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).build();
        ResponseEntity actualResponse = exceptionHandler.handleHttpRequestMethodNotSupportedException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleHttpMediaTypeNotAcceptableException() throws Exception {
        HttpMediaTypeNotAcceptableException exception = mock(HttpMediaTypeNotAcceptableException.class);

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
        ResponseEntity actualResponse = exceptionHandler.handleHttpMediaTypeNotAcceptableException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleHttpMediaTypeNotSupportedException() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{});

        HttpMediaTypeNotSupportedException exception = mock(HttpMediaTypeNotSupportedException.class);
        when(exception.getLocalizedMessage()).thenReturn("Unsupported Media Type");
        when(exception.getContentType()).thenReturn(MediaType.APPLICATION_ATOM_XML);
        when(exception.getSupportedMediaTypes()).thenReturn(Collections.singletonList(MediaType.APPLICATION_JSON));

        ApiError expectedApiError =
                ImmutableApiError
                        .builder()
                        .withHttpStatus(HttpStatus.UNSUPPORTED_MEDIA_TYPE)
                        .withMessage("Unsupported Media Type")
                        .withErrors(Collections.singletonList("application/atom+xml media type is not supported. Supported media types are: application/json"))
                        .build();

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.UNSUPPORTED_MEDIA_TYPE).body(expectedApiError);
        ResponseEntity actualResponse = exceptionHandler.handleHttpMediaTypeNotSupportedException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleHttpMediaTypeNotSupportedExceptionQuietMode() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{"prod"});
        HttpMediaTypeNotSupportedException exception = mock(HttpMediaTypeNotSupportedException.class);

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.UNSUPPORTED_MEDIA_TYPE).build();
        ResponseEntity actualResponse = exceptionHandler.handleHttpMediaTypeNotSupportedException(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleAllExceptions() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{});

        Exception exception = mock(Exception.class);
        when(exception.getLocalizedMessage()).thenReturn("Generic exception");

        ApiError expectedApiError =
                ImmutableApiError
                        .builder()
                        .withHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR)
                        .withMessage("Generic exception")
                        .build();

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(expectedApiError);
        ResponseEntity actualResponse = exceptionHandler.handleAllExceptions(exception);

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void handleAllExceptionsQuietMode() throws Exception {
        when(environment.getActiveProfiles()).thenReturn(new String[]{"prod"});
        Exception exception = mock(Exception.class);

        ResponseEntity expectedResponse = ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        ResponseEntity actualResponse = exceptionHandler.handleAllExceptions(exception);

        assertEquals(expectedResponse, actualResponse);
    }
}