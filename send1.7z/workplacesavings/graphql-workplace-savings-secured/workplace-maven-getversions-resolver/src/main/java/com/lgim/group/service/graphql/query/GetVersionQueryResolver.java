package com.lgim.group.service.graphql.query;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.lgim.group.service.graphql.dto.versions.MicroServiceReportDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.RequestEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

import static org.springframework.http.HttpMethod.GET;

@Slf4j
@Component
public class GetVersionQueryResolver implements GraphQLQueryResolver {

  private final RestTemplate restTemplate = new RestTemplate();
  @Value("${service-reporting.url}")
  private String serviceReportUrl;

  public List<MicroServiceReportDto> getVersions() {
    ParameterizedTypeReference<List<MicroServiceReportDto>> parameterizedTypeReference = new ParameterizedTypeReference<List<MicroServiceReportDto>>() {
    };
    RequestEntity requestEntity = new RequestEntity(headers(), GET, URI.create("http://localhost:8070/service-report"));
    return restTemplate.exchange(requestEntity, parameterizedTypeReference).getBody();
  }

  private HttpHeaders headers() {
    HttpHeaders headers = new HttpHeaders();
    headers.set("Accept", "application/json");
    return headers;
  }

}
