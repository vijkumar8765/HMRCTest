package com.lgim.group.service.graphql.query;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.lgim.group.service.graphql.dto.BasketType;
import com.lgim.group.service.graphql.dto.FundsInBasketDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionCustomerDetailsDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionFundDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionFunds;
import com.lgim.group.service.graphql.dto.WorkplacePensionHoldingsDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto;
import com.lgim.group.service.graphql.service.WorkplaceSavingsService;
import com.lgim.group.service.graphql.util.JourneyIdExtractor;
import com.lgim.group.service.graphql.util.JwtTokenExtractor;
import graphql.GraphQLException;
import graphql.schema.DataFetchingEnvironment;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;

@Component
@Slf4j
public class QueryResolver implements GraphQLQueryResolver {

  public static final String GRAPHQL_SCHEMA_VERSION_FILE_PATH = "/workplace-savings-graphql-schema-version.txt";
  private static final String INVESTMENT_DETAILS_ERROR_MESSAGE = "Error while retrieving Investment Holdings for policy %s";
  private static final String INVESTMENT_AVAILABILITY_ERROR_MESSAGE = "Error while performing switch and redirect check for policy %s";
  private static final String ALLOWABLE_FUNDS_ERROR_MESSAGE = "Error while retrieving allowable funds for policy %s";
  private static final String FUNDS_DETAIL_ERROR_MESSAGE = "Error while retrieving funds detail for fund codes %s";
  private static final String CUSTOMER_DETAILS_ERROR_MESSAGE = "Error while retrieving customer details for policy %s";
  private static final String POLICY_NUM_ERROR_MESSAGE = "Error while resolving policy number";

  /**
   * Schema version derived at build time using a groovy script in src/main/groovy-build. At build time the schema version number is written to a text file which is picked up at runtime
   */
  private String schemaVersion;

  @Autowired
  private WorkplaceSavingsService workplaceSavingsService;

  @Autowired
  private JwtTokenExtractor jwtTokenExtractor;

  @Autowired
  private JourneyIdExtractor journeyIdExtractor;

  public QueryResolver() {
    InputStream is = QueryResolver.class
        .getResourceAsStream(GRAPHQL_SCHEMA_VERSION_FILE_PATH);
    try {
      schemaVersion = IOUtils.toString(is);
    } catch (IOException ioException) {
      log.error(
          String.format("Unable to determine graphql schema version as unable to locate file [%s}, error was [%s]",
              GRAPHQL_SCHEMA_VERSION_FILE_PATH,
              ioException.getMessage()
          )
      );
      throw new RuntimeException("Unable to determine GraphQL schema version");
    }
  }

  public WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto workplacePensionSwitchAndRedirectCheckAllowed(String policyNumber, DataFetchingEnvironment environment) {
    try {
      String jwtToken = jwtTokenExtractor.extractJwtToken(environment);
      String journeyId = journeyIdExtractor.extractJourneyId(environment);
      return workplaceSavingsService.isSwitchAndRedirectAllowed(policyNumber, jwtToken, journeyId);
    } catch (Exception ex) {
      log.error(String.format(INVESTMENT_AVAILABILITY_ERROR_MESSAGE, policyNumber), ex);
      throw new GraphQLException(String.format(INVESTMENT_AVAILABILITY_ERROR_MESSAGE, policyNumber));
    }
  }

  public WorkplacePensionHoldingsDto workplacePensionHoldings(String policyNumber, DataFetchingEnvironment environment) {
    try {
      String jwtToken = jwtTokenExtractor.extractJwtToken(environment);
      String journeyId = journeyIdExtractor.extractJourneyId(environment);
      return workplaceSavingsService.getWorkplacePensionHoldings(policyNumber, jwtToken, journeyId);
    } catch (Exception ex) {
      log.error(String.format(INVESTMENT_DETAILS_ERROR_MESSAGE, policyNumber), ex);
      throw new GraphQLException(String.format(INVESTMENT_DETAILS_ERROR_MESSAGE, policyNumber));
    }

  }

  public List<WorkplacePensionFundDto> workplacePensionFundUniverseSchemeAndCategory(String policyNumber, String schemeCategory, String schemeMembership, String productId, DataFetchingEnvironment environment) {
    try {
      String jwtToken = jwtTokenExtractor.extractJwtToken(environment);
      String journeyId = journeyIdExtractor.extractJourneyId(environment);
      WorkplacePensionFunds fundsDto = workplaceSavingsService.retrieveAllowableFunds(policyNumber, schemeCategory, schemeMembership, productId, jwtToken, journeyId);
      return fundsDto.getWorkplacePensionFundDtoList();
    } catch (Exception ex) {
      log.error(String.format(ALLOWABLE_FUNDS_ERROR_MESSAGE, policyNumber), ex);
      throw new GraphQLException(String.format(ALLOWABLE_FUNDS_ERROR_MESSAGE, policyNumber));
    }
  }

  public List<WorkplacePensionFundDto> workplacePensionFundDetails(List<String> fundCodes, DataFetchingEnvironment environment) {
    try {
      String jwtToken = jwtTokenExtractor.extractJwtToken(environment);
      String journeyId = journeyIdExtractor.extractJourneyId(environment);
      return workplaceSavingsService.getWorkplacePensionFundDetails(fundCodes, jwtToken, journeyId);
    } catch (Exception ex) {
      log.error(String.format(FUNDS_DETAIL_ERROR_MESSAGE, fundCodes), ex);
      throw new GraphQLException(String.format(FUNDS_DETAIL_ERROR_MESSAGE, fundCodes));
    }
  }


  public WorkplacePensionCustomerDetailsDto workplacePensionCustomerDetails(String policyNumber, DataFetchingEnvironment environment) {
    try {
      String jwtToken = jwtTokenExtractor.extractJwtToken(environment);
      String journeyId = journeyIdExtractor.extractJourneyId(environment);
      return workplaceSavingsService.getWorkplacePensionCustomerDetails(policyNumber, jwtToken, journeyId);
    } catch (Exception ex) {
      log.error(String.format(CUSTOMER_DETAILS_ERROR_MESSAGE, policyNumber), ex);
      throw new GraphQLException(String.format(CUSTOMER_DETAILS_ERROR_MESSAGE, policyNumber));
    }
  }

  public FundsInBasketDto workplacePensionFundBasket(String policyNumber, BasketType basketType) {
    return FundsInBasketDto.builder()
        .basketType(basketType)
        .benefits(Collections.emptyList())
        .build();
  }

  public String version() {
    log.info(String.format("Returning schema version [%s]", schemaVersion));
    return schemaVersion;
  }

  public String unhashPolicyNumber(String hashedPolicyNumber, DataFetchingEnvironment environment) {
    try {
      String jwtToken = jwtTokenExtractor.extractJwtToken(environment);
      String journeyId = journeyIdExtractor.extractJourneyId(environment);
      String unhashedPolicyNumber = workplaceSavingsService.unhashPolicyNumber(hashedPolicyNumber, jwtToken, journeyId);
      return unhashedPolicyNumber;
    } catch (Exception ex) {
      log.error(POLICY_NUM_ERROR_MESSAGE, ex);
      throw new GraphQLException(String.format(POLICY_NUM_ERROR_MESSAGE), ex);
    }

  }
}
