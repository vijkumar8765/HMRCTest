
package lbb_personcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_IncomeElement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_IncomeElement"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="incomeType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="incomeGrossAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="estimatedIncomeEvidence" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="effectiveDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_IncomeElement", propOrder = {
    "incomeType",
    "incomeGrossAmount",
    "estimatedIncomeEvidence",
    "effectiveDate"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGIncomeElement
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String incomeType;
    protected Double incomeGrossAmount;
    protected String estimatedIncomeEvidence;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar effectiveDate;

    /**
     * Gets the value of the incomeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncomeType() {
        return incomeType;
    }

    /**
     * Sets the value of the incomeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncomeType(String value) {
        this.incomeType = value;
    }

    /**
     * Gets the value of the incomeGrossAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getIncomeGrossAmount() {
        return incomeGrossAmount;
    }

    /**
     * Sets the value of the incomeGrossAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setIncomeGrossAmount(Double value) {
        this.incomeGrossAmount = value;
    }

    /**
     * Gets the value of the estimatedIncomeEvidence property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEstimatedIncomeEvidence() {
        return estimatedIncomeEvidence;
    }

    /**
     * Sets the value of the estimatedIncomeEvidence property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEstimatedIncomeEvidence(String value) {
        this.estimatedIncomeEvidence = value;
    }

    /**
     * Gets the value of the effectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the value of the effectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setEffectiveDate(XMLGregorianCalendar value) {
        this.effectiveDate = value;
    }

}
