@javax.xml.bind.annotation.XmlSchema(namespace = "http://LBB_Communication_1")
package lbb_communication_1;
