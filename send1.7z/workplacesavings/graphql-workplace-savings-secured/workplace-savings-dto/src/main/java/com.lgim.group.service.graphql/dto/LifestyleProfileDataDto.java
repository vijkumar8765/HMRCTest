package com.lgim.group.service.graphql.dto;

import java.util.List;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class LifestyleProfileDataDto implements java.io.Serializable {
  private int yearFromRetirement;
  private List<LifestyleProfleFundDto> funds;

  public LifestyleProfileDataDto(int yearFromRetirement, List<LifestyleProfleFundDto> funds) {
    this.yearFromRetirement = yearFromRetirement;
    this.funds = funds;
  }
}
