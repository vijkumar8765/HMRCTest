package com.lgim.group.service.graphql.config;

import com.lgim.group.service.graphql.scalar.GraphQLDate;
import com.lgim.group.service.graphql.scalar.GraphQLLocalDate;
import com.lgim.group.service.graphql.scalar.GraphQLLocalDateTime;
import com.lgim.group.service.graphql.scalar.GraphQLLocalTime;
import com.lgim.group.service.graphql.scalar.MonetaryAmount;
import com.oembedler.moon.graphql.boot.GraphQLJavaToolsAutoConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@AutoConfigureBefore( {GraphQLJavaToolsAutoConfiguration.class})
public class GraphQLScalarAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public GraphQLDate graphQLDate() {
    return new GraphQLDate();
  }

  @Bean
  @ConditionalOnMissingBean
  public GraphQLLocalDate graphQLLocalDate() {
    return new GraphQLLocalDate();
  }

  @Bean
  @ConditionalOnMissingBean
  public GraphQLLocalDateTime graphQLLocalDateTime() {
    return new GraphQLLocalDateTime();
  }

  @Bean
  @ConditionalOnMissingBean
  public GraphQLLocalTime graphQLLocalTime() {
    return new GraphQLLocalTime();
  }

  @Bean
  @ConditionalOnMissingBean
  public MonetaryAmount monetaryAmount() {
    return new MonetaryAmount();
  }
}
