package com.lgim.group.gatekeeper.processor;


import com.lgim.group.gatekeeper.helpers.PublicKeyHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class PublicKeyProcessor implements Processor {

  @Value("${public_key_url}")
  private String publicKeyURL;

  @Autowired
  PublicKeyHelper publicKeyHelper;

  @Override
  public void process(Exchange exchange) {

    try {
      publicKeyHelper.fetchPublicKey();
    } catch (Exception error) {
      log.error("Failed to get public key");
    }

  }
}
