package com.lgim.group.service.graphql.query;

import com.coxautodev.graphql.tools.SchemaParserBuilder;
import com.lgim.group.service.graphql.audit.AuditInstrumentation;
import com.lgim.group.service.graphql.audit.AuditInstrumentationState;
import com.lgim.group.service.graphql.config.TestAppConfig;
import com.lgim.group.service.graphql.mutation.MutationResolver;
import com.lgim.group.service.graphql.scalar.GraphQLDate;
import com.lgim.group.service.graphql.scalar.GraphQLLocalDate;
import com.lgim.group.service.graphql.scalar.GraphQLLocalDateTime;
import com.lgim.group.service.graphql.scalar.GraphQLLocalTime;
import com.lgim.group.service.graphql.scalar.MonetaryAmount;
import com.lgim.group.service.graphql.service.WorkplaceSavingsService;
import com.lgim.group.service.graphql.util.JourneyIdExtractor;
import com.lgim.group.service.graphql.util.JwtTokenExtractor;
import com.lgim.group.ws.utility.plugin.model.GroupDigitalMessage;
import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.GraphQLError;
import graphql.execution.ExecutionContext;
import graphql.execution.instrumentation.InstrumentationState;
import graphql.execution.instrumentation.parameters.InstrumentationExecutionParameters;
import graphql.execution.instrumentation.parameters.InstrumentationFieldFetchParameters;
import graphql.language.OperationDefinition;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.GraphQLSchema;
import graphql.servlet.GraphQLContext;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = TestAppConfig.class)
@TestPropertySource(locations = "classpath:test.properties")
public class GraphQLQueryTest {

  private static final String WORKPLACE_SAVINGS_SCHEMA_FILE_LOCATION = "graphql/workplaceSavings_v0.2.18.graphqls";
  @Rule
  public ExpectedException expectedException = ExpectedException.none();
  @Mock
  DataFetchingEnvironment environment;
  @Autowired
  ApplicationContext applicationContext;
  @Mock
  GraphQLContext graphQLContext;
  @Mock
  HttpServletRequest request;

  @Mock
  InstrumentationExecutionParameters parameters;

  @Mock
  InstrumentationState instrumentationState;



  @Mock
  HttpServletRequest httpRequest;

  //AuditInstrumentation auditInstrumentation = new AuditInstrumentation();

  private GraphQL graphQL;
  @Autowired
  private QueryResolver queryResolver;
  @Autowired
  private MutationResolver mutationResolver;
  @Autowired
  private WorkplaceSavingsService workplaceSavingsService;
  @Autowired
  private JwtTokenExtractor jwtTokenExtractor;
  @Autowired
  private JourneyIdExtractor journeyIdExtractor;

  @Mock
  GroupDigitalMessage groupDigitalMessage;

  @Mock
  AuditInstrumentationState auditInstrumentationState;

  @Mock
  InstrumentationFieldFetchParameters instrumentationFieldFetchParameters;
  @Mock
  DataFetcher dataFetcher;

  @Mock
  ExecutionContext executionContext;

  @Mock
  OperationDefinition operationDefinition;

  @Before
  public void setUp() {
    SchemaParserBuilder parser = com.coxautodev.graphql.tools.SchemaParser.newParser();
    parser.file(WORKPLACE_SAVINGS_SCHEMA_FILE_LOCATION);

    GraphQLSchema schema = parser
        .resolvers(Arrays.asList(queryResolver, mutationResolver))
        .scalars(new GraphQLDate(), new GraphQLLocalDate(), new GraphQLLocalDateTime(), new GraphQLLocalTime(), new MonetaryAmount())
        .build().makeExecutableSchema();

    when(parameters.getContext()).thenReturn(graphQLContext);


//    graphQL = GraphQL.newGraphQL(schema).instrumentation(auditInstrumentation).
//        build();
  }



  @Ignore
  public void basicConnectivityTest() {

    when(graphQLContext.getRequest()).thenReturn(Optional.of(request));
    groupDigitalMessage.setMicroserviceMethod("ni");
    when(request.getHeader(JwtTokenExtractor.AUTHORISATION_HEADER_NAME)).thenReturn("Bearer some token value");
    when(request.getAttribute("journeyId")).thenReturn("Journey Id");
    when(request.getMethod()).thenReturn("workplacePensionFundDetails");
    when(request.getRequestURI()).thenReturn("/graphql");

    ExecutionInput executionInput = new ExecutionInput("query workplacePensionSwitchAndRedirectCheckAllowed( $policyNumber : String! ) {         workplacePensionSwitchAndRedirectCheckAllowed( policyNumber: $policyNumber ) {            permittedByScheme            wipStatus {wipExpiryDateIsIndefinite wipSet __typename    }            noPostalAddress         }     }",null,graphQLContext,new Object(),new HashMap<>());

    ExecutionResult result = graphQL.execute(executionInput);

  }

  @Test
  public void test(){

  }

}
