package com.lgim.group.service.graphql.util;

import graphql.schema.DataFetchingEnvironment;

public interface JourneyIdExtractor {

  String extractJourneyId(DataFetchingEnvironment environment);
}
