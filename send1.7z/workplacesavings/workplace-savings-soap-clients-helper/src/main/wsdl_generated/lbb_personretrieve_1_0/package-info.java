@javax.xml.bind.annotation.XmlSchema(namespace = "http://LBB_PersonRetrieve_1_0")
package lbb_personretrieve_1_0;
