
package lbb_personcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_Bankruptcy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_Bankruptcy"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dateOfBankruptcy" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="dateOfDischarge" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_Bankruptcy", propOrder = {
    "dateOfBankruptcy",
    "dateOfDischarge"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGBankruptcy
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateOfBankruptcy;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateOfDischarge;

    /**
     * Gets the value of the dateOfBankruptcy property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOfBankruptcy() {
        return dateOfBankruptcy;
    }

    /**
     * Sets the value of the dateOfBankruptcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfBankruptcy(XMLGregorianCalendar value) {
        this.dateOfBankruptcy = value;
    }

    /**
     * Gets the value of the dateOfDischarge property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOfDischarge() {
        return dateOfDischarge;
    }

    /**
     * Sets the value of the dateOfDischarge property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfDischarge(XMLGregorianCalendar value) {
        this.dateOfDischarge = value;
    }

}
