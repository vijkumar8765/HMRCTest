package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
public class BasketBenefitListDto implements java.io.Serializable {
  private String concatBenefitSequenceId;
  private List<BasketFundsDto> funds;

  public BasketBenefitListDto(String concatBenefitSequenceId, List<BasketFundsDto> funds) {
    this.concatBenefitSequenceId = concatBenefitSequenceId;
    this.funds = funds;
  }
}
