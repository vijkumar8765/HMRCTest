
package lbb_acct_b_1_0;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_AccountTransferDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_AccountTransferDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="cedingSchemeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="cedingPolicyNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="tvRetirementAge" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="sourceOfTransfer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pstr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="sconNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="econNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="asconNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="highEarnerIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="controllingDirectorIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="divorceSplitIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="nonCommutableAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="restrictedTfcAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="transferReceivedAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="transferAnalysisResult" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pensionDebitIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="pensionDebitAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="divorceDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="fsaCustomerCategorisation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="tvSplitIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="pensionInPaymentIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="protectedTfcAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="fundAmountAtADay" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="postADayAccrualIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="internalTransferIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="typeOfTransfer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pensionProvider" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="blockTransferIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="earmarkingIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="membersContribution" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_AccountTransferDetail", propOrder = {
    "cedingSchemeName",
    "cedingPolicyNumber",
    "tvRetirementAge",
    "sourceOfTransfer",
    "pstr",
    "sconNumber",
    "econNumber",
    "asconNumber",
    "highEarnerIndicator",
    "controllingDirectorIndicator",
    "divorceSplitIndicator",
    "nonCommutableAmount",
    "restrictedTfcAmount",
    "transferReceivedAmount",
    "transferAnalysisResult",
    "pensionDebitIndicator",
    "pensionDebitAmount",
    "divorceDate",
    "fsaCustomerCategorisation",
    "tvSplitIndicator",
    "pensionInPaymentIndicator",
    "protectedTfcAmount",
    "fundAmountAtADay",
    "postADayAccrualIndicator",
    "internalTransferIndicator",
    "typeOfTransfer",
    "pensionProvider",
    "blockTransferIndicator",
    "earmarkingIndicator",
    "membersContribution"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAAccountTransferDetail
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String cedingSchemeName;
    protected String cedingPolicyNumber;
    protected Integer tvRetirementAge;
    protected String sourceOfTransfer;
    protected String pstr;
    protected String sconNumber;
    protected String econNumber;
    protected String asconNumber;
    protected Boolean highEarnerIndicator;
    protected Boolean controllingDirectorIndicator;
    protected Boolean divorceSplitIndicator;
    protected BigDecimal nonCommutableAmount;
    protected BigDecimal restrictedTfcAmount;
    protected BigDecimal transferReceivedAmount;
    protected String transferAnalysisResult;
    protected Boolean pensionDebitIndicator;
    protected BigDecimal pensionDebitAmount;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar divorceDate;
    protected String fsaCustomerCategorisation;
    protected Boolean tvSplitIndicator;
    protected Boolean pensionInPaymentIndicator;
    protected BigDecimal protectedTfcAmount;
    protected BigDecimal fundAmountAtADay;
    protected Boolean postADayAccrualIndicator;
    protected Boolean internalTransferIndicator;
    protected String typeOfTransfer;
    protected String pensionProvider;
    protected Boolean blockTransferIndicator;
    protected Boolean earmarkingIndicator;
    protected BigDecimal membersContribution;

    /**
     * Gets the value of the cedingSchemeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCedingSchemeName() {
        return cedingSchemeName;
    }

    /**
     * Sets the value of the cedingSchemeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCedingSchemeName(String value) {
        this.cedingSchemeName = value;
    }

    /**
     * Gets the value of the cedingPolicyNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCedingPolicyNumber() {
        return cedingPolicyNumber;
    }

    /**
     * Sets the value of the cedingPolicyNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCedingPolicyNumber(String value) {
        this.cedingPolicyNumber = value;
    }

    /**
     * Gets the value of the tvRetirementAge property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTvRetirementAge() {
        return tvRetirementAge;
    }

    /**
     * Sets the value of the tvRetirementAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTvRetirementAge(Integer value) {
        this.tvRetirementAge = value;
    }

    /**
     * Gets the value of the sourceOfTransfer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceOfTransfer() {
        return sourceOfTransfer;
    }

    /**
     * Sets the value of the sourceOfTransfer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceOfTransfer(String value) {
        this.sourceOfTransfer = value;
    }

    /**
     * Gets the value of the pstr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPstr() {
        return pstr;
    }

    /**
     * Sets the value of the pstr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPstr(String value) {
        this.pstr = value;
    }

    /**
     * Gets the value of the sconNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSconNumber() {
        return sconNumber;
    }

    /**
     * Sets the value of the sconNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSconNumber(String value) {
        this.sconNumber = value;
    }

    /**
     * Gets the value of the econNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEconNumber() {
        return econNumber;
    }

    /**
     * Sets the value of the econNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEconNumber(String value) {
        this.econNumber = value;
    }

    /**
     * Gets the value of the asconNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAsconNumber() {
        return asconNumber;
    }

    /**
     * Sets the value of the asconNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAsconNumber(String value) {
        this.asconNumber = value;
    }

    /**
     * Gets the value of the highEarnerIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isHighEarnerIndicator() {
        return highEarnerIndicator;
    }

    /**
     * Sets the value of the highEarnerIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setHighEarnerIndicator(Boolean value) {
        this.highEarnerIndicator = value;
    }

    /**
     * Gets the value of the controllingDirectorIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isControllingDirectorIndicator() {
        return controllingDirectorIndicator;
    }

    /**
     * Sets the value of the controllingDirectorIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setControllingDirectorIndicator(Boolean value) {
        this.controllingDirectorIndicator = value;
    }

    /**
     * Gets the value of the divorceSplitIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDivorceSplitIndicator() {
        return divorceSplitIndicator;
    }

    /**
     * Sets the value of the divorceSplitIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDivorceSplitIndicator(Boolean value) {
        this.divorceSplitIndicator = value;
    }

    /**
     * Gets the value of the nonCommutableAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNonCommutableAmount() {
        return nonCommutableAmount;
    }

    /**
     * Sets the value of the nonCommutableAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNonCommutableAmount(BigDecimal value) {
        this.nonCommutableAmount = value;
    }

    /**
     * Gets the value of the restrictedTfcAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getRestrictedTfcAmount() {
        return restrictedTfcAmount;
    }

    /**
     * Sets the value of the restrictedTfcAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setRestrictedTfcAmount(BigDecimal value) {
        this.restrictedTfcAmount = value;
    }

    /**
     * Gets the value of the transferReceivedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTransferReceivedAmount() {
        return transferReceivedAmount;
    }

    /**
     * Sets the value of the transferReceivedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTransferReceivedAmount(BigDecimal value) {
        this.transferReceivedAmount = value;
    }

    /**
     * Gets the value of the transferAnalysisResult property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransferAnalysisResult() {
        return transferAnalysisResult;
    }

    /**
     * Sets the value of the transferAnalysisResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransferAnalysisResult(String value) {
        this.transferAnalysisResult = value;
    }

    /**
     * Gets the value of the pensionDebitIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPensionDebitIndicator() {
        return pensionDebitIndicator;
    }

    /**
     * Sets the value of the pensionDebitIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPensionDebitIndicator(Boolean value) {
        this.pensionDebitIndicator = value;
    }

    /**
     * Gets the value of the pensionDebitAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPensionDebitAmount() {
        return pensionDebitAmount;
    }

    /**
     * Sets the value of the pensionDebitAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPensionDebitAmount(BigDecimal value) {
        this.pensionDebitAmount = value;
    }

    /**
     * Gets the value of the divorceDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDivorceDate() {
        return divorceDate;
    }

    /**
     * Sets the value of the divorceDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDivorceDate(XMLGregorianCalendar value) {
        this.divorceDate = value;
    }

    /**
     * Gets the value of the fsaCustomerCategorisation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFsaCustomerCategorisation() {
        return fsaCustomerCategorisation;
    }

    /**
     * Sets the value of the fsaCustomerCategorisation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFsaCustomerCategorisation(String value) {
        this.fsaCustomerCategorisation = value;
    }

    /**
     * Gets the value of the tvSplitIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTvSplitIndicator() {
        return tvSplitIndicator;
    }

    /**
     * Sets the value of the tvSplitIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTvSplitIndicator(Boolean value) {
        this.tvSplitIndicator = value;
    }

    /**
     * Gets the value of the pensionInPaymentIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPensionInPaymentIndicator() {
        return pensionInPaymentIndicator;
    }

    /**
     * Sets the value of the pensionInPaymentIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPensionInPaymentIndicator(Boolean value) {
        this.pensionInPaymentIndicator = value;
    }

    /**
     * Gets the value of the protectedTfcAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getProtectedTfcAmount() {
        return protectedTfcAmount;
    }

    /**
     * Sets the value of the protectedTfcAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setProtectedTfcAmount(BigDecimal value) {
        this.protectedTfcAmount = value;
    }

    /**
     * Gets the value of the fundAmountAtADay property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFundAmountAtADay() {
        return fundAmountAtADay;
    }

    /**
     * Sets the value of the fundAmountAtADay property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFundAmountAtADay(BigDecimal value) {
        this.fundAmountAtADay = value;
    }

    /**
     * Gets the value of the postADayAccrualIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPostADayAccrualIndicator() {
        return postADayAccrualIndicator;
    }

    /**
     * Sets the value of the postADayAccrualIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPostADayAccrualIndicator(Boolean value) {
        this.postADayAccrualIndicator = value;
    }

    /**
     * Gets the value of the internalTransferIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isInternalTransferIndicator() {
        return internalTransferIndicator;
    }

    /**
     * Sets the value of the internalTransferIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setInternalTransferIndicator(Boolean value) {
        this.internalTransferIndicator = value;
    }

    /**
     * Gets the value of the typeOfTransfer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfTransfer() {
        return typeOfTransfer;
    }

    /**
     * Sets the value of the typeOfTransfer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfTransfer(String value) {
        this.typeOfTransfer = value;
    }

    /**
     * Gets the value of the pensionProvider property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPensionProvider() {
        return pensionProvider;
    }

    /**
     * Sets the value of the pensionProvider property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPensionProvider(String value) {
        this.pensionProvider = value;
    }

    /**
     * Gets the value of the blockTransferIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isBlockTransferIndicator() {
        return blockTransferIndicator;
    }

    /**
     * Sets the value of the blockTransferIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setBlockTransferIndicator(Boolean value) {
        this.blockTransferIndicator = value;
    }

    /**
     * Gets the value of the earmarkingIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEarmarkingIndicator() {
        return earmarkingIndicator;
    }

    /**
     * Sets the value of the earmarkingIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEarmarkingIndicator(Boolean value) {
        this.earmarkingIndicator = value;
    }

    /**
     * Gets the value of the membersContribution property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMembersContribution() {
        return membersContribution;
    }

    /**
     * Sets the value of the membersContribution property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMembersContribution(BigDecimal value) {
        this.membersContribution = value;
    }

}
