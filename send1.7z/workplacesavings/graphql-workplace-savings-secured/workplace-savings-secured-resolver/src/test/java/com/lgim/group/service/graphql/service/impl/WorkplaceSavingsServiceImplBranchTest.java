package com.lgim.group.service.graphql.service.impl;

import org.springframework.test.context.TestPropertySource;

@TestPropertySource(properties = {"investment.details.service.url=http://localhost:9090", "allowable.funds.service.url=http://localhost:9090",
    "investment.availability.service.url=http://localhost:9090", "valuation.reason.code=SO", "entitlements.business.function=SWTC",
    "customer.details.service.url=http://localhost:9090",
    "fund.service.url=http://localhost:9090/lgim/funds/retrieveFundsDetail",
    "iminstruction.service.url=http://localhost:9090"})

public class WorkplaceSavingsServiceImplBranchTest extends WorkplaceSavingsServiceImplTest {


}