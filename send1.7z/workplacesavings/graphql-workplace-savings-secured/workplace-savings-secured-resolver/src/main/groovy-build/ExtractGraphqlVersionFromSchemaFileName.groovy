/**
 * Writes 2 files to the workplace-savings-secured-resolver/target
 * directory called:
 *      manage-your-account-graphql-schema-version.txt
 *      workplace-savings-graphql-schema-version.txt
 *
 * These files contain the schema version number for the corresponding GraphQL
 * schema files in the format major.minor.build
 */

def graphqlFilesWithVersionNumbers = getGraphqlSchemaFiles()
def manageYourAccountVersion = getManageYourAccountVersion(graphqlFilesWithVersionNumbers)
def workplaceSavingsVersion = getWorkplaceSavingsVersion(graphqlFilesWithVersionNumbers)
def outputDirectory = getOutputDirectory()

writeVersionFile("manage-your-account-graphql-schema-version.txt", manageYourAccountVersion, outputDirectory)
writeVersionFile("workplace-savings-graphql-schema-version.txt", workplaceSavingsVersion, outputDirectory)

/**
 * Ensures there are x2 GraphQL schema files and returns their names.
 *      manageYourAccount_vX.X.X.graphqls
 *      workplaceSavings_vX.X.X.graphqls
 *
 * @return the list of GraphQL schema file names
 */
private def getGraphqlSchemaFiles() {
    File resourcesDir = new File("${basedir}/../api/src/main/resources/graphql")
    def regexForTestingVersionNumberExistsInFileName = /.+_v[0-9\.]+\.graphqls/

    println "Checking for GraphQL schema files in [$resourcesDir]"
    def graphqlFilesWithVersionNumbers = resourcesDir.list().findAll { it =~ regexForTestingVersionNumberExistsInFileName}

    if(graphqlFilesWithVersionNumbers.size() != 2) {
        throw new RuntimeException("Only 2 graphql files should be found containing a version but actually found [${graphqlFilesWithVersionNumbers.size()}], they were $graphqlFilesWithVersionNumbers . ")
    }

    println "Found the following graphql schema files [${graphqlFilesWithVersionNumbers}]"

    return graphqlFilesWithVersionNumbers
}

/**
 * @param graphqlSchemaFilenames the list of GraphQL schema files
 * @return the manage you account schema version number
 */
def getManageYourAccountVersion(graphqlSchemaFilenames) {
    def regexForExtractingManageYourAccountVersionNumberFromFileName = /manageYourAccount_v([0-9\.]+)\.graphqls/
    def manageYourAccountVersion = (graphqlSchemaFilenames[0] =~ /$regexForExtractingManageYourAccountVersionNumberFromFileName/)[0][1]

    if(!isVersionFormatValid(manageYourAccountVersion)) {
        throw new RuntimeException("Manage Your Account extracted schema version is not in required format [$manageYourAccountVersion]")
    }

    println "Manage Your Account GraphQL schema version found is [${manageYourAccountVersion}]"

    return manageYourAccountVersion
}
/**
 *  @param graphqlSchemaFilenames the list of GraphQL schema files
 *  @return the workplace savings schema version number
 */
def getWorkplaceSavingsVersion(graphqlSchemaFilenames) {
    def regexForExtractingWorkplaceSavingsVersionNumberFromFileName = /workplaceSavings_v([0-9\.]+)\.graphqls/
    def workplaceSavingsVersion = (graphqlSchemaFilenames[1] =~ /$regexForExtractingWorkplaceSavingsVersionNumberFromFileName/)[0][1]

    if(!isVersionFormatValid(workplaceSavingsVersion)) {
        throw new RuntimeException("Workplace Savings extracted schema version is not in required format [$workplaceSavingsVersion]")
    }

    println "Workplace Savings GraphQL schema version found is [${workplaceSavingsVersion}]"

    return workplaceSavingsVersion
}

/**
 * @param version the version to check
 * @return true if version format is valid otherwise false
 */
def static isVersionFormatValid(version) {
    if (!version =~ /[0-9\.]+/) {
        return false
    }

    return true
}

/**
 * Gets the name of path to the output directory.
 *
 * @returns the string pathname to output
 */
def static getOutputDirectory() {
    createTargetDirectory()

    def currentFolder = new File(".").getAbsoluteFile().getParentFile().getName()

    if("workplace-savings-secured-resolver".equals(currentFolder)) {
        return "target/"
    } else {
        return "./workplace-savings-secured-resolver/target/"
    }
}

/**
 * Creates the target directory depending on current directory.
 */
def static createTargetDirectory() {
    def currentFolder = new File(".").getAbsoluteFile().getParentFile().getName()

    if("workplace-savings-secured-resolver".equals(currentFolder)) {
        new File("target/classes").mkdir()
    } else {
        new File("./workplace-savings-secured-resolver/target/classes").mkdir()
    }
}

/**
 * Writes a file to the output directory with the give name and the
 * version is written to the file contents.
 *
 * @param filename the file name to use
 * @param version the version to write into the file
 * @param outputDirectory the directory to write the file to
 */
def writeVersionFile(filename, version, outputDirectory) {
    def fileName = (String) (outputDirectory + filename)
    def graphqlSchemaVersionFile = new File(fileName)

    graphqlSchemaVersionFile.text = version

    println "GraphQL schema version file written to [$graphqlSchemaVersionFile.absolutePath]"
    println "File exists: [" + graphqlSchemaVersionFile.exists() + "]"
}
