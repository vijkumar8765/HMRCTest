
package lbf_acct_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_AcctLoc complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_AcctLoc"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="roleTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="contractEngineType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="productHoldingType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="valuationClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountInception" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountExpiry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="groupArrangementID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_AcctLoc", propOrder = {
    "roleTypeCode",
    "accountID",
    "contractEngineType",
    "productHoldingType",
    "valuationClass",
    "accountStatus",
    "accountInception",
    "accountExpiry",
    "groupArrangementID"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGAcctLoc
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String roleTypeCode;
    protected String accountID;
    protected String contractEngineType;
    protected String productHoldingType;
    protected String valuationClass;
    protected String accountStatus;
    protected String accountInception;
    protected String accountExpiry;
    protected String groupArrangementID;

    /**
     * Gets the value of the roleTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoleTypeCode() {
        return roleTypeCode;
    }

    /**
     * Sets the value of the roleTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoleTypeCode(String value) {
        this.roleTypeCode = value;
    }

    /**
     * Gets the value of the accountID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountID() {
        return accountID;
    }

    /**
     * Sets the value of the accountID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountID(String value) {
        this.accountID = value;
    }

    /**
     * Gets the value of the contractEngineType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractEngineType() {
        return contractEngineType;
    }

    /**
     * Sets the value of the contractEngineType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractEngineType(String value) {
        this.contractEngineType = value;
    }

    /**
     * Gets the value of the productHoldingType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductHoldingType() {
        return productHoldingType;
    }

    /**
     * Sets the value of the productHoldingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductHoldingType(String value) {
        this.productHoldingType = value;
    }

    /**
     * Gets the value of the valuationClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValuationClass() {
        return valuationClass;
    }

    /**
     * Sets the value of the valuationClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValuationClass(String value) {
        this.valuationClass = value;
    }

    /**
     * Gets the value of the accountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountStatus() {
        return accountStatus;
    }

    /**
     * Sets the value of the accountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountStatus(String value) {
        this.accountStatus = value;
    }

    /**
     * Gets the value of the accountInception property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountInception() {
        return accountInception;
    }

    /**
     * Sets the value of the accountInception property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountInception(String value) {
        this.accountInception = value;
    }

    /**
     * Gets the value of the accountExpiry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountExpiry() {
        return accountExpiry;
    }

    /**
     * Sets the value of the accountExpiry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountExpiry(String value) {
        this.accountExpiry = value;
    }

    /**
     * Gets the value of the groupArrangementID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupArrangementID() {
        return groupArrangementID;
    }

    /**
     * Sets the value of the groupArrangementID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupArrangementID(String value) {
        this.groupArrangementID = value;
    }

}
