package com.lgim.group.service.graphql.dto;

public enum BenefitType {
  REGULAR,
  SINGLE,
  TRANSFERVALUE
}
