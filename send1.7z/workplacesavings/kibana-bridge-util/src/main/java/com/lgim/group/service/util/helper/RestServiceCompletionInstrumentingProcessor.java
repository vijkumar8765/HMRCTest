package com.lgim.group.service.util.helper;

import com.lgim.group.ws.utility.plugin.model.AuditData;
import com.lgim.group.ws.utility.plugin.model.GroupDigitalMessage;
import com.lgim.group.ws.utility.plugin.model.MailAlertData;
import com.lgim.group.ws.utility.plugin.util.AuditRouteHelper;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.CamelContextAware;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.stereotype.Component;

@Slf4j
@Component
/**
 * This class is used to intercept when an exchange has been completed and provide log output for ElasticSearch/Kibana. Usage:-
 *
 *     rest("/holdings/policy/")
 *         .id(InvestmentDetailsConstants.LGIM_RETRIEVE_POLICY_HOLDINGS_REST_ROUTE_ID)
 *         .get("{policyNumber}")
 *         .produces("application/json")
 *         .outType(InvestmentDetailDto.class)
 *         //****** INSERT FROM HERE
 *         .route()
 *         .onCompletion()
 *           .process(new RestServiceCompletionInstrumentingProcessor())
 *         .end()
 *         //******* END OF CODE TO INSERT
 *         .log(INFO, "ws-policy-holdings-rest-route Call Started..")
 *
 */
public class RestServiceCompletionInstrumentingProcessor implements Processor, CamelContextAware {

  private CamelContext camelContext;
  private ProducerTemplate producerTemplate;

  GroupDigitalMessage populateGroupDigitalMessageWithDefaults(GroupDigitalMessage originalGroupDigitalMessage) {
    GroupDigitalMessage gdm = GroupDigitalMessage.builder()
        .businessFunction(originalGroupDigitalMessage.getBusinessFunction())
        .journeyId(originalGroupDigitalMessage.getJourneyId())
        .microserviceMethod(originalGroupDigitalMessage.getMicroserviceMethod())
        .microserviceName(originalGroupDigitalMessage.getMicroserviceName())
        .systemId(originalGroupDigitalMessage.getSystemId())
        .auditData(new AuditData())
        .alertData(new MailAlertData())
        .build();
    gdm.setTags(new HashMap<>());
    gdm.setPayloads(new HashMap<>());
    gdm.setErrors(new ArrayList<>());
    gdm.getTags().put("is_framework_generated", "true");
    gdm.getTags().put("endpointUriActual", originalGroupDigitalMessage.getTags().get("endpointUriActual"));
    gdm.getTags().put("endpointUriCleansed", originalGroupDigitalMessage.getTags().get("endpointUriCleansed"));
    gdm.getTags().put("endpointUriDefinition", originalGroupDigitalMessage.getTags().get("endpointUriDefinition"));
    gdm.getAuditData().setUpdatedAt(ZonedDateTime.now());
    gdm.getAuditData().setCreatedAt(ZonedDateTime.now());
    return gdm;
  }

  GroupDigitalMessage createGroupDigitalMessage(GroupDigitalMessage originalGroupDigitalMessage, Map<String, String> extraTags, HashMap<String, String> extraPayloads) {
    GroupDigitalMessage groupDigitalMessage = populateGroupDigitalMessageWithDefaults(originalGroupDigitalMessage);
    groupDigitalMessage.getTags().putAll(extraTags);
    groupDigitalMessage.getPayloads().putAll(extraPayloads);
    return groupDigitalMessage;
  }


  @Override
  public void process(Exchange exchange) throws Exception {
    log.info("Completed REST call, preparing GroupDigitalMessage for auditing");
    GroupDigitalMessage originalGroupDigitalMessage = exchange.getProperty(
        CamelRouteInstrumentationHelper.GROUP_DIGITAL_MESSAGE_FOR_INCOMING_REST_PROPERTY_KEY,
        GroupDigitalMessage.class);
    HashMap<String, String> extraTags = new HashMap<>();
    HashMap<String, String> extraPayloads = new HashMap<>();
    Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
    if(exception != null) {
      extraTags.put("is_exception", "true");
      extraPayloads.put("exception_message", exception.getMessage());
      extraPayloads.put("exception", ExceptionUtils.getStackTrace(exception));
      extraTags.put("status", "REST service unable to complete due to exception for endpoint " + originalGroupDigitalMessage.getTags().get("endpointUriCleansed"));
    } else {
      extraTags.put("status", "Completed servicing REST call on endpoint " + originalGroupDigitalMessage.getTags().get("endpointUriCleansed"));
    }
    long timeTakenInMillis = new Date().getTime() - originalGroupDigitalMessage.getAuditData().getCreatedAt().toInstant().toEpochMilli();
    extraTags.put("service_request_response_duration_integer", Long.toString(timeTakenInMillis));
    extraTags.put("is_framework_generated", "true");
    extraTags.put("is_response","true");
    extraTags.put("protocol", "rest");
    GroupDigitalMessage groupDigitalMessage = createGroupDigitalMessage(originalGroupDigitalMessage, extraTags, extraPayloads);
    new AuditRouteHelper().sendGroupDigitalMessageForAuditing(producerTemplate, groupDigitalMessage);
  }

  @Override
  public void setCamelContext(CamelContext camelContext) {
    this.camelContext = camelContext;
    this.producerTemplate = camelContext.createProducerTemplate();
  }

  @Override
  public CamelContext getCamelContext() {
    return camelContext;
  }
}
