package com.lgim.group.gatekeeper.processor;

import com.lgim.group.gatekeeper.exception.JwtAuthenticationException;
import com.lgim.group.gatekeeper.helpers.PublicKeyHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@Slf4j
public class ValidateJwtTokenProcessor implements Processor {

  private static final String AUTHORIZATION_HEADER = "Authorization";

  @Autowired
  private PublicKeyHelper publicKeyHelper;

  @Override
  public void process(Exchange exchange) throws  JwtAuthenticationException {

    //Extract the authorization header
    String authorizationHeader = (String)exchange.getIn().getHeader(AUTHORIZATION_HEADER);

    if (authorizationHeader == null  || authorizationHeader.equals("null") || authorizationHeader.length() < 7) {
      throw new JwtAuthenticationException("Missing Authorization Header or Bearer token is null");
    }

    //Remove the 'Bearer ' prefix from the authorization Header
    String bearerText = authorizationHeader.substring(0,7);

    if (!bearerText.toUpperCase().equals("BEARER ")) {
      throw new JwtAuthenticationException(String.format("Invalid Authorization Header, missing 'Bearer' ? [%s]",authorizationHeader));
    }


    String token = authorizationHeader.replace(bearerText,"");

    if (token != null && token.trim().length() == 0) {
      throw new JwtAuthenticationException(String.format("Invalid Authorization Header [%s]",authorizationHeader));
    }

    //Validate the JWT token
    Map<String,Object> claims = publicKeyHelper.validateToken(token);

    exchange.getIn().setHeader("CLAIMS",claims);

  }
}
