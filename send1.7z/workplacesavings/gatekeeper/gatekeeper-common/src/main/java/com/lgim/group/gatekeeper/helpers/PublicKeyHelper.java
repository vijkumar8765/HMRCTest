package com.lgim.group.gatekeeper.helpers;

import com.lgim.group.gatekeeper.exception.JwtAuthenticationException;
import com.lgim.group.gatekeeper.exception.PublicKeyException;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.RemoteKeySourceException;
import com.nimbusds.jose.jwk.JWKMatcher;
import com.nimbusds.jose.jwk.JWKSelector;
import com.nimbusds.jose.jwk.KeyType;
import com.nimbusds.jose.jwk.KeyUse;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.jwk.source.RemoteJWKSet;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.proc.BadJWTException;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Component
@Slf4j
/**
 * This class is used to encapsulate the logic required to
 * validate JWT tokens
 */
public class PublicKeyHelper {

  @Value("${public_key_url}")
  private String publicKeyURL;

  @Value("${feature_toggle_gatekeeper_test_mode:false}")
  private Boolean featureToggleGatekeeperTestMode;

  @Autowired
  private JwtValidator jwtValidator;

  @Value("${gatekeeper_date:null}")
  private String dateString;


  //We are using a lock here to ensure we don't update the public key whilst valdiating a token
  private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

  private JWKSource publicKey = null;

  //This is the algorithm we expect to see all JWT tokens signed using
  private final JWSAlgorithm expectedJWSAlg = JWSAlgorithm.RS256;

  private ReentrantReadWriteLock getLock() {
    return lock;
  }

  public JWKSource getPublicKey() {
    return publicKey;
  }

  private void setPublicKey(JWKSource jwtSource) throws PublicKeyException {
    try {
      lock.writeLock().lock();
      publicKey = jwtSource;
    } catch (Exception exception) {
      throw new PublicKeyException("Unable to set Public Key", exception);
    } finally {
      lock.writeLock().unlock();
    }
  }

  /**
  *  This method is used to fetch the public key for valdiating JWT tokens signatures
  */
  public void fetchPublicKey() {
    try {

      if (featureToggleGatekeeperTestMode.booleanValue()) {
        return;
      }

      RemoteJWKSet keySource = new RemoteJWKSet(new URL(publicKeyURL));

      /*
            The code below is required in order to actually fetch the token
            without the code the token will only ever be fetched when a
            token has been received, for performance reasons the code below
            will fetch the key and have it cached ready for a JWT validation Req
       */

      JWKMatcher matcher = new JWKMatcher.Builder()
          .keyType(KeyType.forAlgorithm(expectedJWSAlg))
          .keyUse(KeyUse.SIGNATURE)
          .build();

      keySource.get(new JWKSelector(matcher), null);

      //For the first time we fetch the public key, log successfully fetch
      if (publicKey == null) {
        log.info("Successfully fetched public key from " + publicKeyURL);
      }

      //We only overwrite the public key used for valdiating tokens once we have successfully pulled the public key again
      setPublicKey(keySource);

    } catch (PublicKeyException | RemoteKeySourceException remoteKeySourceException) {
      log.error(String.format("Failed to fetch public Key from [%s]", publicKeyURL), remoteKeySourceException);
    } catch (MalformedURLException malformedURLException) {
      log.error(String.format("Public Key URL invalid [%s]", publicKeyURL), malformedURLException);
    }
  }

  /**
   * This method is used to valdiate a JWT token
   * @param token The token to valdiate
   * @return A map of claims contained within the token
   * @throws JwtAuthenticationException Thrown mainly if the token isn't valid
   */
  public Map<String, Object> validateToken(String token) throws JwtAuthenticationException {

    /*
        Feature Toggle Gatekeeper Test Mode
        Turns off token checking and returns a claims map containing partyId populated
        with the value in the token, this is to allow unit testing without generating
        proper tokens from Keycloak.
    */

    if (featureToggleGatekeeperTestMode.booleanValue()) {
      log.warn("******GATEKEEPER IN FEATURE TOGGLE MODE!******");
      Map<String, Object> claims = new HashMap<>();
      claims.put("partyId", token);

      return claims;
    }

    try {

      //Get a read lock so that we stop the fetch public key process from being able to update the public key
      getLock().readLock().lock();

      ConfigurableJWTProcessor jwtProcessor = new DefaultJWTProcessor();

      JWSKeySelector keySelector = new JWSVerificationKeySelector(expectedJWSAlg, publicKey);

      jwtProcessor.setJWSKeySelector(keySelector);

      //Rule our JWT validation rules against the token
      jwtProcessor.setJWTClaimsSetVerifier(jwtValidator);

      JWTClaimsSet claimsSet = jwtProcessor.process(token, null);

      return claimsSet.getClaims();

    } catch (ParseException | JOSEException parseException) {
      throw new JwtAuthenticationException("Error parsing JWT token", parseException);
    } catch (BadJWTException exception) {
      throw new JwtAuthenticationException(exception.getMessage(), exception);
    } catch (Exception exception) {
      throw new JwtAuthenticationException("Invalid JWT token", exception);
    } finally {
      //Release the read lock
      getLock().readLock().unlock();
    }
  }

}
