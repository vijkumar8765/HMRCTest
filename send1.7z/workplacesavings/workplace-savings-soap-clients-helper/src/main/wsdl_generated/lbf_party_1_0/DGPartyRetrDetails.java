
package lbf_party_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_PartyRetrDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_PartyRetrDetails"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="partyId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="partySubType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="partyDetails" type="{http://LBF_Party_1_0}DG_PartyDetails" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_PartyRetrDetails", propOrder = {
    "partyId",
    "partySubType",
    "partyDetails"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGPartyRetrDetails
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String partyId;
    protected String partySubType;
    protected DGPartyDetails partyDetails;

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the partySubType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartySubType() {
        return partySubType;
    }

    /**
     * Sets the value of the partySubType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartySubType(String value) {
        this.partySubType = value;
    }

    /**
     * Gets the value of the partyDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGPartyDetails }
     *     
     */
    public DGPartyDetails getPartyDetails() {
        return partyDetails;
    }

    /**
     * Sets the value of the partyDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPartyDetails }
     *     
     */
    public void setPartyDetails(DGPartyDetails value) {
        this.partyDetails = value;
    }

}
