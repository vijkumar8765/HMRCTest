
package lbb_personcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_ContactDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_ContactDetails"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="addresses" type="{http://LBB_PersonCommon_1_0}DG_PostalAddresses" minOccurs="0"/&gt;
 *         &lt;element name="emailAddresses" type="{http://LBB_PersonCommon_1_0}DG_EmailAddresses" minOccurs="0"/&gt;
 *         &lt;element name="telephoneNumbers" type="{http://LBB_PersonCommon_1_0}DG_TelephoneNumbers" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_ContactDetails", propOrder = {
    "addresses",
    "emailAddresses",
    "telephoneNumbers"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGContactDetails
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGPostalAddresses addresses;
    protected DGEmailAddresses emailAddresses;
    protected DGTelephoneNumbers telephoneNumbers;

    /**
     * Gets the value of the addresses property.
     * 
     * @return
     *     possible object is
     *     {@link DGPostalAddresses }
     *     
     */
    public DGPostalAddresses getAddresses() {
        return addresses;
    }

    /**
     * Sets the value of the addresses property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPostalAddresses }
     *     
     */
    public void setAddresses(DGPostalAddresses value) {
        this.addresses = value;
    }

    /**
     * Gets the value of the emailAddresses property.
     * 
     * @return
     *     possible object is
     *     {@link DGEmailAddresses }
     *     
     */
    public DGEmailAddresses getEmailAddresses() {
        return emailAddresses;
    }

    /**
     * Sets the value of the emailAddresses property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGEmailAddresses }
     *     
     */
    public void setEmailAddresses(DGEmailAddresses value) {
        this.emailAddresses = value;
    }

    /**
     * Gets the value of the telephoneNumbers property.
     * 
     * @return
     *     possible object is
     *     {@link DGTelephoneNumbers }
     *     
     */
    public DGTelephoneNumbers getTelephoneNumbers() {
        return telephoneNumbers;
    }

    /**
     * Sets the value of the telephoneNumbers property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGTelephoneNumbers }
     *     
     */
    public void setTelephoneNumbers(DGTelephoneNumbers value) {
        this.telephoneNumbers = value;
    }

}
