package com.lgim.group.service.customerprofile.exception.handler;

import com.lgim.group.gatekeeper.exception.JwtAuthenticationException;
import com.lgim.group.service.customerprofile.dto.ApiError;
import com.lgim.group.service.customerprofile.dto.ImmutableApiError;
import com.lgim.group.service.customerprofile.exception.CustomerNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.TypeMismatchException;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Spring API exception handlers which determine how to respond deal with exceptions in a friendly way for API users.
 * In quiet mode, such as production, the information returned by these exception handlers is reduced to just the HTTP status code.
 */
@Slf4j
@ControllerAdvice
@SuppressWarnings({"PMD.TooManyMethods", "PMD.ExcessiveImports"})
public class CustomResponseEntityExceptionHandler {

  private final Environment environment;

  public CustomResponseEntityExceptionHandler(final Environment environment) {
    super();
    this.environment = environment;
  }

  // 400

  @ExceptionHandler(MethodArgumentNotValidException.class)
  protected ResponseEntity<Object> handleMethodArgumentNotValidException(final MethodArgumentNotValidException exception) {
    log.info(exception.getClass().getName());

    if (isQuietMode()) {
      return ResponseEntity.badRequest().build();
    }

    final BindingResult bindingResult = exception.getBindingResult();

    return handleBindingResultException(exception, bindingResult.getFieldErrors(), bindingResult.getGlobalErrors());
  }

  @ExceptionHandler(BindException.class)
  protected ResponseEntity<Object> handleBindException(final BindException exception) {
    log.info(exception.getClass().getName());

    if (isQuietMode()) {
      return ResponseEntity.badRequest().build();
    }

    return handleBindingResultException(exception, exception.getFieldErrors(), exception.getGlobalErrors());
  }

  @ExceptionHandler(HttpMessageNotReadableException.class)
  protected ResponseEntity<Object> handleHttpMessageNotReadableException(final HttpMessageNotReadableException exception) {
    log.info(exception.getClass().getName());
    final HttpStatus httpStatus = HttpStatus.BAD_REQUEST;

    if (isQuietMode()) {
      return ResponseEntity.status(httpStatus).build();
    }

    final List<String> errors = Collections.singletonList(exception.getLocalizedMessage());

    final ApiError apiError = ImmutableApiError
        .builder()
        .withHttpStatus(httpStatus)
        .withMessage("The request is badly formatted and could not be read")
        .withErrors(errors)
        .build();
    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getHttpStatus());
  }

  @ExceptionHandler(TypeMismatchException.class)
  protected ResponseEntity<Object> handleTypeMismatchException(final TypeMismatchException exception) {
    log.info(exception.getClass().getName());
    final HttpStatus httpStatus = HttpStatus.BAD_REQUEST;

    if (isQuietMode()) {
      return ResponseEntity.status(httpStatus).build();
    }

    final String error = exception.getValue() + " value for " + exception.getPropertyName() + " should be of type " + exception.getRequiredType();
    final List<String> errors = Collections.singletonList(error);

    final ApiError apiError = ImmutableApiError
        .builder()
        .withHttpStatus(httpStatus)
        .withMessage(exception.getLocalizedMessage())
        .withErrors(errors)
        .build();
    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getHttpStatus());
  }

  @ExceptionHandler(MethodArgumentTypeMismatchException.class)
  protected ResponseEntity<Object> handleMethodArgumentTypeMismatchException(final MethodArgumentTypeMismatchException exception) {
    log.info(exception.getClass().getName());
    final HttpStatus httpStatus = HttpStatus.BAD_REQUEST;

    if (isQuietMode()) {
      return ResponseEntity.status(httpStatus).build();
    }

    final String error = exception.getName() + " should be of type " + Optional.ofNullable(exception.getRequiredType()).map(Class::getName).orElse("unknown");
    final List<String> errors = Collections.singletonList(error);

    final ApiError apiError = ImmutableApiError
        .builder()
        .withHttpStatus(httpStatus)
        .withMessage(exception.getLocalizedMessage())
        .withErrors(errors)
        .build();
    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getHttpStatus());
  }

  @ExceptionHandler(JwtAuthenticationException.class)
  protected ResponseEntity<Object> handleJwtAuthenticationException(final JwtAuthenticationException exception) {
    log.info(exception.getClass().getName());
    final HttpStatus httpStatus = HttpStatus.UNAUTHORIZED;

    if (isQuietMode()) {
      return ResponseEntity.status(httpStatus).build();
    }

    final ApiError apiError = ImmutableApiError
        .builder()
        .withHttpStatus(httpStatus)
        .withMessage(exception.getLocalizedMessage())
        .build();
    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getHttpStatus());
  }

  /**
   * TODO - This should be a 404 Not Found. Unfortunately the Stored Procedure
   * call throws an exception when the connection is unavailable but also when
   * there is no customer found for the given ID. For now we'll return 500.
   *
   * @param exception the customer not found exception
   * @return the error response entity
   */
  @ExceptionHandler(CustomerNotFoundException.class)
  protected ResponseEntity<Object> handleCustomerNotFoundException(final CustomerNotFoundException exception) {
    log.info(exception.getClass().getName());
    final HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;

    if (isQuietMode()) {
      return ResponseEntity.status(httpStatus).build();
    }

    final ApiError apiError = ImmutableApiError
        .builder()
        .withHttpStatus(httpStatus)
        .withMessage(exception.getLocalizedMessage())
        .withErrors(exception.getErrors())
        .build();
    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getHttpStatus());
  }

  // 404

  @ExceptionHandler(NoHandlerFoundException.class)
  protected ResponseEntity<Object> handleNotFoundException(final Exception exception) {
    log.info(exception.getClass().getName());
    final HttpStatus httpStatus = HttpStatus.NOT_FOUND;

    if (isQuietMode()) {
      return ResponseEntity.status(httpStatus).build();
    }

    final ApiError apiError = ImmutableApiError
        .builder()
        .withHttpStatus(httpStatus)
        .withMessage(exception.getLocalizedMessage())
        .build();

    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getHttpStatus());
  }

  // 405
  @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
  protected ResponseEntity<Object> handleHttpRequestMethodNotSupportedException(final HttpRequestMethodNotSupportedException exception) {
    log.info(exception.getClass().getName());
    final HttpStatus httpStatus = HttpStatus.METHOD_NOT_ALLOWED;

    if (isQuietMode()) {
      return ResponseEntity.status(httpStatus).build();
    }

    final StringBuilder builder = new StringBuilder(100);
    builder.append(Optional.ofNullable(exception.getMethod()).orElse("unknown")).append(" method is not supported for this request. Supported methods are: ");
    return handleExceptionWithSupportedTypes(exception, httpStatus, exception.getSupportedHttpMethods(), builder);
  }

  // 406

  @ExceptionHandler(HttpMediaTypeNotAcceptableException.class)
  protected ResponseEntity handleHttpMediaTypeNotAcceptableException(final HttpMediaTypeNotAcceptableException exception) {
    log.info(exception.getClass().getName());
    final HttpStatus httpStatus = HttpStatus.NOT_ACCEPTABLE;
    return ResponseEntity.status(httpStatus).build();
  }

  // 415

  @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
  protected ResponseEntity<Object> handleHttpMediaTypeNotSupportedException(final HttpMediaTypeNotSupportedException exception) {
    log.info(exception.getClass().getName());
    final HttpStatus httpStatus = HttpStatus.UNSUPPORTED_MEDIA_TYPE;

    if (isQuietMode()) {
      return ResponseEntity.status(httpStatus).build();
    }

    final StringBuilder builder = new StringBuilder(150);
    builder.append(exception.getContentType()).append(" media type is not supported. Supported media types are: ");
    return handleExceptionWithSupportedTypes(exception, httpStatus, exception.getSupportedMediaTypes(), builder);
  }

  // 500

  @ExceptionHandler(Exception.class)
  protected ResponseEntity<Object> handleAllExceptions(final Exception exception) {
    log.info(exception.getClass().getName());
    log.error("An exception has been thrown without a specific exception handler: ", exception);

    final HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;

    if (isQuietMode()) {
      return ResponseEntity.status(httpStatus).build();
    }

    final ApiError apiError = ImmutableApiError
        .builder()
        .withHttpStatus(httpStatus)
        .withMessage(exception.getLocalizedMessage())
        .build();
    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getHttpStatus());
  }

  private ResponseEntity<Object> handleExceptionWithSupportedTypes(
      final Exception exception, final HttpStatus httpStatus, final Iterable<?> supportedTypes, final StringBuilder errorBuilder) {

    supportedTypes.forEach(type -> errorBuilder.append(type).append(", "));
    final List<String> errors = Collections.singletonList(errorBuilder.substring(0, errorBuilder.length() - 2));

    final ApiError apiError = ImmutableApiError
        .builder()
        .withHttpStatus(httpStatus)
        .withMessage(exception.getLocalizedMessage())
        .withErrors(errors)
        .build();

    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getHttpStatus());
  }

  private ResponseEntity<Object> handleBindingResultException(final Exception exception,
                                                              final List<FieldError> fieldErrors,
                                                              final List<ObjectError> globalErrors) {

    final List<String> errors = new ArrayList<>();

    fieldErrors.forEach(error -> errors.add(error.getField() + ": " + error.getDefaultMessage()));

    globalErrors.forEach(error -> errors.add(error.getObjectName() + ": " + error.getDefaultMessage()));

    final ApiError apiError = ImmutableApiError
        .builder()
        .withHttpStatus(HttpStatus.BAD_REQUEST)
        .withMessage(exception.getLocalizedMessage())
        .withErrors(errors)
        .build();
    return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getHttpStatus());
  }

  private boolean isQuietMode() {
    final List<String> profiles = Arrays.asList(environment.getActiveProfiles());
    return profiles.contains("prod");
  }
}
