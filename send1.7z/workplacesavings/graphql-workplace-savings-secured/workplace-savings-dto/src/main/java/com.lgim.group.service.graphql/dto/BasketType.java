package com.lgim.group.service.graphql.dto;

public enum BasketType {
  HOLDINGS, CONTRIBUTIONS
}
