
package lbb_personcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_VerifiableDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_VerifiableDetails"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dateOfBirth" type="{http://LBB_PersonCommon_1_0}DG_DateOfBirth" minOccurs="0"/&gt;
 *         &lt;element name="name" type="{http://LBB_PersonCommon_1_0}DG_PersonName" minOccurs="0"/&gt;
 *         &lt;element name="gender" type="{http://LBB_PersonCommon_1_0}DG_Gender" minOccurs="0"/&gt;
 *         &lt;element name="maritalStatus" type="{http://LBB_PersonCommon_1_0}DG_MaritalStatus" minOccurs="0"/&gt;
 *         &lt;element name="niNumber" type="{http://LBB_PersonCommon_1_0}DG_NINumber" minOccurs="0"/&gt;
 *         &lt;element name="ageAddmitted" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_VerifiableDetails", propOrder = {
    "dateOfBirth",
    "name",
    "gender",
    "maritalStatus",
    "niNumber",
    "ageAddmitted"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGVerifiableDetails
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGDateOfBirth dateOfBirth;
    protected DGPersonName name;
    protected String gender;
    protected String maritalStatus;
    protected String niNumber;
    protected Boolean ageAddmitted;

    /**
     * Gets the value of the dateOfBirth property.
     * 
     * @return
     *     possible object is
     *     {@link DGDateOfBirth }
     *     
     */
    public DGDateOfBirth getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Sets the value of the dateOfBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGDateOfBirth }
     *     
     */
    public void setDateOfBirth(DGDateOfBirth value) {
        this.dateOfBirth = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link DGPersonName }
     *     
     */
    public DGPersonName getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPersonName }
     *     
     */
    public void setName(DGPersonName value) {
        this.name = value;
    }

    /**
     * Gets the value of the gender property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGender() {
        return gender;
    }

    /**
     * Sets the value of the gender property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGender(String value) {
        this.gender = value;
    }

    /**
     * Gets the value of the maritalStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * Sets the value of the maritalStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaritalStatus(String value) {
        this.maritalStatus = value;
    }

    /**
     * Gets the value of the niNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNiNumber() {
        return niNumber;
    }

    /**
     * Sets the value of the niNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNiNumber(String value) {
        this.niNumber = value;
    }

    /**
     * Gets the value of the ageAddmitted property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAgeAddmitted() {
        return ageAddmitted;
    }

    /**
     * Sets the value of the ageAddmitted property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAgeAddmitted(Boolean value) {
        this.ageAddmitted = value;
    }

}
