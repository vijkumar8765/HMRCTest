
package lbb_personlocate_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lbb_personcommon_1_0.DGInitials;
import lbb_personcommon_1_0.DGPersonName;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_LocatedPerson complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_LocatedPerson"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="partyId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="personName" type="{http://LBB_PersonCommon_1_0}DG_PersonName" minOccurs="0"/&gt;
 *         &lt;element name="initial" type="{http://LBB_PersonCommon_1_0}DG_Initials" minOccurs="0"/&gt;
 *         &lt;element name="title" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="gender" type="{http://LBB_PersonCommon_1_0}DG_Gender" minOccurs="0"/&gt;
 *         &lt;element name="dateOfBirth" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="nationalInsuranceNumber" type="{http://LBB_PersonCommon_1_0}DG_NINumber" minOccurs="0"/&gt;
 *         &lt;element name="ageAdmittedIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="maritalStatus" type="{http://LBB_PersonCommon_1_0}DG_MaritalStatus" minOccurs="0"/&gt;
 *         &lt;element name="smokerType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="marketingAttitudeType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="servicingAttitudeType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="personDetailsVerifiedIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="addressDetails" type="{http://LBB_PersonLocate_1_0}DG_AddressDetails" minOccurs="0"/&gt;
 *         &lt;element name="deathDetails" type="{http://LBB_PersonLocate_1_0}DG_DeathDetails" minOccurs="0"/&gt;
 *         &lt;element name="bankruptcyDetails" type="{http://LBB_PersonLocate_1_0}DG_BankruptcyDetails" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_LocatedPerson", propOrder = {
    "partyId",
    "personName",
    "initial",
    "title",
    "gender",
    "dateOfBirth",
    "nationalInsuranceNumber",
    "ageAdmittedIndicator",
    "maritalStatus",
    "smokerType",
    "marketingAttitudeType",
    "servicingAttitudeType",
    "personDetailsVerifiedIndicator",
    "addressDetails",
    "deathDetails",
    "bankruptcyDetails"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGLocatedPerson
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String partyId;
    protected DGPersonName personName;
    protected DGInitials initial;
    protected String title;
    protected String gender;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateOfBirth;
    protected String nationalInsuranceNumber;
    protected Boolean ageAdmittedIndicator;
    protected String maritalStatus;
    protected String smokerType;
    protected String marketingAttitudeType;
    protected String servicingAttitudeType;
    protected Boolean personDetailsVerifiedIndicator;
    protected DGAddressDetails addressDetails;
    protected DGDeathDetails deathDetails;
    protected DGBankruptcyDetails bankruptcyDetails;

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the personName property.
     * 
     * @return
     *     possible object is
     *     {@link DGPersonName }
     *     
     */
    public DGPersonName getPersonName() {
        return personName;
    }

    /**
     * Sets the value of the personName property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPersonName }
     *     
     */
    public void setPersonName(DGPersonName value) {
        this.personName = value;
    }

    /**
     * Gets the value of the initial property.
     * 
     * @return
     *     possible object is
     *     {@link DGInitials }
     *     
     */
    public DGInitials getInitial() {
        return initial;
    }

    /**
     * Sets the value of the initial property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGInitials }
     *     
     */
    public void setInitial(DGInitials value) {
        this.initial = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Gets the value of the gender property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGender() {
        return gender;
    }

    /**
     * Sets the value of the gender property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGender(String value) {
        this.gender = value;
    }

    /**
     * Gets the value of the dateOfBirth property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Sets the value of the dateOfBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfBirth(XMLGregorianCalendar value) {
        this.dateOfBirth = value;
    }

    /**
     * Gets the value of the nationalInsuranceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNationalInsuranceNumber() {
        return nationalInsuranceNumber;
    }

    /**
     * Sets the value of the nationalInsuranceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNationalInsuranceNumber(String value) {
        this.nationalInsuranceNumber = value;
    }

    /**
     * Gets the value of the ageAdmittedIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAgeAdmittedIndicator() {
        return ageAdmittedIndicator;
    }

    /**
     * Sets the value of the ageAdmittedIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAgeAdmittedIndicator(Boolean value) {
        this.ageAdmittedIndicator = value;
    }

    /**
     * Gets the value of the maritalStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * Sets the value of the maritalStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaritalStatus(String value) {
        this.maritalStatus = value;
    }

    /**
     * Gets the value of the smokerType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSmokerType() {
        return smokerType;
    }

    /**
     * Sets the value of the smokerType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSmokerType(String value) {
        this.smokerType = value;
    }

    /**
     * Gets the value of the marketingAttitudeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarketingAttitudeType() {
        return marketingAttitudeType;
    }

    /**
     * Sets the value of the marketingAttitudeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarketingAttitudeType(String value) {
        this.marketingAttitudeType = value;
    }

    /**
     * Gets the value of the servicingAttitudeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicingAttitudeType() {
        return servicingAttitudeType;
    }

    /**
     * Sets the value of the servicingAttitudeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicingAttitudeType(String value) {
        this.servicingAttitudeType = value;
    }

    /**
     * Gets the value of the personDetailsVerifiedIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPersonDetailsVerifiedIndicator() {
        return personDetailsVerifiedIndicator;
    }

    /**
     * Sets the value of the personDetailsVerifiedIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPersonDetailsVerifiedIndicator(Boolean value) {
        this.personDetailsVerifiedIndicator = value;
    }

    /**
     * Gets the value of the addressDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGAddressDetails }
     *     
     */
    public DGAddressDetails getAddressDetails() {
        return addressDetails;
    }

    /**
     * Sets the value of the addressDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGAddressDetails }
     *     
     */
    public void setAddressDetails(DGAddressDetails value) {
        this.addressDetails = value;
    }

    /**
     * Gets the value of the deathDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGDeathDetails }
     *     
     */
    public DGDeathDetails getDeathDetails() {
        return deathDetails;
    }

    /**
     * Sets the value of the deathDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGDeathDetails }
     *     
     */
    public void setDeathDetails(DGDeathDetails value) {
        this.deathDetails = value;
    }

    /**
     * Gets the value of the bankruptcyDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGBankruptcyDetails }
     *     
     */
    public DGBankruptcyDetails getBankruptcyDetails() {
        return bankruptcyDetails;
    }

    /**
     * Sets the value of the bankruptcyDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGBankruptcyDetails }
     *     
     */
    public void setBankruptcyDetails(DGBankruptcyDetails value) {
        this.bankruptcyDetails = value;
    }

}
