package com.lgim.group.gatekeeper.route;

import com.lgim.group.gatekeeper.processor.ValidateJwtTokenProcessor;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class GatekeeperCommonRoute extends RouteBuilder {

  @Value("${rest_address:localhost}")
  private String gatekeeperUriLocal;

  @Value("${rest_port:9111}")
  private String port;

  @Autowired
  private ValidateJwtTokenProcessor validateJwtTokenProcessor;

  public static final String VALIDATE_JWT_TOKEN = "direct:gatekeeperJwtValidation";
  public static final String KEY_AUTHORIZATION = "Authorization";

  @Override
  public void configure() {

    from(VALIDATE_JWT_TOKEN)
        .setProperty(KEY_AUTHORIZATION, header(KEY_AUTHORIZATION))
        .routeId("validate-token-route")
        .process(validateJwtTokenProcessor);

  }
}
