
package lbf_acct_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_AcctGroup complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_AcctGroup"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="groupArrangementID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="groupArrangementName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="groupType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_AcctGroup", propOrder = {
    "groupArrangementID",
    "groupArrangementName",
    "groupType"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGAcctGroup
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String groupArrangementID;
    protected String groupArrangementName;
    protected String groupType;

    /**
     * Gets the value of the groupArrangementID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupArrangementID() {
        return groupArrangementID;
    }

    /**
     * Sets the value of the groupArrangementID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupArrangementID(String value) {
        this.groupArrangementID = value;
    }

    /**
     * Gets the value of the groupArrangementName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupArrangementName() {
        return groupArrangementName;
    }

    /**
     * Sets the value of the groupArrangementName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupArrangementName(String value) {
        this.groupArrangementName = value;
    }

    /**
     * Gets the value of the groupType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupType() {
        return groupType;
    }

    /**
     * Sets the value of the groupType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupType(String value) {
        this.groupType = value;
    }

}
