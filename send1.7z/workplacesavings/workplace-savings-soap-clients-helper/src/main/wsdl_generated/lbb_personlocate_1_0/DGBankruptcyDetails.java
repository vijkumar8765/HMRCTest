
package lbb_personlocate_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_BankruptcyDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_BankruptcyDetails"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="bankruptcyStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="bankruptcyEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_BankruptcyDetails", propOrder = {
    "bankruptcyStartDate",
    "bankruptcyEndDate"
})
@ToString
@EqualsAndHashCode
public class DGBankruptcyDetails implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar bankruptcyStartDate;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar bankruptcyEndDate;

    /**
     * Gets the value of the bankruptcyStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBankruptcyStartDate() {
        return bankruptcyStartDate;
    }

    /**
     * Sets the value of the bankruptcyStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBankruptcyStartDate(XMLGregorianCalendar value) {
        this.bankruptcyStartDate = value;
    }

    /**
     * Gets the value of the bankruptcyEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBankruptcyEndDate() {
        return bankruptcyEndDate;
    }

    /**
     * Sets the value of the bankruptcyEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBankruptcyEndDate(XMLGregorianCalendar value) {
        this.bankruptcyEndDate = value;
    }

}
