package com.lgim.group.service.graphql.util;

import graphql.schema.DataFetchingEnvironment;
import graphql.servlet.GraphQLContext;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpServerErrorException;

import javax.servlet.http.HttpServletRequest;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class JwtTokenExtractorImplTest {


  @InjectMocks
  JwtTokenExtractor jwtTokenExtractor = new JwtTokenExtractorImpl();

  @Mock
  DataFetchingEnvironment environment;

  @Mock
  GraphQLContext graphQLContext;

  @Mock
  HttpServletRequest request;

  String jwtToken = "Bearer eyJhbGciOiJIUzUxMiJ9.eyJwb2xpY3lOdW1iZXIiOiIyNjkxMTUwMDMxIiwicGFydHlJZCI6IkJCREI5NFhZMCJ9.jIDQtkVcYxpO39J5KUM8ht-SgNbcCeRGht2xj9DlHqF5Q5Ydwj0k0BSA-CRPS7XsFHefnd86kBOoA11Vg6dFfA";

  @Rule
  public ExpectedException expectedException = ExpectedException.none();

  @Before
  public void setUp() throws Exception {

  }

  @Test
  public void testJwtTokenIsExtractedWhenPresent() {
    when(environment.getContext()).thenReturn(graphQLContext);
    when(graphQLContext.getRequest()).thenReturn(Optional.of(request));
    when(request.getHeader(RestUtil.JWT_TOKEN_REST_HEADER_NAME)).thenReturn(jwtToken);

    assertEquals(jwtToken, jwtTokenExtractor.extractJwtToken(environment));
  }

  @Test
  public void testExceptionThrownWhenRequestNotPresent() {
    when(environment.getContext()).thenReturn(graphQLContext);
    when(graphQLContext.getRequest()).thenReturn(Optional.empty());

    expectedException.expect(HttpServerErrorException.class);

    expectedException.expectMessage(HttpStatus.UNAUTHORIZED + " UNAUTHORIZED: Jwt Token is not provided or is empty!");

    assertNull(jwtTokenExtractor.extractJwtToken(environment));
  }

  @Test
  public void testExceptionThrownWhenJwtTokenIsNull() {
    when(environment.getContext()).thenReturn(graphQLContext);
    when(graphQLContext.getRequest()).thenReturn(Optional.of(request));
    when(request.getHeader(RestUtil.JWT_TOKEN_REST_HEADER_NAME)).thenReturn(null);

    expectedException.expect(HttpServerErrorException.class);

    expectedException.expectMessage(HttpStatus.UNAUTHORIZED + " UNAUTHORIZED: Jwt Token is not provided or is empty!");

    assertNull(jwtTokenExtractor.extractJwtToken(environment));
  }

  @Test
  public void testExceptionThrownWhenJwtTokenIsEmpty() {
    when(environment.getContext()).thenReturn(graphQLContext);
    when(graphQLContext.getRequest()).thenReturn(Optional.of(request));
    when(request.getHeader(RestUtil.JWT_TOKEN_REST_HEADER_NAME)).thenReturn("");

    expectedException.expect(HttpServerErrorException.class);

    expectedException.expectMessage(HttpStatus.UNAUTHORIZED + " UNAUTHORIZED: Jwt Token is not provided or is empty!");

    assertNull(jwtTokenExtractor.extractJwtToken(environment));
  }

  @Test
  public void testExceptionThrownWhenJwtTokenIsOfIncorrectFormat() {
    when(environment.getContext()).thenReturn(graphQLContext);
    when(graphQLContext.getRequest()).thenReturn(Optional.of(request));
    when(request.getHeader(RestUtil.JWT_TOKEN_REST_HEADER_NAME)).thenReturn("BearerSomeToken");

    expectedException.expect(HttpServerErrorException.class);

    expectedException.expectMessage(HttpStatus.UNAUTHORIZED + " UNAUTHORIZED: Jwt Token is not provided or is empty!");

    assertNull(jwtTokenExtractor.extractJwtToken(environment));
  }


}

