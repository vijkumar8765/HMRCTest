
package lbb_personlocate_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_DeathDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_DeathDetails"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dateDeathVerifiedIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="dateDeathNotified" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="dateDeathVerified" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="dateOfDeath" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_DeathDetails", propOrder = {
    "dateDeathVerifiedIndicator",
    "dateDeathNotified",
    "dateDeathVerified",
    "dateOfDeath"
})
@ToString
@EqualsAndHashCode
public class DGDeathDetails implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected Boolean dateDeathVerifiedIndicator;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateDeathNotified;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateDeathVerified;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateOfDeath;

    /**
     * Gets the value of the dateDeathVerifiedIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDateDeathVerifiedIndicator() {
        return dateDeathVerifiedIndicator;
    }

    /**
     * Sets the value of the dateDeathVerifiedIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDateDeathVerifiedIndicator(Boolean value) {
        this.dateDeathVerifiedIndicator = value;
    }

    /**
     * Gets the value of the dateDeathNotified property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDeathNotified() {
        return dateDeathNotified;
    }

    /**
     * Sets the value of the dateDeathNotified property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDeathNotified(XMLGregorianCalendar value) {
        this.dateDeathNotified = value;
    }

    /**
     * Gets the value of the dateDeathVerified property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDeathVerified() {
        return dateDeathVerified;
    }

    /**
     * Sets the value of the dateDeathVerified property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDeathVerified(XMLGregorianCalendar value) {
        this.dateDeathVerified = value;
    }

    /**
     * Gets the value of the dateOfDeath property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOfDeath() {
        return dateOfDeath;
    }

    /**
     * Sets the value of the dateOfDeath property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfDeath(XMLGregorianCalendar value) {
        this.dateOfDeath = value;
    }

}
