package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@Builder
public class WorkplacePensionHoldingsDto implements java.io.Serializable {
  private List<BenefitDto> benefits;
  private List<InvestmentStrategyDto> future;
  private BigDecimal lastRegularContribution;
  private LastRegularContributionFrequencyCode lastRegularContributionFrequencyCode;
  private Boolean facilitatedAdviserChargeAvailable;
  private Boolean permittedByRole;

  public WorkplacePensionHoldingsDto(List<BenefitDto> benefits, List<InvestmentStrategyDto> future, BigDecimal lastRegularContribution, LastRegularContributionFrequencyCode lastRegularContributionFrequencyCode, Boolean facilitatedAdviserChargeAvailable, Boolean permittedByRole) {
    this.benefits = benefits;
    this.future = future;
    this.lastRegularContribution = lastRegularContribution;
    this.lastRegularContributionFrequencyCode = lastRegularContributionFrequencyCode;
    this.facilitatedAdviserChargeAvailable = facilitatedAdviserChargeAvailable;
    this.permittedByRole = permittedByRole;
  }
}
