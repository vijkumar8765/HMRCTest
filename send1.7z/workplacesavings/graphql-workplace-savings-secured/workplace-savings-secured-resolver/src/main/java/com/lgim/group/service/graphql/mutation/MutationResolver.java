package com.lgim.group.service.graphql.mutation;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.lgim.group.service.graphql.dto.BasketType;
import com.lgim.group.service.graphql.dto.FundsInBasketInputDto;
import com.lgim.group.service.graphql.dto.Outcome;
import com.lgim.group.service.graphql.dto.WorkplacePensionInputDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionSwitchAndRedirectOrderResponseDto;
import com.lgim.group.service.graphql.service.WorkplaceSavingsService;
import com.lgim.group.service.graphql.util.JourneyIdExtractor;
import com.lgim.group.service.graphql.util.JwtTokenExtractor;
import graphql.GraphQLException;
import graphql.schema.DataFetchingEnvironment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class MutationResolver implements GraphQLMutationResolver {

  private static final String WORKPLACE_PENSION_ORDER_ERROR_MESSAGE = "Error while processing workplace pension order for policy %s";

  @Autowired
  private WorkplaceSavingsService workplaceSavingsService;

  @Autowired
  private JwtTokenExtractor jwtTokenExtractor;

  @Autowired
  private JourneyIdExtractor journeyIdExtractor;

  public WorkplacePensionSwitchAndRedirectOrderResponseDto workplacePensionSwitchAndRedirectOrder(
      String policyNumber, WorkplacePensionInputDto workplacePensionInputDto, DataFetchingEnvironment environment) {
    try {
      log.info("In SwitchAndRedirectOrder Mutation Resolver: ");
      log.info("policyNumber: " + policyNumber);
      log.info("workplacePensionInputDto: " + workplacePensionInputDto);
      String jwtToken = jwtTokenExtractor.extractJwtToken(environment);
      String journeyId = journeyIdExtractor.extractJourneyId(environment);
      return workplaceSavingsService.processWorkplacePensionSwitchAndRedirectOrder(policyNumber, workplacePensionInputDto, jwtToken, journeyId);
    } catch (Exception ex) {
      log.error(String.format(WORKPLACE_PENSION_ORDER_ERROR_MESSAGE, policyNumber), ex);
      throw new GraphQLException(String.format(WORKPLACE_PENSION_ORDER_ERROR_MESSAGE, policyNumber));
    }
  }

  public Outcome workplacePensionSaveBasket(String policyNumber, BasketType basketType, FundsInBasketInputDto fundsInBasket) {
    log.info("In SaveBasket Mutation Resolver: ");
    log.info("policyNumber: " + policyNumber);
    return Outcome.SUCCESS;
  }
}
