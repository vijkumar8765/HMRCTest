package com.lgim.group.service.graphql.query;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.lgim.group.service.graphql.dto.CustomerProfileDto;
import com.lgim.group.service.graphql.dto.ManageYourAccountDetailsDto;
import com.lgim.group.service.graphql.service.ManageYourAccountService;
import com.lgim.group.service.graphql.util.JwtTokenExtractor;
import graphql.GraphQLException;
import graphql.schema.DataFetchingEnvironment;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;

@Component
@Slf4j
public class ManageYourAccountDetailsQueryResolver implements GraphQLQueryResolver {

  private static final String MYA_GRAPHQL_SCHEMA_VERSION_FILE_PATH = "/manage-your-account-graphql-schema-version.txt";
  private static final String MANAGE_YOUR_ACCOUNT_DEtAILS_ERROR_MESSAGE = "Error while fetching manage your account details for customerID %s";
  private String myaSchemaVersion;

  @Autowired
  private ManageYourAccountService manageYourAccountService;

  @Autowired
  private JwtTokenExtractor jwtTokenExtractor;

  public ManageYourAccountDetailsQueryResolver() {
    setMyaSchemaVersion();
  }

  ManageYourAccountDetailsDto manageYourAccountDetails(String customerID, DataFetchingEnvironment environment) {
    try {
      final String jwtToken = jwtTokenExtractor.extractJwtToken(environment);
      final CustomerProfileDto customerProfileDto = manageYourAccountService.getCustomerProfile(customerID, jwtToken);
      return ManageYourAccountDetailsDto.builder().customerProfile(customerProfileDto).build();
    } catch (Exception ex) {
      log.error(String.format(MANAGE_YOUR_ACCOUNT_DEtAILS_ERROR_MESSAGE, customerID), ex);
      throw new GraphQLException(String.format(MANAGE_YOUR_ACCOUNT_DEtAILS_ERROR_MESSAGE, customerID));
    }
  }

  String myaVersion() {
    log.info(String.format("Returning MYA schema version [%s]", myaSchemaVersion));
    return myaSchemaVersion;
  }

  void setMyaSchemaVersion() {
    final InputStream is = getVersionFileInputStream();
    try {
      myaSchemaVersion = IOUtils.toString(is);
    } catch (IOException ioException) {
      log.error(
          String.format("Unable to determine graphql schema version as unable to locate file [%s}, error was [%s]",
              MYA_GRAPHQL_SCHEMA_VERSION_FILE_PATH,
              ioException.getMessage()
          )
      );
      throw new RuntimeException("Unable to determine GraphQL schema version");
    }
  }

  InputStream getVersionFileInputStream() {
    return ManageYourAccountDetailsQueryResolver.class.getResourceAsStream(MYA_GRAPHQL_SCHEMA_VERSION_FILE_PATH);
  }
}
