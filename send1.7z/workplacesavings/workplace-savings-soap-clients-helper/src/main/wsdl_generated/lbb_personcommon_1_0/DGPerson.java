
package lbb_personcommon_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_Person complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_Person"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="personalDetails" type="{http://LBB_PersonCommon_1_0}DG_PersonalDetails" minOccurs="0"/&gt;
 *         &lt;element name="incomeDetails" type="{http://LBB_PersonCommon_1_0}DG_IncomeDetails" minOccurs="0"/&gt;
 *         &lt;element name="contactDetails" type="{http://LBB_PersonCommon_1_0}DG_ContactDetails" minOccurs="0"/&gt;
 *         &lt;element name="partyRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="evidenceDetails" type="{http://LBB_PersonCommon_1_0}DG_EvidenceDetails" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="nationRelationship" type="{http://LBB_PersonCommon_1_0}DG_NationRelationship" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_Person", propOrder = {
    "personalDetails",
    "incomeDetails",
    "contactDetails",
    "partyRef",
    "evidenceDetails",
    "nationRelationship"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGPerson
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGPersonalDetails personalDetails;
    protected DGIncomeDetails incomeDetails;
    protected DGContactDetails contactDetails;
    protected String partyRef;
    protected List<DGEvidenceDetails> evidenceDetails;
    protected List<DGNationRelationship> nationRelationship;

    /**
     * Gets the value of the personalDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGPersonalDetails }
     *     
     */
    public DGPersonalDetails getPersonalDetails() {
        return personalDetails;
    }

    /**
     * Sets the value of the personalDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGPersonalDetails }
     *     
     */
    public void setPersonalDetails(DGPersonalDetails value) {
        this.personalDetails = value;
    }

    /**
     * Gets the value of the incomeDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGIncomeDetails }
     *     
     */
    public DGIncomeDetails getIncomeDetails() {
        return incomeDetails;
    }

    /**
     * Sets the value of the incomeDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGIncomeDetails }
     *     
     */
    public void setIncomeDetails(DGIncomeDetails value) {
        this.incomeDetails = value;
    }

    /**
     * Gets the value of the contactDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGContactDetails }
     *     
     */
    public DGContactDetails getContactDetails() {
        return contactDetails;
    }

    /**
     * Sets the value of the contactDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGContactDetails }
     *     
     */
    public void setContactDetails(DGContactDetails value) {
        this.contactDetails = value;
    }

    /**
     * Gets the value of the partyRef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyRef() {
        return partyRef;
    }

    /**
     * Sets the value of the partyRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyRef(String value) {
        this.partyRef = value;
    }

    /**
     * Gets the value of the evidenceDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the evidenceDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEvidenceDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGEvidenceDetails }
     * 
     * 
     */
    public List<DGEvidenceDetails> getEvidenceDetails() {
        if (evidenceDetails == null) {
            evidenceDetails = new ArrayList<DGEvidenceDetails>();
        }
        return this.evidenceDetails;
    }

    /**
     * Gets the value of the nationRelationship property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the nationRelationship property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNationRelationship().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGNationRelationship }
     * 
     * 
     */
    public List<DGNationRelationship> getNationRelationship() {
        if (nationRelationship == null) {
            nationRelationship = new ArrayList<DGNationRelationship>();
        }
        return this.nationRelationship;
    }

}
