@javax.xml.bind.annotation.XmlSchema(namespace = "http://LBB_OrganisationCommon_1_0")
package lbb_organisationcommon_1_0;
