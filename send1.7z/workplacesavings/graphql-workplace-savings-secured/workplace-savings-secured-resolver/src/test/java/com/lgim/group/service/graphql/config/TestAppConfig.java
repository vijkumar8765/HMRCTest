package com.lgim.group.service.graphql.config;

import com.lgim.group.service.graphql.mutation.MutationResolver;
import com.lgim.group.service.graphql.query.QueryResolver;
import com.lgim.group.service.graphql.service.WorkplaceSavingsService;
import com.lgim.group.service.graphql.service.impl.WorkplaceSavingsServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TestAppConfig {

  @Bean
  public QueryResolver queryResolver() {
    return new QueryResolver();
  }

  @Bean
  public MutationResolver mutationResolver() {
    return new MutationResolver();
  }

  @Bean
  public WorkplaceSavingsService workplaceSavingsService() {
    return new WorkplaceSavingsServiceImpl();
  }
}
