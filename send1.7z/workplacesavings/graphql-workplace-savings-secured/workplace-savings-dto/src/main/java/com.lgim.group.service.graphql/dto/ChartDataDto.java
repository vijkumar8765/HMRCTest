package com.lgim.group.service.graphql.dto;

import java.util.Date;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class ChartDataDto implements java.io.Serializable {
  private Date date;
  private Float price;

  public ChartDataDto(Date date, Float price) {
    this.date = date;
    this.price = price;
  }
}
