
package lbb_acct_b_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_FullAccountDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_FullAccountDetails"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="alterationControl" type="{http://LBB_Acct_B_1_0}DA_AccountAltControl" minOccurs="0"/&gt;
 *         &lt;element name="policyDetail" type="{http://LBB_Acct_B_1_0}DA_AccountPolicyDetail" minOccurs="0"/&gt;
 *         &lt;element name="funds" type="{http://LBB_Acct_B_1_0}DA_AccountFund" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="receiptDetails" type="{http://LBB_Acct_B_1_0}DA_AccountReceipt" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_FullAccountDetails", propOrder = {
    "alterationControl",
    "policyDetail",
    "funds",
    "receiptDetails"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAFullAccountDetails
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DAAccountAltControl alterationControl;
    protected DAAccountPolicyDetail policyDetail;
    protected List<DAAccountFund> funds;
    protected List<DAAccountReceipt> receiptDetails;

    /**
     * Gets the value of the alterationControl property.
     * 
     * @return
     *     possible object is
     *     {@link DAAccountAltControl }
     *     
     */
    public DAAccountAltControl getAlterationControl() {
        return alterationControl;
    }

    /**
     * Sets the value of the alterationControl property.
     * 
     * @param value
     *     allowed object is
     *     {@link DAAccountAltControl }
     *     
     */
    public void setAlterationControl(DAAccountAltControl value) {
        this.alterationControl = value;
    }

    /**
     * Gets the value of the policyDetail property.
     * 
     * @return
     *     possible object is
     *     {@link DAAccountPolicyDetail }
     *     
     */
    public DAAccountPolicyDetail getPolicyDetail() {
        return policyDetail;
    }

    /**
     * Sets the value of the policyDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link DAAccountPolicyDetail }
     *     
     */
    public void setPolicyDetail(DAAccountPolicyDetail value) {
        this.policyDetail = value;
    }

    /**
     * Gets the value of the funds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the funds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFunds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DAAccountFund }
     * 
     * 
     */
    public List<DAAccountFund> getFunds() {
        if (funds == null) {
            funds = new ArrayList<DAAccountFund>();
        }
        return this.funds;
    }

    /**
     * Gets the value of the receiptDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the receiptDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReceiptDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DAAccountReceipt }
     * 
     * 
     */
    public List<DAAccountReceipt> getReceiptDetails() {
        if (receiptDetails == null) {
            receiptDetails = new ArrayList<DAAccountReceipt>();
        }
        return this.receiptDetails;
    }

}
