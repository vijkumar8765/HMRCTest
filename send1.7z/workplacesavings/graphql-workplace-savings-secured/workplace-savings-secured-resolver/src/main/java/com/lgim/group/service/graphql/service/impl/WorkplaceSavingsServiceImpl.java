package com.lgim.group.service.graphql.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lgim.group.service.graphql.dto.InvestmentDetailDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionCustomerDetailsDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionFundDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionFunds;
import com.lgim.group.service.graphql.dto.WorkplacePensionHoldingsDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionInputDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionSwitchAndRedirectOrderResponseDto;
import com.lgim.group.service.graphql.service.WorkplaceSavingsService;
import com.lgim.group.service.graphql.util.RestUtil;
import graphql.GraphQLException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.UUID;

import static com.lgim.group.service.graphql.util.RestUtil.AMPERSAND;
import static com.lgim.group.service.graphql.util.RestUtil.QUESTION_MARK;

@Service
@Slf4j
public class WorkplaceSavingsServiceImpl implements WorkplaceSavingsService {

  private static final String ALLOWABLE_SERVICE = "/lgim/allowableFunds/retrieveAllowableFunds";

  private static String JSON_CONVERSION_ERROR_MESSAGE = "Exception occurred while converting workplacePensionInputDto to JSON";

  @Value("${investment.details.service.url}")
  private String investmentDetailsServiceUrl;

  @Value("${customer.details.service.url}")
  private String customerDetailsServiceUrl;

  @Value("${investment.availability.service.url}")
  private String investmentAvailabilityServiceUrl;

  @Value("${valuation.reason.code}")
  private String valuationReasonCode;

  @Value("${entitlements.business.function}")
  private String entitlementsBusinessFunction;

  @Value("${allowable.funds.service.url}")
  private String allowableFundsServiceUrl;

  @Value("${fund.service.url}")
  private String fundServiceUrl;

  @Value("${iminstruction.service.url}")
  private String iminstructionServiceUrl;

  @Value("${account.service.url}")
  private String accountServiceUrl;

  @Value("${policy.unhash.active}")
  private String policyUnhashActive;


  @Override
  public WorkplacePensionHoldingsDto getWorkplacePensionHoldings(String policyNumber, String jwtToken, String journeyId) {
    log.info("Received a request to get holdings for policy number {}", policyNumber);

    HttpEntity<String> entity = getHttpEntityWithHeadersSet(jwtToken, policyNumber, null, journeyId);
    String queryParams = QUESTION_MARK + "valuationreasoncode=" + valuationReasonCode + AMPERSAND + "entitlementsbusinessfunction=" + entitlementsBusinessFunction;
    log.info("queryParams: " + queryParams);

    ResponseEntity<InvestmentDetailDto> responseEntity = RestUtil.REST_TEMPLATE.exchange(investmentDetailsServiceUrl
        + "/holdings/policy/" + policyNumber + queryParams, HttpMethod.GET, entity, InvestmentDetailDto.class);

    InvestmentDetailDto investmentDetailDto = responseEntity.getBody();

    if (!investmentDetailDto.getPermittedByRole().booleanValue()) {
      throw (new RuntimeException("No Entitlements"));
    }
    log.info("Completed request to get holdings for policy number {} with payload {}", policyNumber, investmentDetailDto);
    return investmentDetailDto.getWorkplacePensionHoldingsDto();
  }


  private HttpEntity<String> getHttpEntityWithHeadersSet(String jwtToken, String policyNumber, String jsonString, String journeyId) {
    HttpHeaders headers = new HttpHeaders();
    headers.set(RestUtil.JWT_TOKEN_REST_HEADER_NAME, jwtToken);
    log.info("Setting REST header {} for policy number {} to value {} for policy number {}", RestUtil.JWT_TOKEN_REST_HEADER_NAME, policyNumber, jwtToken);
    headers.set(RestUtil.JOURNEY_ID_REST_HEADER_NAME, journeyId);

    log.info("Setting REST header {} for policy number {} to value {}", RestUtil.JOURNEY_ID_REST_HEADER_NAME, policyNumber, journeyId);
    headers.set("Content-Type", "application/json");

    if (StringUtils.isNotEmpty(jsonString)) {
      return new HttpEntity<>(jsonString, headers);
    }
    return new HttpEntity<>("parameters", headers);
  }

  @Override
  public WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto isSwitchAndRedirectAllowed(String policyNumber, String jwtToken, String journeyId) {
    log.info("Received a request to perform switch and redirect check for policy number {}", policyNumber);

    HttpEntity<String> entity = getHttpEntityWithHeadersSet(jwtToken, policyNumber, null, journeyId);
    ResponseEntity<WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto> responseEntity = RestUtil.REST_TEMPLATE.exchange(investmentAvailabilityServiceUrl
        + "/wip/policy/" + policyNumber + "?businessFunction=" + entitlementsBusinessFunction, HttpMethod.GET, entity, WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto.class);

    WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto switchRedirectCheckAllowedResponseDto = responseEntity.getBody();

    log.info("Completed request to perform switch and redirect check for policy number {}", policyNumber);
    return switchRedirectCheckAllowedResponseDto;
  }

  @Override
  public WorkplacePensionCustomerDetailsDto getWorkplacePensionCustomerDetails(String policyNumber, String jwtToken, String journeyId) {
    log.info("Received a request to get Customer Details for policy number {}", policyNumber);

    HttpEntity<String> entity = getHttpEntityWithHeadersSet(jwtToken, policyNumber, null, journeyId);
    ResponseEntity<WorkplacePensionCustomerDetailsDto> responseEntity = RestUtil.REST_TEMPLATE.exchange(customerDetailsServiceUrl
        + "/customer/policy/" + policyNumber, HttpMethod.GET, entity, WorkplacePensionCustomerDetailsDto.class);

    WorkplacePensionCustomerDetailsDto workplacePensionCustomerDetailsDto = responseEntity.getBody();

    log.info("Completed request to get Customer Details for policy number {}", policyNumber);
    return workplacePensionCustomerDetailsDto;
  }

  @Override
  public WorkplacePensionFunds retrieveAllowableFunds(String policyNumber, String schemeCategory, String schemeMembership, String productId, String jwtToken, String journeyId) {
    log.info("Received a request to retrieveAllowableFunds for policy number {}", policyNumber);
    HttpEntity<String> entity = getHttpEntityWithHeadersSet(jwtToken, policyNumber, null, journeyId);
    String url = UriComponentsBuilder.fromHttpUrl(allowableFundsServiceUrl + ALLOWABLE_SERVICE)
        .queryParam("policyNumber", policyNumber)
        .queryParam("schemeCategory", schemeCategory)
        .queryParam("schemeId", schemeMembership)
        .queryParam("productId", productId)
        .build().toUriString();
    log.info("connecting to :: " + url);
    ResponseEntity<WorkplacePensionFunds> responseEntity = RestUtil.REST_TEMPLATE.exchange(url, HttpMethod.GET, entity, WorkplacePensionFunds.class);
    return responseEntity.getBody();
  }

  @Override
  public List<WorkplacePensionFundDto> getWorkplacePensionFundDetails(List<String> fundCodes, String jwtToken, String journeyId) {
    log.info("Received a request to get fund detail for funds {}", fundCodes);
    HttpEntity<String> entity = getHttpEntityWithHeadersSet(jwtToken, null, null, journeyId);
    String serviceUri = fundServiceUrl + "/" + StringUtils.join(fundCodes, ',');
    log.info("connecting to :: " + serviceUri);
    ResponseEntity<WorkplacePensionFunds> responseEntity = RestUtil.REST_TEMPLATE.exchange(serviceUri, HttpMethod.GET, entity, WorkplacePensionFunds.class);
    WorkplacePensionFunds workplacePensionFunds = responseEntity.getBody();
    log.info("Completed request to get fund detail for funds {}", fundCodes);
    return workplacePensionFunds.getWorkplacePensionFundDtoList();
  }

  @Override
  public WorkplacePensionSwitchAndRedirectOrderResponseDto processWorkplacePensionSwitchAndRedirectOrder(
      String policyNumber, WorkplacePensionInputDto workplacePensionInputDto, String jwtToken, String journeyId) {
    log.info("Received a request to process workplace pension order {}", policyNumber);

    String bodyJson;
    try {
      bodyJson = new ObjectMapper().writeValueAsString(workplacePensionInputDto);
    } catch (JsonProcessingException ex) {
      log.error(String.format(JSON_CONVERSION_ERROR_MESSAGE, policyNumber), ex);
      throw new GraphQLException(String.format(JSON_CONVERSION_ERROR_MESSAGE, policyNumber));
    }

    HttpEntity<String> entity = getHttpEntityWithHeadersSet(jwtToken, policyNumber, bodyJson, journeyId);
    String serviceUri = iminstructionServiceUrl + "/accept/" + policyNumber;

    String queryParams = QUESTION_MARK + "valuationreasoncode=" + valuationReasonCode + AMPERSAND + "businessfunction=" + entitlementsBusinessFunction;
    log.info("queryParams: " + queryParams);

    log.info("connecting to :: " + serviceUri);
    ResponseEntity<WorkplacePensionSwitchAndRedirectOrderResponseDto> responseEntity = RestUtil.REST_TEMPLATE.exchange(
        serviceUri + queryParams, HttpMethod.POST, entity, WorkplacePensionSwitchAndRedirectOrderResponseDto.class);

    WorkplacePensionSwitchAndRedirectOrderResponseDto workplacePensionSwitchAndRedirectOrderResponseDto = responseEntity.getBody();
    log.info("Completed request to process workplace pension order {}", policyNumber);
    return workplacePensionSwitchAndRedirectOrderResponseDto;
  }

  public String unhashPolicyNumber(String hashedPolicyNumber, String jwtToken, String journeyId) throws Exception {
    log.info("Received a request to unhash policy number {}", hashedPolicyNumber);

    if (!Boolean.valueOf(policyUnhashActive)) {
      log.info("Unhash policy number resolution not active");
      return hashedPolicyNumber;
    }
    HttpEntity<String> entity = getHttpEntityWithHeadersSet(jwtToken, hashedPolicyNumber, null, journeyId);
    String serviceUri = accountServiceUrl + "/accountsByPartyId/" + hashedPolicyNumber;
    ResponseEntity<String> responseEntity = RestUtil.REST_TEMPLATE.exchange(
        serviceUri, HttpMethod.GET, entity, String.class);

    String data = responseEntity.getBody();
    String unhashedPolicyNumber;

    try {
      unhashedPolicyNumber = new ObjectMapper().readTree(data).get("accountID").asText();
    } catch (JsonMappingException | NullPointerException jmex) {
      throw new GraphQLException("Unable to resolve policy number");
    }

    log.info("Completed processing unhashPolicyNumber request()");
    return unhashedPolicyNumber;
  }

  private String generateUuid() {
    return UUID.randomUUID().toString();
  }

}