package com.lgim.group.service.graphql.util;

import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component(value = "jwtTokenExtractor")
@Profile("graphiql")
public class GraphiqlJwtTokenExtractorImpl implements JwtTokenExtractor {

  @Value("${graphiql.jwt.token}")
  private String graphiqlJwtToken;

  @Override
  public String extractJwtToken(DataFetchingEnvironment environment) {
    return graphiqlJwtToken;
  }


}
