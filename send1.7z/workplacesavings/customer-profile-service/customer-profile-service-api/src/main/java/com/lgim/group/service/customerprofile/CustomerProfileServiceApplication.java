package com.lgim.group.service.customerprofile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {
    "com.lgim.group.service.customerprofile.*",
    "com.lgim.group.gatekeeper.*"
    })
public class CustomerProfileServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(CustomerProfileServiceApplication.class, args);
  }
}

