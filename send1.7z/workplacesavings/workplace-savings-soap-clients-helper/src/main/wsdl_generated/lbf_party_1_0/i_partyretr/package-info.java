@javax.xml.bind.annotation.XmlSchema(namespace = "http://LBF_Party_1_0/I_PartyRetr")
package lbf_party_1_0.i_partyretr;
