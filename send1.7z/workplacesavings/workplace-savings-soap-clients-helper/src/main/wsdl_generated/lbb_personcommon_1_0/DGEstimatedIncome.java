
package lbb_personcommon_1_0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_EstimatedIncome complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_EstimatedIncome"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="taxYear" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="incomeEvidenceDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="estimatedIncomeAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="incomeEvidenceTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="incomeAddedDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="totalAnnualIncome" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="incomeElements" type="{http://LBB_PersonCommon_1_0}DG_IncomeElement" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_EstimatedIncome", propOrder = {
    "taxYear",
    "incomeEvidenceDate",
    "estimatedIncomeAmount",
    "incomeEvidenceTypeCode",
    "incomeAddedDate",
    "totalAnnualIncome",
    "incomeElements"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGEstimatedIncome
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String taxYear;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar incomeEvidenceDate;
    protected Double estimatedIncomeAmount;
    protected String incomeEvidenceTypeCode;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar incomeAddedDate;
    protected Double totalAnnualIncome;
    protected List<DGIncomeElement> incomeElements;

    /**
     * Gets the value of the taxYear property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxYear() {
        return taxYear;
    }

    /**
     * Sets the value of the taxYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxYear(String value) {
        this.taxYear = value;
    }

    /**
     * Gets the value of the incomeEvidenceDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIncomeEvidenceDate() {
        return incomeEvidenceDate;
    }

    /**
     * Sets the value of the incomeEvidenceDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIncomeEvidenceDate(XMLGregorianCalendar value) {
        this.incomeEvidenceDate = value;
    }

    /**
     * Gets the value of the estimatedIncomeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getEstimatedIncomeAmount() {
        return estimatedIncomeAmount;
    }

    /**
     * Sets the value of the estimatedIncomeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setEstimatedIncomeAmount(Double value) {
        this.estimatedIncomeAmount = value;
    }

    /**
     * Gets the value of the incomeEvidenceTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncomeEvidenceTypeCode() {
        return incomeEvidenceTypeCode;
    }

    /**
     * Sets the value of the incomeEvidenceTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncomeEvidenceTypeCode(String value) {
        this.incomeEvidenceTypeCode = value;
    }

    /**
     * Gets the value of the incomeAddedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIncomeAddedDate() {
        return incomeAddedDate;
    }

    /**
     * Sets the value of the incomeAddedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIncomeAddedDate(XMLGregorianCalendar value) {
        this.incomeAddedDate = value;
    }

    /**
     * Gets the value of the totalAnnualIncome property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getTotalAnnualIncome() {
        return totalAnnualIncome;
    }

    /**
     * Sets the value of the totalAnnualIncome property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setTotalAnnualIncome(Double value) {
        this.totalAnnualIncome = value;
    }

    /**
     * Gets the value of the incomeElements property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the incomeElements property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIncomeElements().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DGIncomeElement }
     * 
     * 
     */
    public List<DGIncomeElement> getIncomeElements() {
        if (incomeElements == null) {
            incomeElements = new ArrayList<DGIncomeElement>();
        }
        return this.incomeElements;
    }

}
