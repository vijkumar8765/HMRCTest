
package lbb_communication_1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGRequestEnvelope;
import lbb_generatecommunication_1.DGGenerateCommunicationRequest;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_BaseCommunicationRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_BaseCommunicationRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_RequestEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="data" type="{http://LBB_Communication_1}DG_CommunicationData" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_BaseCommunicationRequest", propOrder = {
    "data"
})
@XmlSeeAlso({
    DGGenerateCommunicationRequest.class
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGBaseCommunicationRequest
    extends DGRequestEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGCommunicationData data;

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link DGCommunicationData }
     *     
     */
    public DGCommunicationData getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGCommunicationData }
     *     
     */
    public void setData(DGCommunicationData value) {
        this.data = value;
    }

}
