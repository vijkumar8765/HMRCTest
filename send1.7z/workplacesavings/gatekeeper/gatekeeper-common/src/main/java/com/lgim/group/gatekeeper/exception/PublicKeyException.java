package com.lgim.group.gatekeeper.exception;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PublicKeyException extends Exception {

  public PublicKeyException(String message, Throwable cause) {
    super(message, cause);
    log.error(message,cause);
  }
}
