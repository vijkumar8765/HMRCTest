package com.lgim.group.service.graphql.functionaltest;

import com.lgim.group.service.graphql.GraphQLApplication;
import com.lgim.group.service.graphql.dto.versions.MicroServiceReportDto;
import com.lgim.group.service.graphql.functionaltest.bdd.Given;
import com.lgim.group.service.graphql.functionaltest.bdd.When;
import org.junit.AfterClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.test.context.TestPropertySource;

import java.io.IOException;
import java.util.List;

import static com.lgim.group.service.graphql.functionaltest.bdd.When.theVersionResponseFromGraphQl;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.BDDAssertions.then;

@TestPropertySource(locations = "classpath:test.properties")
public class GetMicroServiceVersionTest {

  private static final ConfigurableApplicationContext application = SpringApplication.run(GraphQLApplication.class);

  @AfterClass
  public static void tearDown() {
    application.close();
  }

  // add WireMockRule for different service call

  private final Given given = new Given();
  private final When when = new When();

  //This test must be fixed for each service call addition
  @Ignore
  @Test
  public void happyFlowGetVersions() throws IOException, InterruptedException {
    when.theGraphQLServerReceivesAGetVersionsRequest();
    List<MicroServiceReportDto> actualResponse = theVersionResponseFromGraphQl();
    then(actualResponse.size()).isEqualTo(1);

    assertThat(actualResponse.get(0).getArtifactId().toString()).isEqualTo("graphql-workplace-savings-secured-api");
    assertThat(actualResponse.get(0).getGroupId().toString()).isEqualTo("com.lgim.digital.graphql");
  }
}
