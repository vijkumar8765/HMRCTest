package com.lgim.group.service.graphql.functionaltest.bdd;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import org.springframework.http.HttpStatus;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;

import com.lgim.group.service.graphql.dto.versions.MicroServiceReportDto;

public class Given {

  private final ObjectMapper mapper = new ObjectMapper();

  //This to be created for mocking each service call
  public void stubForFundVersionOfMicroservice(WireMockRule rule) throws JsonProcessingException {
    MicroServiceReportDto testReport = new MicroServiceReportDto("com.lgim.group.service","test-api","1.1-SNAPSHOT");
    stubFor(get(urlMatching("getVersions"))
        .willReturn(aResponse()
            .withStatus(HttpStatus.OK.value())
            .withHeader("Content-Type", "application/json")
            .withBody(mapper.writeValueAsString(testReport))));
  }
}
