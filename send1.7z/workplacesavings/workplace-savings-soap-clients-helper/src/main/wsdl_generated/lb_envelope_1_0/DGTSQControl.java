
package lb_envelope_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_TSQControl complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_TSQControl"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="moreDataInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="tsqName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="tsqOffset" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_TSQControl", propOrder = {
    "moreDataInd",
    "tsqName",
    "tsqOffset"
})
@ToString
@EqualsAndHashCode
public class DGTSQControl implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String moreDataInd;
    protected String tsqName;
    protected Integer tsqOffset;

    /**
     * Gets the value of the moreDataInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMoreDataInd() {
        return moreDataInd;
    }

    /**
     * Sets the value of the moreDataInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMoreDataInd(String value) {
        this.moreDataInd = value;
    }

    /**
     * Gets the value of the tsqName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTsqName() {
        return tsqName;
    }

    /**
     * Sets the value of the tsqName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTsqName(String value) {
        this.tsqName = value;
    }

    /**
     * Gets the value of the tsqOffset property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTsqOffset() {
        return tsqOffset;
    }

    /**
     * Sets the value of the tsqOffset property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTsqOffset(Integer value) {
        this.tsqOffset = value;
    }

}
