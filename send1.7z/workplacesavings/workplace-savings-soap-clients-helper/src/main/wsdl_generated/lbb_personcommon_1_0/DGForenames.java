
package lbb_personcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_Forenames complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_Forenames"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="forename1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="forename2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="forename3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_Forenames", propOrder = {
    "forename1",
    "forename2",
    "forename3"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGForenames
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String forename1;
    protected String forename2;
    protected String forename3;

    /**
     * Gets the value of the forename1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForename1() {
        return forename1;
    }

    /**
     * Sets the value of the forename1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForename1(String value) {
        this.forename1 = value;
    }

    /**
     * Gets the value of the forename2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForename2() {
        return forename2;
    }

    /**
     * Sets the value of the forename2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForename2(String value) {
        this.forename2 = value;
    }

    /**
     * Gets the value of the forename3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForename3() {
        return forename3;
    }

    /**
     * Sets the value of the forename3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForename3(String value) {
        this.forename3 = value;
    }

}
