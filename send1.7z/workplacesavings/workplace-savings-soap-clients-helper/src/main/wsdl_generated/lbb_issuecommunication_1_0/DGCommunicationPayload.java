
package lbb_issuecommunication_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * Any sub class of this BO must have an attribute named "data" of appropriate type.
 * 
 * <p>Java class for DG_CommunicationPayload complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_CommunicationPayload"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_CommunicationPayload")
@XmlSeeAlso({
    DGPersonCommunicationPayload.class
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGCommunicationPayload
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;

}
