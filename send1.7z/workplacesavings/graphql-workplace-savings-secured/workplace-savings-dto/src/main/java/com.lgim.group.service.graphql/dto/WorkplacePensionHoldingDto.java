package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
public class WorkplacePensionHoldingDto implements java.io.Serializable {

  private String fundCode;
  private String name;
  private Boolean fundTypeLifestyle;
  private BigDecimal monetaryValue;
  private BigDecimal unitPrice;
  private Float unitsHeld;
  private Date unitPriceDate;
  private Boolean softClosed;


  public WorkplacePensionHoldingDto(String fundCode, String name, Boolean fundTypeLifestyle, BigDecimal monetaryValue, BigDecimal unitPrice, Float unitsHeld, Date unitPriceDate, Boolean softClosed) {
    this.fundCode = fundCode;
    this.name = name;
    this.fundTypeLifestyle = fundTypeLifestyle;
    this.monetaryValue = monetaryValue;
    this.unitPrice = unitPrice;
    this.unitsHeld = unitsHeld;
    this.unitPriceDate = unitPriceDate;
    this.softClosed = softClosed;
  }
}
