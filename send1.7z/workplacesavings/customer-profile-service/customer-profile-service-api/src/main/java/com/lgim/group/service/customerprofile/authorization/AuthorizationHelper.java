package com.lgim.group.service.customerprofile.authorization;

import com.lgim.group.gatekeeper.exception.JwtAuthenticationException;
import com.lgim.group.gatekeeper.helpers.PublicKeyHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;

@Slf4j
@Service
public class AuthorizationHelper {

  private static final String PARTY_ID_KEY = "partyId";

  private final PublicKeyHelper publicKeyHelper;

  // TODO - Setting public key could probably be done by Gatekeeper itself
  public AuthorizationHelper(final PublicKeyHelper publicKeyHelper) throws JwtAuthenticationException {
    this.publicKeyHelper = publicKeyHelper;
    setGatekeeperPublicKey();
  }

  public String authorizeRequest(final String authorizationHeader) throws JwtAuthenticationException {
    final Map<String, Object> jwtData = validateHeader(authorizationHeader);
    printJwtData(jwtData);
    return jwtData.get(PARTY_ID_KEY).toString();

  }

  private void setGatekeeperPublicKey() throws JwtAuthenticationException {
    final boolean publicKeyResult = publicKeyHelper.isPublicKeySet() || publicKeyHelper.fetchPublicKey();

    if (!publicKeyResult) {
      throw new JwtAuthenticationException("Gatekeeper.PublicKeyHelper.fetchPublicKey returned false");
    }
  }

  private Map<String, Object> validateHeader(final String authorizationHeader) throws JwtAuthenticationException {
    log.debug("Authorizing header: {}", authorizationHeader);
    return publicKeyHelper.validateToken(authorizationHeader);
  }

  private void printJwtData(final Map<String, Object> jwtData) {
    log.debug("Printing JWT Data:");
    for (String key: jwtData.keySet()) {
      final String value = jwtData.get(key).toString();
      log.debug("Key: '{}' Value: '{}'", key, value);
    }
  }
}
