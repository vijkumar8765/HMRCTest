
package lbb_acct_b_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_AccountLifestyleFund complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_AccountLifestyleFund"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="lifestyleFundId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="lifestyleFundName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_AccountLifestyleFund", propOrder = {
    "lifestyleFundId",
    "lifestyleFundName"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAAccountLifestyleFund
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String lifestyleFundId;
    protected String lifestyleFundName;

    /**
     * Gets the value of the lifestyleFundId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLifestyleFundId() {
        return lifestyleFundId;
    }

    /**
     * Sets the value of the lifestyleFundId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLifestyleFundId(String value) {
        this.lifestyleFundId = value;
    }

    /**
     * Gets the value of the lifestyleFundName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLifestyleFundName() {
        return lifestyleFundName;
    }

    /**
     * Sets the value of the lifestyleFundName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLifestyleFundName(String value) {
        this.lifestyleFundName = value;
    }

}
