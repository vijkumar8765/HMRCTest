package com.lgim.group.service.graphql.service.impl;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static graphql.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.google.common.collect.Lists;
import com.lgim.group.service.graphql.dto.BenefitDto;
import com.lgim.group.service.graphql.dto.BenefitInputDto;
import com.lgim.group.service.graphql.dto.BenefitType;
import com.lgim.group.service.graphql.dto.FundInputDto;
import com.lgim.group.service.graphql.dto.InvestmentDetailDto;
import com.lgim.group.service.graphql.dto.InvestmentStrategyDto;
import com.lgim.group.service.graphql.dto.LastRegularContributionFrequencyCode;
import com.lgim.group.service.graphql.dto.Outcome;
import com.lgim.group.service.graphql.dto.WorkInProgressCheckDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionCustomerDetailsDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionFundDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionFunds;
import com.lgim.group.service.graphql.dto.WorkplacePensionHoldingDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionHoldingsDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionInputDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto;
import com.lgim.group.service.graphql.dto.WorkplacePensionSwitchAndRedirectOrderResponseDto;
import com.lgim.group.service.graphql.service.WorkplaceSavingsService;
import com.lgim.group.service.graphql.util.RestUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

import graphql.GraphQLException;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.HttpServerErrorException;

@RunWith(SpringJUnit4ClassRunner.class)
@TestPropertySource(properties = {"investment.details.service.url=http://localhost:9090", "allowable.funds.service.url=http://localhost:9090",
    "investment.availability.service.url=http://localhost:9090", "valuation.reason.code=SO", "entitlements.business.function=SWTC",
    "customer.details.service.url=http://localhost:9090",
    "fund.service.url=http://localhost:9090/lgim/funds/retrieveFundsDetail",
    "iminstruction.service.url=http://localhost:9090", "account.service.url=http://localhost:9090","policy.unhash.active=true"})
@ContextConfiguration(classes = WorkplaceSavingsServiceImpl.class)
public class WorkplaceSavingsServiceImplTest {

  private static final Pattern UUID_PATTERN = Pattern.compile("[a-z0-9-]{36}");
  @Rule
  public WireMockRule wireMockRule = new WireMockRule(9090);
  @Rule
  public ExpectedException expectedException = ExpectedException.none();
  private String policyNumber = "12345";
  private String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI5c0JRSTUtMDZLVldNUnJyMEg2dWdfaEhIbXA5a3VQUndQN3o4cGtUcWgwIn0.eyJqdGkiOiJmNmM3OGU2My1kZDAxLTRjY2ItODNkMy04NjhjMzUwM2U4ODkiLCJleHAiOjE1MjE4MDUyMjAsIm5iZiI6MCwiaWF0IjoxNTIxODA0OTIwLCJpc3MiOiJodHRwczovL3NlY3VyZS1zc28tYWpiLXJodC1zc28uYXBwcy5uYTEub3BlbnNoaWZ0Lm9wZW50bGMuY29tL2F1dGgvcmVhbG1zL3JodF9ncHRlXzNzY2FsZV9yZWFsbSIsImF1ZCI6ImN1cmxDbGllbnQiLCJzdWIiOiIzNmZiZTBiNi04OTI3LTQ4YzItOTc0NS1jZmY5MmFkODgwYTUiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJjdXJsQ2xpZW50IiwiYXV0aF90aW1lIjowLCJzZXNzaW9uX3N0YXRlIjoiOTI0YzgyNmMtZTJlZi00NDZhLTgyMzctZDY1NTczNDcyOTQ3IiwiYWNyIjoiMSIsImNsaWVudF9zZXNzaW9uIjoiM2Y2MDExNTMtMmY2YS00YjAzLWEzNTQtMTI4ODFjN2UwYzFmIiwiYWxsb3dlZC1vcmlnaW5zIjpbXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbInVtYV9hdXRob3JpemF0aW9uIiwic3dhcm1Sb2xlIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsInZpZXctcHJvZmlsZSJdfX0sIm5hbWUiOiIiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJzd2FybV9kZXYifQ.JkSg7CmTDreA-gEyS88LWcQbiEYRMZS869DiwcCHGxX9DM4AcSKFSbJa1gLhJYygaCNPZm69ySds35eDNyBJHnc5lfFA9rdvDAVFUz4ypxA0ZmpKJiFqsNYmoGSMlVhaCHZcUhbdcRBg6fMsAmkJJ_cQ0wrK1bBiUD03IGsuZW6ojG_RE99V5t3lI1x3T8ITAl7uFmbFYwtPvosZJoYhWazWwPQz0CxgyVLeLi-lNI0U79ZPfIg06h1KfXuIgM2nClOaO9zY1LY1u7H5bbOBbxdF-nTfyclQ5QIC4-dPKk2AZmQ7Djc6FUisPaRffyX1LxlzkrPYP4liVdTn2YEQVQ";
  private String concatBenefitSequenceId = "ABCD9999";
  private String fundCode = "GB99999901";
  private WorkplacePensionHoldingsDto workplacePensionHoldingsDto;
  private WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto switchRedirectCheckAllowedResponseDto;
  private WorkplacePensionCustomerDetailsDto customerDetailsDto;
  private WorkplacePensionInputDto workplacePensionInputDto;
  private WorkplacePensionSwitchAndRedirectOrderResponseDto switchAndRedirectOrderResponseDto;
  private InvestmentDetailDto investmentDetailDto;

  @Autowired
  private ApplicationContext applicationContext;

  @Autowired
  private WorkplaceSavingsService workplaceSavingsService;

  @Value("${investment.details.service.url}")
  private String investmentBenefitsServiceUrl;

  @Value("${valuation.reason.code}")
  private String valuationReasonCode;

  @Value("${entitlements.business.function}")
  private String entitlementsBusinessFunction;

  private String journeyId = generateUuid();

  @After
  public void tearDown() {
    wireMockRule.shutdown();
  }

  @Before
  public void setUp() {
    workplacePensionHoldingsDto = WorkplacePensionHoldingsDto.builder()
        .lastRegularContribution(new BigDecimal(100))
        .lastRegularContributionFrequencyCode(LastRegularContributionFrequencyCode.FOUR_WEEKLY)
        .benefits(Arrays.asList(BenefitDto.builder().concatBenefitSequenceId(concatBenefitSequenceId)
            .type(BenefitType.REGULAR)
            .holdings(Arrays.asList(WorkplacePensionHoldingDto.builder()
                .fundCode(fundCode)
                .fundTypeLifestyle(true)
                .name("some name")
                .unitsHeld(55f)
                .unitPriceDate(new Date())
                .build()))
            .build()))
        .future(Arrays.asList(InvestmentStrategyDto.builder()
            .fundCode(fundCode)
            .contributionPercentage(33.34f)
            .name("fund name")
            .build()))
        .build();

    investmentDetailDto = InvestmentDetailDto.builder().workplacePensionHoldingsDto(workplacePensionHoldingsDto)
        .permittedByRole(true)
        .build();

    switchRedirectCheckAllowedResponseDto = WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto.builder()
        .noPostalAddress(false)
        .permittedByScheme(true)
        .wipStatus(WorkInProgressCheckDto.builder()
            .wipSet(true)
            .build())
        .build();

    customerDetailsDto = WorkplacePensionCustomerDetailsDto.builder()
        .emailAddress("someone@aol.com")
        .schemeCategory("scheme-category")
        .schemeMembership("scheme-membership")
        .build();

    switchAndRedirectOrderResponseDto = WorkplacePensionSwitchAndRedirectOrderResponseDto.builder()
        .wipResponse(WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto.builder().permittedByScheme(false).noPostalAddress(true).build())
        .outcome(Outcome.SUCCESS)
        .build();

    workplacePensionInputDto = WorkplacePensionInputDto.builder()
        .emailAddress("xyz.com")
        .benefitsHoldings(getBenefitsHoldings())
        .benefitsFutureContributions(getBenefitsFutureContributions())
        .build();
  }

  public static List<BenefitInputDto> getBenefitsHoldings() {
    List<FundInputDto> benefitInputDto1Funds = new ArrayList();
    benefitInputDto1Funds.add(FundInputDto.builder().fundCode("EAAY").percentage(101.23f).fundTypeLifestyle(false).build());
    benefitInputDto1Funds.add(FundInputDto.builder().fundCode("EABY").percentage(102.23f).fundTypeLifestyle(false).build());
    benefitInputDto1Funds.add(FundInputDto.builder().fundCode("EACY").percentage(103.23f).fundTypeLifestyle(false).build());
    List<FundInputDto> benefitInputDto2Funds = new ArrayList();
    benefitInputDto2Funds.add(FundInputDto.builder().fundCode("EADY").percentage(104.23f).fundTypeLifestyle(false).build());
    benefitInputDto2Funds.add(FundInputDto.builder().fundCode("EAEY").percentage(105.23f).fundTypeLifestyle(false).build());
    benefitInputDto2Funds.add(FundInputDto.builder().fundCode("EAFY").percentage(106.23f).fundTypeLifestyle(false).build());
    List<BenefitInputDto> benefitHoldings = new ArrayList();
    benefitHoldings.add(BenefitInputDto.builder()
        .concatBenefitSequenceId("01")
        .funds(benefitInputDto1Funds)
        .build());
    benefitHoldings.add(BenefitInputDto.builder()
        .concatBenefitSequenceId("02")
        .funds(benefitInputDto2Funds)
        .build());
    return benefitHoldings;
  }

  public static List<BenefitInputDto> getBenefitsFutureContributions() {
    List<FundInputDto> benefitInputDto1Funds = new ArrayList();
    benefitInputDto1Funds.add(FundInputDto.builder().fundCode("EAZY").percentage(23.23f).fundTypeLifestyle(false).build());
    benefitInputDto1Funds.add(FundInputDto.builder().fundCode("EAYY").percentage(24.23f).fundTypeLifestyle(false).build());
    benefitInputDto1Funds.add(FundInputDto.builder().fundCode("EAXY").percentage(25.23f).fundTypeLifestyle(false).build());
    List<FundInputDto> benefitInputDto2Funds = new ArrayList();
    benefitInputDto2Funds.add(FundInputDto.builder().fundCode("EAMY").percentage(26.23f).fundTypeLifestyle(false).build());
    benefitInputDto2Funds.add(FundInputDto.builder().fundCode("EANY").percentage(27.23f).fundTypeLifestyle(false).build());
    benefitInputDto2Funds.add(FundInputDto.builder().fundCode("EAOY").percentage(28.23f).fundTypeLifestyle(false).build());
    List<BenefitInputDto> benefitHoldings = new ArrayList();
    benefitHoldings.add(BenefitInputDto.builder()
        .concatBenefitSequenceId("03")
        .funds(benefitInputDto1Funds)
        .build());
    benefitHoldings.add(BenefitInputDto.builder()
        .concatBenefitSequenceId("04")
        .funds(benefitInputDto2Funds)
        .build());
    return benefitHoldings;
  }

  @Test
  public void shouldReturnListOfHoldingsWhenPresent() throws JsonProcessingException {

    stubFor(get(urlPathEqualTo(filterUrl()))
        .withQueryParam("valuationreasoncode", equalTo("SO"))
        .withQueryParam("entitlementsbusinessfunction", equalTo("SWTC"))
        .withHeader(RestUtil.JWT_TOKEN_REST_HEADER_NAME, equalTo(jwtToken))
        .withHeader(RestUtil.JOURNEY_ID_REST_HEADER_NAME, matching(UUID_PATTERN.pattern()))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(new ObjectMapper().writeValueAsString(investmentDetailDto))));

    WorkplacePensionHoldingsDto result = workplaceSavingsService.getWorkplacePensionHoldings(policyNumber, jwtToken,journeyId);

    assertEquals(workplacePensionHoldingsDto, result);
    assertEquals(workplacePensionHoldingsDto.getPermittedByRole(), result.getPermittedByRole());
  }

  @Test
  public void shouldThrowExceptionWhenPermittedByRoleFalse() throws JsonProcessingException {

    expectedException.expect(Exception.class);
    investmentDetailDto = InvestmentDetailDto.builder().workplacePensionHoldingsDto(workplacePensionHoldingsDto)
        .permittedByRole(false)
        .build();

    stubFor(get(urlPathEqualTo(filterUrl()))
        .withQueryParam("valuationreasoncode", equalTo("SO"))
        .withQueryParam("entitlementsbusinessfunction", equalTo("SWTC"))
        .withHeader(RestUtil.JWT_TOKEN_REST_HEADER_NAME, equalTo(jwtToken))
        .withHeader(RestUtil.JOURNEY_ID_REST_HEADER_NAME, matching(UUID_PATTERN.pattern()))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(new ObjectMapper().writeValueAsString(investmentDetailDto))));

    WorkplacePensionHoldingsDto result = workplaceSavingsService.getWorkplacePensionHoldings(policyNumber, jwtToken,journeyId);

    assertNull("result should be Null.", result);
  }

  @Test
  public void shouldThrowExceptionWhenErrorOccurs() {

    expectedException.expect(HttpServerErrorException.class);

    stubFor(get(urlPathEqualTo(filterUrl()))
        .withQueryParam("valuationreasoncode", equalTo("SO"))
        .withQueryParam("entitlementsbusinessfunction", equalTo("SWTC"))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")
            .withBody("")));

    WorkplacePensionHoldingsDto result = workplaceSavingsService.getWorkplacePensionHoldings(policyNumber, jwtToken,journeyId);
    assertNull(result);
  }

  @Test
  public void shouldReturnListIfSwitchAndRedirectAllowed() throws JsonProcessingException {

    stubFor(get(urlPathEqualTo("/wip/policy/" + policyNumber))
        .withQueryParam("businessFunction", equalTo("SWTC"))
        .withHeader(RestUtil.JWT_TOKEN_REST_HEADER_NAME, equalTo(jwtToken))
        .withHeader(RestUtil.JOURNEY_ID_REST_HEADER_NAME, matching(UUID_PATTERN.pattern()))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(new ObjectMapper().writeValueAsString(switchRedirectCheckAllowedResponseDto))));

    WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto result = workplaceSavingsService.isSwitchAndRedirectAllowed(policyNumber, jwtToken,journeyId);

    assertEquals(switchRedirectCheckAllowedResponseDto, result);
  }

  @Test
  public void shouldThrowExceptionWhenErrorOccursForSwitchAndRedirectCheck() {

    expectedException.expect(HttpServerErrorException.class);

    stubFor(get(urlPathEqualTo("/wip/policy/" + policyNumber))
        .withQueryParam("businessFunction", equalTo("SWTC"))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")
            .withBody("")));

    WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto result = workplaceSavingsService.isSwitchAndRedirectAllowed(policyNumber, jwtToken,journeyId);

    assertNull(result);
  }

  @Test
  public void shouldThrowExceptionWhenErrorOccursForAllowableFundsMicroservice() {

    expectedException.expect(HttpServerErrorException.class);

    stubFor(get(urlEqualTo("/lgim/allowableFunds/retrieveAllowableFunds?policyNumber=12345&schemeCategory=&schemeId=&productId="))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")));

    WorkplacePensionFunds funds = workplaceSavingsService.retrieveAllowableFunds(policyNumber, "", "", "", jwtToken,journeyId);

    assertNull(funds);
  }

  @Test
  public void shouldThrowExceptionWhenErrorOccursForFundsDetail() throws Exception {
    expectedException.expect(HttpServerErrorException.class);

    stubFor(get(urlMatching("/lgim/funds/retrieveFundsDetail/DBAU"))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")));

    List<WorkplacePensionFundDto> funds = workplaceSavingsService.getWorkplacePensionFundDetails(Lists.newArrayList("DBAU"), jwtToken,journeyId);

    assertNull(funds);
  }

  @Test
  public void shouldReturnResponseForFundsDetail() throws Exception {
    stubFor(get(urlMatching("/lgim/funds/retrieveFundsDetail/DBAU"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBodyFile("response-success.json")));

    List<WorkplacePensionFundDto> funds = workplaceSavingsService.getWorkplacePensionFundDetails(Lists.newArrayList("DBAU"), jwtToken,journeyId);
    assertNotNull(funds);
  }


  @Test
  public void shouldReturnResponseForAllowableFundsMicroservice() throws Exception {

    stubFor(get(urlEqualTo("/lgim/allowableFunds/retrieveAllowableFunds?policyNumber=12345&schemeCategory=DC&schemeId=SD&productId=DF"))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBodyFile("response-success.json")));

    WorkplacePensionFunds funds = workplaceSavingsService.retrieveAllowableFunds(policyNumber, "DC", "SD", "DF", jwtToken,journeyId);
    String jsonInString = new ObjectMapper().writeValueAsString(funds);
    assertNotNull(funds);
    assertNotNull(jsonInString);
  }

  @Test
  public void shouldReturnCustomerDetailsIfFound() throws JsonProcessingException {

    stubFor(get(urlEqualTo("/customer/policy/" + policyNumber))
        .withHeader(RestUtil.JWT_TOKEN_REST_HEADER_NAME, equalTo(jwtToken))
        .withHeader(RestUtil.JOURNEY_ID_REST_HEADER_NAME, matching(UUID_PATTERN.pattern()))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(new ObjectMapper().writeValueAsString(customerDetailsDto))));

    WorkplacePensionCustomerDetailsDto result = workplaceSavingsService.getWorkplacePensionCustomerDetails(policyNumber, jwtToken,journeyId);

    assertEquals(customerDetailsDto, result);
  }

  @Test
  public void shouldThrowExceptionWhenErrorOccursForCustomerDetails() {

    expectedException.expect(HttpServerErrorException.class);

    stubFor(get(urlEqualTo("/customer/policy/" + policyNumber))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")
            .withBody("")));

    WorkplacePensionCustomerDetailsDto result = workplaceSavingsService.getWorkplacePensionCustomerDetails(policyNumber, jwtToken,journeyId);

    assertNull("result should be Null.", result);
  }

  @Test
  public void testProcessWorkplacePensionSwitchAndRedirectOrder() throws Exception {

    stubFor(post(urlEqualTo("/accept/" + policyNumber + "?valuationreasoncode=SO&businessfunction=SWTC"))
        //.withQueryParam("valuationreasoncode", equalTo("SO"))
        //.withQueryParam("businessfunction", equalTo("SWTC"))
        .withHeader(RestUtil.JWT_TOKEN_REST_HEADER_NAME, equalTo(jwtToken))
        .withHeader(RestUtil.JOURNEY_ID_REST_HEADER_NAME, matching(UUID_PATTERN.pattern()))
        .withRequestBody(equalToJson(new ObjectMapper().writeValueAsString(workplacePensionInputDto)))
        .willReturn(aResponse()
            .withStatus(200)
            .withHeader("Content-Type", "application/json")
            .withBody(new ObjectMapper().writeValueAsString(switchAndRedirectOrderResponseDto))
        ));

    WorkplacePensionSwitchAndRedirectOrderResponseDto result =
        workplaceSavingsService.processWorkplacePensionSwitchAndRedirectOrder(policyNumber, workplacePensionInputDto, jwtToken,journeyId);

    assertEquals("Both flags should be equal.", switchAndRedirectOrderResponseDto.getWipResponse().getPermittedByScheme(), result.getWipResponse().getPermittedByScheme());
    assertEquals("Both objects should be equal.", switchAndRedirectOrderResponseDto, result);
  }

  @Test
  public void shouldThrowExceptionProcessingWPSROrder() throws Exception {

    expectedException.expect(HttpServerErrorException.class);

    stubFor(post(urlEqualTo("/accept/" + policyNumber + "?valuationreasoncode=SO&businessfunction=SWTC"))
        //.withQueryParam("valuationreasoncode", equalTo("SO"))
        //.withQueryParam("businessfunction", equalTo("SWTC"))
        .willReturn(aResponse()
            .withStatus(500)
            .withHeader("Content-Type", "application/json")
            .withBody("")));

    WorkplacePensionSwitchAndRedirectOrderResponseDto result =
        workplaceSavingsService.processWorkplacePensionSwitchAndRedirectOrder(policyNumber, workplacePensionInputDto, jwtToken,journeyId);

    assertNull("result should be Null.", result);
  }

  @Test
  public void testUnhashPolicyNumSuccess() throws Exception {
    String data = "{\"roleTypeCode\":\"AG\"," +
        "\"accountID\":\"2595456031\"," +
        "\"contractEngineType\":\"AD\",\"productHoldingType\":\"AQ\"," +
        "\"valuationClass\":\"BSE\",\"accountStatus\":\"IF\",\"accountInception\":\"06/2018\"," +
        "\"accountExpiry\":\"2044\",\"groupArrangementID\":\"GF95697000\"}";
    stubFor(get(urlEqualTo("/accountsByPartyId/" + policyNumber))
        .willReturn(
            aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody(data)
        ));
    String unhashedPolicy = workplaceSavingsService.unhashPolicyNumber(policyNumber, jwtToken,journeyId);
    assertNotNull("A policy response is processed successfully", unhashedPolicy);
    assertEquals("retrieving the correct policy/account number", "2595456031", unhashedPolicy);
  }

  @Test
  public void testUnhashPolicyNumFailure() throws Exception {
    expectedException.expect(GraphQLException.class);
    String data = "";
    stubFor(get(urlEqualTo("/accountsByPartyId/" + policyNumber))
        .willReturn(
            aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody(data)
        ));
    workplaceSavingsService.unhashPolicyNumber(policyNumber, jwtToken,journeyId);
  }

  private String filterUrl() {
    return ("/holdings/policy/" + policyNumber);
  }

  private String generateUuid() {
    return UUID.randomUUID().toString();
  }
}