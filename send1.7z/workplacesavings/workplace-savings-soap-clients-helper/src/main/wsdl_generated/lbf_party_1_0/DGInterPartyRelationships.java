
package lbf_party_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_InterPartyRelationships complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_InterPartyRelationships"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="partyId1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="partyId2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="partyId2SubType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="relationshipType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="relationshipStartDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="relationshipEndDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_InterPartyRelationships", propOrder = {
    "partyId1",
    "partyId2",
    "partyId2SubType",
    "relationshipType",
    "relationshipStartDate",
    "relationshipEndDate"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGInterPartyRelationships
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String partyId1;
    protected String partyId2;
    protected String partyId2SubType;
    protected String relationshipType;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar relationshipStartDate;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar relationshipEndDate;

    /**
     * Gets the value of the partyId1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId1() {
        return partyId1;
    }

    /**
     * Sets the value of the partyId1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId1(String value) {
        this.partyId1 = value;
    }

    /**
     * Gets the value of the partyId2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId2() {
        return partyId2;
    }

    /**
     * Sets the value of the partyId2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId2(String value) {
        this.partyId2 = value;
    }

    /**
     * Gets the value of the partyId2SubType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId2SubType() {
        return partyId2SubType;
    }

    /**
     * Sets the value of the partyId2SubType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId2SubType(String value) {
        this.partyId2SubType = value;
    }

    /**
     * Gets the value of the relationshipType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipType() {
        return relationshipType;
    }

    /**
     * Sets the value of the relationshipType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipType(String value) {
        this.relationshipType = value;
    }

    /**
     * Gets the value of the relationshipStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRelationshipStartDate() {
        return relationshipStartDate;
    }

    /**
     * Sets the value of the relationshipStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRelationshipStartDate(XMLGregorianCalendar value) {
        this.relationshipStartDate = value;
    }

    /**
     * Gets the value of the relationshipEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRelationshipEndDate() {
        return relationshipEndDate;
    }

    /**
     * Sets the value of the relationshipEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRelationshipEndDate(XMLGregorianCalendar value) {
        this.relationshipEndDate = value;
    }

}
