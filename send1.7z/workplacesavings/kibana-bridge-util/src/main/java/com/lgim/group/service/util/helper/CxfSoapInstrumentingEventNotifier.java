package com.lgim.group.service.util.helper;

import com.lgim.group.ws.utility.plugin.model.AuditData;
import com.lgim.group.ws.utility.plugin.model.GroupDigitalMessage;
import com.lgim.group.ws.utility.plugin.model.MailAlertData;
import com.lgim.group.ws.utility.plugin.util.AuditRouteHelper;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.EventObject;
import java.util.HashMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.cxf.CxfEndpoint;
import org.apache.camel.management.event.ExchangeFailedEvent;
import org.apache.camel.management.event.ExchangeSendingEvent;
import org.apache.camel.management.event.ExchangeSentEvent;
import org.apache.camel.support.EventNotifierSupport;
import org.apache.commons.lang3.exception.ExceptionUtils;

@Slf4j
/**
 * This class instruments calls to CXF endpoints
 */
public class CxfSoapInstrumentingEventNotifier extends EventNotifierSupport {

  public static final String GROUP_DIGITAL_MESSAGE_FOR_CXF_INSTRUMENTATION_PROPERTY_KEY = "groupDigitalMessageForCxfInstrumentation";
  private AuditRouteHelper auditRouteHelper = new AuditRouteHelper();
  private final ProducerTemplate producerTemplate;

  public CxfSoapInstrumentingEventNotifier(ProducerTemplate producerTemplate) {
    this.producerTemplate = producerTemplate;
  }

  @Override
  public void notify(EventObject event) throws Exception {
    try {
      if (event instanceof ExchangeSendingEvent) {
        ExchangeSendingEvent exchangeSendingEvent = (ExchangeSendingEvent) event;
        if (exchangeSendingEvent.getEndpoint() instanceof CxfEndpoint) {
          processExchangeSendingEvent(exchangeSendingEvent);
          return;
        }
      }
      if (event instanceof ExchangeSentEvent) {
        ExchangeSentEvent exchangeSentEvent = (ExchangeSentEvent) event;
        if (exchangeSentEvent.getEndpoint() instanceof CxfEndpoint) {
          processExchangeSentEvent(exchangeSentEvent);
        }
        return;
      }
      if (event instanceof ExchangeFailedEvent) {
        ExchangeFailedEvent exchangeFailedEvent = (ExchangeFailedEvent) event;
        if (exchangeFailedEvent.getExchange().getProperty(GROUP_DIGITAL_MESSAGE_FOR_CXF_INSTRUMENTATION_PROPERTY_KEY) != null) {
          processExchangeFailedEvent(exchangeFailedEvent);
        }
        return;
      }
    } catch (Exception ex) {
      log.warn("Unable to extract CXF information for instrumentation to logs", ex);
    }
  }

  private void processExchangeFailedEvent(ExchangeFailedEvent exchangeFailedEvent) {
    GroupDigitalMessage originalGdm = exchangeFailedEvent.getExchange().getProperty(GROUP_DIGITAL_MESSAGE_FOR_CXF_INSTRUMENTATION_PROPERTY_KEY, GroupDigitalMessage.class);
    long timeTaken = new Date().getTime() - originalGdm.getAuditData().getCreatedAt().toInstant().toEpochMilli();
    log.info("CXF endpoint failed. Time taken for call to [{}] was [{}]ms", timeTaken);
    exchangeFailedEvent.getExchange().removeProperty(GROUP_DIGITAL_MESSAGE_FOR_CXF_INSTRUMENTATION_PROPERTY_KEY);
    Throwable cause = exchangeFailedEvent.getCause();
    logGroupDigitalMessageAsFailure(originalGdm, timeTaken, cause);
  }

  private void processExchangeSendingEvent(ExchangeSendingEvent exchangeSendingEvent) {
    CxfEndpoint cxfEndpoint = (CxfEndpoint) exchangeSendingEvent.getEndpoint();
    String address = cxfEndpoint.getAddress();
    log.info("Found CXF endpoint - before for url [{}]", address);
    GroupDigitalMessage groupDigitalMessage = exchangeSendingEvent.getExchange().getProperty("groupDigitalMessage", GroupDigitalMessage.class);
    if (groupDigitalMessage == null) {
      log.info("GroupDigitalMessage not found so not logging the request");
      return;
    }
    String serviceClass = cxfEndpoint.getServiceClass().getName();
    String request = exchangeSendingEvent.getExchange().getIn().getBody().toString();
    String routeId = exchangeSendingEvent.getExchange().getUnitOfWork().getRouteContext().getRoute().getId();

    logGroupDigitalMessageAsRequest(groupDigitalMessage, address, serviceClass, request, routeId, exchangeSendingEvent.getExchange());
  }

  private void processExchangeSentEvent(ExchangeSentEvent exchangeSentEvent) {
    long timeTaken = exchangeSentEvent.getTimeTaken();
    CxfEndpoint cxfEndpoint = (CxfEndpoint) exchangeSentEvent.getEndpoint();
    String address = cxfEndpoint.getAddress();
    log.info("Found CXF endpoint - after. Time taken for call to [{}] was [{}]ms", address, timeTaken);
    GroupDigitalMessage groupDigitalMessage = exchangeSentEvent.getExchange().getProperty(GROUP_DIGITAL_MESSAGE_FOR_CXF_INSTRUMENTATION_PROPERTY_KEY, GroupDigitalMessage.class);
    if (groupDigitalMessage == null) {
      log.info("GroupDigitalMessage not found so not logging the response");
      return;
    }
    exchangeSentEvent.getExchange().removeProperty(GROUP_DIGITAL_MESSAGE_FOR_CXF_INSTRUMENTATION_PROPERTY_KEY);
    String serviceClass = cxfEndpoint.getServiceClass().getName();
    String response;
    if (exchangeSentEvent.getExchange().getOut().getBody()==null) {
      response = "No response from service, probably an error";
    } else {
      response = exchangeSentEvent.getExchange().getOut().getBody().toString();
    }
    String routeId = exchangeSentEvent.getExchange().getUnitOfWork().getRouteContext().getRoute().getId();
    logGroupDigitalMessageAsResponse(groupDigitalMessage, address, serviceClass, response, timeTaken, routeId);
  }

  @Override
  public boolean isEnabled(EventObject event) {
    if (event instanceof ExchangeSendingEvent) {
      return true;
    }
    if (event instanceof ExchangeSentEvent) {
      return true;
    }
    if (event instanceof ExchangeFailedEvent) {
      return true;
    }
    return false;
  }

  private void logGroupDigitalMessageAsRequest(GroupDigitalMessage originalGroupDigitalMessage, String url, String serviceClassName, String request, String routeId, Exchange exchange) {
    GroupDigitalMessage gdm = populateGroupDigitalMessageWithDefaults(originalGroupDigitalMessage, url, serviceClassName, routeId);
    gdm.getTags().put("is_request", "true");
    gdm.getTags().put("request_generated_timestamp", getNowAsMillisString());
    gdm.getTags().put("status", "Calling CXF Soap service " + url);
    gdm.getPayloads().put("service_request", request);

    //get Claims from REST request GroupDigitalMessage
    try {
      if (exchange.getProperties().containsKey(CamelRouteInstrumentationHelper.GROUP_DIGITAL_MESSAGE_FOR_INCOMING_REST_PROPERTY_KEY)) {
        GroupDigitalMessage gdmRest = exchange.getProperty(CamelRouteInstrumentationHelper.GROUP_DIGITAL_MESSAGE_FOR_INCOMING_REST_PROPERTY_KEY, GroupDigitalMessage.class);
        for (String tagKey : gdmRest.getTags().keySet()) {
          if (tagKey.startsWith("claims_")) {
            gdm.getTags().put(tagKey, gdmRest.getTags().get(tagKey));
          }
        }
      }
    } catch (Exception ex2) {
        //ignore
    }

    exchange.setProperty(GROUP_DIGITAL_MESSAGE_FOR_CXF_INSTRUMENTATION_PROPERTY_KEY, gdm);
    auditRouteHelper.sendGroupDigitalMessageForAuditing(producerTemplate, gdm);
  }

  private void logGroupDigitalMessageAsResponse(GroupDigitalMessage originalGroupDigitalMessage, String url, String serviceClassName, String response, Long timeTaken, String routeId) {
    originalGroupDigitalMessage.getTags().put("is_response", "true");
    originalGroupDigitalMessage.getTags().put("response_received_timestamp", getNowAsMillisString());
    originalGroupDigitalMessage.getTags().put("service_request_response_duration_integer", timeTaken.toString());
    originalGroupDigitalMessage.getTags().put("status", "Completed calling CXF Soap service " + url);

    originalGroupDigitalMessage.getTags().remove("is_request");
    String currentRoute = originalGroupDigitalMessage.getAuditData().getCurrentRoute();
    originalGroupDigitalMessage.setAuditData(new AuditData());
    originalGroupDigitalMessage.getAuditData().setCurrentRoute(currentRoute);
    originalGroupDigitalMessage.getPayloads().put("service_response", response);
    auditRouteHelper.sendGroupDigitalMessageForAuditing(producerTemplate, originalGroupDigitalMessage);
  }

  private void logGroupDigitalMessageAsFailure(GroupDigitalMessage originalGroupDigitalMessage, Long timeTaken, Throwable cause) {
    originalGroupDigitalMessage.getTags().put("is_response", "true");
    originalGroupDigitalMessage.getTags().remove("is_request");
    originalGroupDigitalMessage.getTags().put("is_exception", "true");
    originalGroupDigitalMessage.getTags().put("response_received_timestamp", getNowAsMillisString());
    originalGroupDigitalMessage.getTags().put("service_request_response_duration_integer", timeTaken.toString());
    originalGroupDigitalMessage.getTags().put("status", "Completed calling CXF Soap service " + originalGroupDigitalMessage.getTags().get("service_url"));
    originalGroupDigitalMessage.getPayloads().put("exception", ExceptionUtils.getStackTrace(cause));
    originalGroupDigitalMessage.getPayloads().put("exception_messsage", cause.getMessage());

    auditRouteHelper.sendGroupDigitalMessageForAuditing(producerTemplate, originalGroupDigitalMessage);
  }

  private GroupDigitalMessage populateGroupDigitalMessageWithDefaults(GroupDigitalMessage originalGroupDigitalMessage, String serviceUrl, String serviceClassName, String routeId) {
    GroupDigitalMessage gdm = GroupDigitalMessage.builder()
        .businessFunction(originalGroupDigitalMessage.getBusinessFunction())
        .journeyId(originalGroupDigitalMessage.getJourneyId())
        .microserviceMethod(originalGroupDigitalMessage.getMicroserviceMethod())
        .microserviceName(originalGroupDigitalMessage.getMicroserviceName())
        .systemId(originalGroupDigitalMessage.getSystemId())
        .auditData(new AuditData())
        .alertData(new MailAlertData())
        .build();
    gdm.setTags(new HashMap<>());
    gdm.setPayloads(new HashMap<>());
    gdm.setErrors(new ArrayList<>());
    gdm.getTags().put("service_url", serviceUrl);
    gdm.getTags().put("service_class", serviceClassName);
    gdm.getTags().put("is_framework_generated", "true");
    gdm.getTags().put("protocol", "soap");
    gdm.getAuditData().setCurrentRoute(routeId);
    gdm.getAuditData().setUpdatedAt(ZonedDateTime.now());
    gdm.getAuditData().setCreatedAt(ZonedDateTime.now());
    return gdm;
  }

  private String getNowAsMillisString() {
    return new Long(new Date().getTime()).toString();
  }

}
