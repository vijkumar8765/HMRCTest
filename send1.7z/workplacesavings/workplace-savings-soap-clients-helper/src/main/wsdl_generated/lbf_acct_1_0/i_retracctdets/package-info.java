@javax.xml.bind.annotation.XmlSchema(namespace = "http://LBF_Acct_1_0/I_RetrAcctDets")
package lbf_acct_1_0.i_retracctdets;
