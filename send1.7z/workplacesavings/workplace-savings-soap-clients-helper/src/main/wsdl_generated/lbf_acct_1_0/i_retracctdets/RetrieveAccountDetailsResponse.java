
package lbf_acct_1_0.i_retracctdets;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import lbf_acct_1_0.DGRetrAcctDetsResponse;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="resp" type="{http://LBF_Acct_1_0}DG_RetrAcctDetsResponse"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "resp"
})
@XmlRootElement(name = "retrieveAccountDetailsResponse")
@ToString
@EqualsAndHashCode
public class RetrieveAccountDetailsResponse implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(required = true, nillable = true)
    protected DGRetrAcctDetsResponse resp;

    /**
     * Gets the value of the resp property.
     * 
     * @return
     *     possible object is
     *     {@link DGRetrAcctDetsResponse }
     *     
     */
    public DGRetrAcctDetsResponse getResp() {
        return resp;
    }

    /**
     * Sets the value of the resp property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGRetrAcctDetsResponse }
     *     
     */
    public void setResp(DGRetrAcctDetsResponse value) {
        this.resp = value;
    }

}
