
package lbf_acct_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGResponseEnvelope;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_RetrUnmtchdCashResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_RetrUnmtchdCashResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_ResponseEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="unmtchdCashSearchResult" type="{http://LBF_Acct_1_0}DG_UnmtchdCashSearchResult" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_RetrUnmtchdCashResponse", propOrder = {
    "unmtchdCashSearchResult"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGRetrUnmtchdCashResponse
    extends DGResponseEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGUnmtchdCashSearchResult unmtchdCashSearchResult;

    /**
     * Gets the value of the unmtchdCashSearchResult property.
     * 
     * @return
     *     possible object is
     *     {@link DGUnmtchdCashSearchResult }
     *     
     */
    public DGUnmtchdCashSearchResult getUnmtchdCashSearchResult() {
        return unmtchdCashSearchResult;
    }

    /**
     * Sets the value of the unmtchdCashSearchResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGUnmtchdCashSearchResult }
     *     
     */
    public void setUnmtchdCashSearchResult(DGUnmtchdCashSearchResult value) {
        this.unmtchdCashSearchResult = value;
    }

}
