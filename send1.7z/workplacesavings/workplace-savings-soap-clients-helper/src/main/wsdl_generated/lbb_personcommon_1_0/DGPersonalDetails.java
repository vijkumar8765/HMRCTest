
package lbb_personcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_PersonalDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_PersonalDetails"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="title" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="initials" type="{http://LBB_PersonCommon_1_0}DG_Initials" minOccurs="0"/&gt;
 *         &lt;element name="death" type="{http://LBB_PersonCommon_1_0}DG_Death" minOccurs="0"/&gt;
 *         &lt;element name="bankruptcy" type="{http://LBB_PersonCommon_1_0}DG_Bankruptcy" minOccurs="0"/&gt;
 *         &lt;element name="residency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="domicile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="unverifiedDetails" type="{http://LBB_PersonCommon_1_0}DG_VerifiableDetails" minOccurs="0"/&gt;
 *         &lt;element name="verifiedDetails" type="{http://LBB_PersonCommon_1_0}DG_VerifiableDetails" minOccurs="0"/&gt;
 *         &lt;element name="smokerType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="marketingAttitude" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="servicingAttitude" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="personDetailsVerifiedInd" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="lifeSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_PersonalDetails", propOrder = {
    "title",
    "initials",
    "death",
    "bankruptcy",
    "residency",
    "domicile",
    "unverifiedDetails",
    "verifiedDetails",
    "smokerType",
    "marketingAttitude",
    "servicingAttitude",
    "personDetailsVerifiedInd",
    "lifeSequenceNumber"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGPersonalDetails
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String title;
    protected DGInitials initials;
    protected DGDeath death;
    protected DGBankruptcy bankruptcy;
    protected String residency;
    protected String domicile;
    protected DGVerifiableDetails unverifiedDetails;
    protected DGVerifiableDetails verifiedDetails;
    protected String smokerType;
    protected String marketingAttitude;
    protected String servicingAttitude;
    protected Boolean personDetailsVerifiedInd;
    protected String lifeSequenceNumber;

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Gets the value of the initials property.
     * 
     * @return
     *     possible object is
     *     {@link DGInitials }
     *     
     */
    public DGInitials getInitials() {
        return initials;
    }

    /**
     * Sets the value of the initials property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGInitials }
     *     
     */
    public void setInitials(DGInitials value) {
        this.initials = value;
    }

    /**
     * Gets the value of the death property.
     * 
     * @return
     *     possible object is
     *     {@link DGDeath }
     *     
     */
    public DGDeath getDeath() {
        return death;
    }

    /**
     * Sets the value of the death property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGDeath }
     *     
     */
    public void setDeath(DGDeath value) {
        this.death = value;
    }

    /**
     * Gets the value of the bankruptcy property.
     * 
     * @return
     *     possible object is
     *     {@link DGBankruptcy }
     *     
     */
    public DGBankruptcy getBankruptcy() {
        return bankruptcy;
    }

    /**
     * Sets the value of the bankruptcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGBankruptcy }
     *     
     */
    public void setBankruptcy(DGBankruptcy value) {
        this.bankruptcy = value;
    }

    /**
     * Gets the value of the residency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResidency() {
        return residency;
    }

    /**
     * Sets the value of the residency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResidency(String value) {
        this.residency = value;
    }

    /**
     * Gets the value of the domicile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDomicile() {
        return domicile;
    }

    /**
     * Sets the value of the domicile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDomicile(String value) {
        this.domicile = value;
    }

    /**
     * Gets the value of the unverifiedDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGVerifiableDetails }
     *     
     */
    public DGVerifiableDetails getUnverifiedDetails() {
        return unverifiedDetails;
    }

    /**
     * Sets the value of the unverifiedDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGVerifiableDetails }
     *     
     */
    public void setUnverifiedDetails(DGVerifiableDetails value) {
        this.unverifiedDetails = value;
    }

    /**
     * Gets the value of the verifiedDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DGVerifiableDetails }
     *     
     */
    public DGVerifiableDetails getVerifiedDetails() {
        return verifiedDetails;
    }

    /**
     * Sets the value of the verifiedDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGVerifiableDetails }
     *     
     */
    public void setVerifiedDetails(DGVerifiableDetails value) {
        this.verifiedDetails = value;
    }

    /**
     * Gets the value of the smokerType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSmokerType() {
        return smokerType;
    }

    /**
     * Sets the value of the smokerType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSmokerType(String value) {
        this.smokerType = value;
    }

    /**
     * Gets the value of the marketingAttitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarketingAttitude() {
        return marketingAttitude;
    }

    /**
     * Sets the value of the marketingAttitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarketingAttitude(String value) {
        this.marketingAttitude = value;
    }

    /**
     * Gets the value of the servicingAttitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServicingAttitude() {
        return servicingAttitude;
    }

    /**
     * Sets the value of the servicingAttitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServicingAttitude(String value) {
        this.servicingAttitude = value;
    }

    /**
     * Gets the value of the personDetailsVerifiedInd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPersonDetailsVerifiedInd() {
        return personDetailsVerifiedInd;
    }

    /**
     * Sets the value of the personDetailsVerifiedInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPersonDetailsVerifiedInd(Boolean value) {
        this.personDetailsVerifiedInd = value;
    }

    /**
     * Gets the value of the lifeSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLifeSequenceNumber() {
        return lifeSequenceNumber;
    }

    /**
     * Sets the value of the lifeSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLifeSequenceNumber(String value) {
        this.lifeSequenceNumber = value;
    }

}
