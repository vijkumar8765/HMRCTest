package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Builder
public class InvestmentDetailDto implements java.io.Serializable {

  private WorkplacePensionHoldingsDto workplacePensionHoldingsDto;
  private Boolean permittedByRole;

  public InvestmentDetailDto(WorkplacePensionHoldingsDto workplacePensionHoldingsDto, Boolean permittedByRole) {
    this.workplacePensionHoldingsDto = workplacePensionHoldingsDto;
    this.permittedByRole = permittedByRole;
  }
}
