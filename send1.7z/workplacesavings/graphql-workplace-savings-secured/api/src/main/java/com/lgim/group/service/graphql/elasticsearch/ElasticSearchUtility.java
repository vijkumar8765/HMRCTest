package com.lgim.group.service.graphql.elasticsearch;

import com.lgim.group.ws.utility.plugin.model.AuditData;
import com.lgim.group.ws.utility.plugin.model.GroupDigitalMessage;

import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.lgim.group.ws.utility.plugin.constants.ServiceUtilConstant.GD_TIMESTAMP_FORMAT;

public class ElasticSearchUtility {

  private static final DateTimeFormatter ES_TIMESTAMP = DateTimeFormatter.ofPattern(GD_TIMESTAMP_FORMAT);
  private static final Pattern UPPERCASE_TO_UNDERSCORES = Pattern.compile("(.)(\\p{Upper})");
  private static final Pattern REPLACE_WITH_UNDERSCORES = Pattern.compile("([- ])");
  private static final Pattern CHECK_LOWERCASE = Pattern.compile("[a-z]");
  private static final Pattern REPLACE_NON_ALPHA = Pattern.compile("[^A-Za-z]");

  private static final Map<AuditData.IndexRollingStrategy, DateTimeFormatter> ES_INDEX_STRATEGIES =
      new HashMap<AuditData.IndexRollingStrategy, DateTimeFormatter>();

  static {
    ES_INDEX_STRATEGIES.put(AuditData.IndexRollingStrategy.DAILY, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    ES_INDEX_STRATEGIES.put(AuditData.IndexRollingStrategy.WEEKLY, DateTimeFormatter.ofPattern("yyyy-MM-'w'W"));
    ES_INDEX_STRATEGIES.put(AuditData.IndexRollingStrategy.MONTHLY, DateTimeFormatter.ofPattern("yyyy-MM"));
    ES_INDEX_STRATEGIES.put(AuditData.IndexRollingStrategy.YEARLY, DateTimeFormatter.ofPattern("yyyy"));
  }

  public static Map<String, String> getElasticSearchBaseMap(GroupDigitalMessage gdMessage, boolean appendTags) {
    Map<String, String> esData = new HashMap<String, String>();

    for (Map.Entry<String, String> payload : gdMessage.getPayloads().entrySet()) {
      String key = "payload_" + convertFieldNameForElasticSearch(payload.getKey());
      esData.put(key, payload.getValue());
    }

    esData.put("system_id", gdMessage.getSystemId());
    esData.put("journey_id", gdMessage.getJourneyId());
    esData.put("business_function", gdMessage.getBusinessFunction());
    esData.put("microservice_name", gdMessage.getMicroserviceName());
    
    esData.put("created_at", ES_TIMESTAMP.format(gdMessage.getAuditData().getCreatedAt()));
    esData.put("updated_at", ES_TIMESTAMP.format(gdMessage.getAuditData().getUpdatedAt()));

    if (appendTags && gdMessage.getTags() != null && !gdMessage.getTags().isEmpty()) {
      for (Map.Entry<String, String> tag : gdMessage.getTags().entrySet()) {
        String key = "tag_" + convertFieldNameForElasticSearch(tag.getKey());
        if (tag.getValue().length() > 255) {
          tag.setValue(tag.getValue().substring(0, 255));
        }
        esData.put(key, tag.getValue());
      }
    }
    if (gdMessage.getAuditData().getCurrentRoute() != null) {
      esData.put("route", gdMessage.getAuditData().getCurrentRoute());
    }

    return esData;
  }

  public static String convertFieldNameForElasticSearch(String fieldName) {
    Matcher checkLowerCase = CHECK_LOWERCASE.matcher(fieldName);

    String newFieldName = fieldName;
    if (checkLowerCase.find()) {
      Matcher upperCaseToUnderscores = UPPERCASE_TO_UNDERSCORES.matcher(fieldName);
      newFieldName = upperCaseToUnderscores.replaceAll("$1_$2");
    }

    newFieldName = newFieldName.toLowerCase();


    Matcher replaceWithUnderscores = REPLACE_WITH_UNDERSCORES.matcher(newFieldName);
    newFieldName = replaceWithUnderscores.replaceAll("_");

    return newFieldName;
  }

  public static String getIndexName(GroupDigitalMessage gdMessage) {
    String indexName = convertBusinessProcessNameForElasticSearchIndex(gdMessage.getBusinessFunction());

    AuditData.IndexRollingStrategy rollingStrategy = gdMessage.getAuditData().getIndexRollingStrategy();

    if (ES_INDEX_STRATEGIES.containsKey(rollingStrategy)) {
      indexName += "-" + ES_INDEX_STRATEGIES.get(rollingStrategy).format(gdMessage.getAuditData().getCreatedAt());
    }

    return indexName;
  }

  public static String convertBusinessProcessNameForElasticSearchIndex(String journeyId) {
    Matcher replaceNoAlpha = REPLACE_NON_ALPHA.matcher(journeyId);
    String indexName = replaceNoAlpha.replaceAll("").toLowerCase();

    return indexName;
  }

  public static String getIndexId() {
    String indexId = UUID.randomUUID().toString();
    return indexId;
  }

}
