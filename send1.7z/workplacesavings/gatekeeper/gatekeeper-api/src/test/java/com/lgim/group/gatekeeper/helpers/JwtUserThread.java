package com.lgim.group.gatekeeper.helpers;

import com.lgim.group.gatekeeper.exception.JwtAuthenticationException;
import com.lgim.group.gatekeeper.processor.ValidateJwtTokenProcessor;
import org.apache.camel.Exchange;
import org.apache.camel.test.junit4.CamelTestSupport;

import java.util.Map;

public class JwtUserThread extends CamelTestSupport implements Runnable {

    private final String AUTHORIZATION_HEADER = "Authorization";

    private String jwtToken;

    private String partyId;

    private int attempts=100;

    private boolean hasPassed = true;

    private Thread t = null;

    private Exchange ex;

    public JwtUserThread(String jwtToken, String partyId, int attempts,  ValidateJwtTokenProcessor processor,Exchange ex ) {
        this.jwtToken = jwtToken;
        this.partyId = partyId;
        this.attempts = attempts;
        this.processor = processor;
        this.ex=ex;
    }

    private ValidateJwtTokenProcessor processor;

    @Override
    public void run() {
        ex.getIn().setHeader(AUTHORIZATION_HEADER,"Bearer " + jwtToken);
        for (int i = 0; i < attempts ; i++)
        {
            try {
                processor.process(ex);
                Map<String,Object> claims = (Map<String,Object>)ex.getIn().getHeader("CLAIMS");
                if (!partyId.equals(claims.get("partyId")))
                {
                    hasPassed = false;
                    break;
                }
                ex.getIn().removeHeader("CLAIMS");
            } catch (JwtAuthenticationException e) {
                hasPassed = false;
                break;
            }
        }


    }

    public Thread getT() {
        return t;
    }

    public boolean hasPassed()
    {
        return hasPassed;
    }

    public void start () {

        if (t == null) {
            t = new Thread (this);
            t.start ();
        }
    }


}
