
package lbb_personcommon_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_Initials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_Initials"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="initial1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="initial2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="intial3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_Initials", propOrder = {
    "initial1",
    "initial2",
    "intial3"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGInitials
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String initial1;
    protected String initial2;
    protected String intial3;

    /**
     * Gets the value of the initial1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitial1() {
        return initial1;
    }

    /**
     * Sets the value of the initial1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitial1(String value) {
        this.initial1 = value;
    }

    /**
     * Gets the value of the initial2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitial2() {
        return initial2;
    }

    /**
     * Sets the value of the initial2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitial2(String value) {
        this.initial2 = value;
    }

    /**
     * Gets the value of the intial3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntial3() {
        return intial3;
    }

    /**
     * Sets the value of the intial3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntial3(String value) {
        this.intial3 = value;
    }

}
