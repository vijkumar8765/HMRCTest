package com.lgim.group.service.graphql.dto;

public enum LastRegularContributionFrequencyCode {

  WEEKLY("WFL"),
  FOUR_WEEKLY("FFL"),
  MONTHLY("MFL");

  private final String lgasCode;

  LastRegularContributionFrequencyCode(String lgasCode) {
    this.lgasCode = lgasCode;
  }

  public static LastRegularContributionFrequencyCode fromLgasString(String text) {
    for (LastRegularContributionFrequencyCode b : LastRegularContributionFrequencyCode.values()) {
      if (b.getLgasCode().equalsIgnoreCase(text)) {
        return b;
      }
    }
    return null;
  }

  public String getLgasCode() {
    return this.lgasCode;
  }
}

