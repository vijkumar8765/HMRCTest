package com.lgim.group.smart.frontend;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {
  @RequestMapping({
      "/investments/isas/apply/assets/static/isa-apply"
  })
  public String calendar(Model model) {
    System.out.println("Request");
    return "forward:/investments/isas/apply/assets/static/isa-apply/index.html";
  }

}
