
package lbb_acct_b_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGRequestEnvelope;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_RetrAcctTransHistValReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_RetrAcctTransHistValReq"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_RequestEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="searchCriteria" type="{http://LBB_Acct_B_1_0}DA_RetrAcctTransHistSrchCrit" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_RetrAcctTransHistValReq", propOrder = {
    "searchCriteria"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DARetrAcctTransHistValReq
    extends DGRequestEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DARetrAcctTransHistSrchCrit searchCriteria;

    /**
     * Gets the value of the searchCriteria property.
     * 
     * @return
     *     possible object is
     *     {@link DARetrAcctTransHistSrchCrit }
     *     
     */
    public DARetrAcctTransHistSrchCrit getSearchCriteria() {
        return searchCriteria;
    }

    /**
     * Sets the value of the searchCriteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link DARetrAcctTransHistSrchCrit }
     *     
     */
    public void setSearchCriteria(DARetrAcctTransHistSrchCrit value) {
        this.searchCriteria = value;
    }

}
