package com.lgim.group.service.graphql.dto;


import java.util.List;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class WorkplacePensionFunds {

  private List<WorkplacePensionFundDto> workplacePensionFundDtoList;

  public WorkplacePensionFunds(List<WorkplacePensionFundDto> workplacePensionFundDtoList) {
    this.workplacePensionFundDtoList = workplacePensionFundDtoList;
  }
}
