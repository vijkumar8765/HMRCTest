
package lbb_acct_b_1_0;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_AccountReceiptPosting complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_AccountReceiptPosting"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="postingAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="postingSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="allocationReference" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="accountTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="matchStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="postingReservedReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="partyId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="protectedRightsIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_AccountReceiptPosting", propOrder = {
    "postingAmount",
    "postingSequenceNumber",
    "allocationReference",
    "accountTypeCode",
    "matchStatus",
    "postingReservedReasonCode",
    "partyId",
    "protectedRightsIndicator"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAAccountReceiptPosting
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected BigDecimal postingAmount;
    protected String postingSequenceNumber;
    protected String allocationReference;
    protected String accountTypeCode;
    protected String matchStatus;
    protected String postingReservedReasonCode;
    protected String partyId;
    protected String protectedRightsIndicator;

    /**
     * Gets the value of the postingAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPostingAmount() {
        return postingAmount;
    }

    /**
     * Sets the value of the postingAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPostingAmount(BigDecimal value) {
        this.postingAmount = value;
    }

    /**
     * Gets the value of the postingSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostingSequenceNumber() {
        return postingSequenceNumber;
    }

    /**
     * Sets the value of the postingSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostingSequenceNumber(String value) {
        this.postingSequenceNumber = value;
    }

    /**
     * Gets the value of the allocationReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllocationReference() {
        return allocationReference;
    }

    /**
     * Sets the value of the allocationReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllocationReference(String value) {
        this.allocationReference = value;
    }

    /**
     * Gets the value of the accountTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountTypeCode() {
        return accountTypeCode;
    }

    /**
     * Sets the value of the accountTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountTypeCode(String value) {
        this.accountTypeCode = value;
    }

    /**
     * Gets the value of the matchStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMatchStatus() {
        return matchStatus;
    }

    /**
     * Sets the value of the matchStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMatchStatus(String value) {
        this.matchStatus = value;
    }

    /**
     * Gets the value of the postingReservedReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostingReservedReasonCode() {
        return postingReservedReasonCode;
    }

    /**
     * Sets the value of the postingReservedReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostingReservedReasonCode(String value) {
        this.postingReservedReasonCode = value;
    }

    /**
     * Gets the value of the partyId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Sets the value of the partyId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartyId(String value) {
        this.partyId = value;
    }

    /**
     * Gets the value of the protectedRightsIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProtectedRightsIndicator() {
        return protectedRightsIndicator;
    }

    /**
     * Sets the value of the protectedRightsIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProtectedRightsIndicator(String value) {
        this.protectedRightsIndicator = value;
    }

}
