package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class ManageYourAccountDetailsDto implements java.io.Serializable {

  private CustomerProfileDto customerProfile;

  public ManageYourAccountDetailsDto(CustomerProfileDto customerProfile) {
    this.customerProfile = customerProfile;
  }
}
