package com.lgim.group.service.graphql;

import com.lgim.group.service.graphql.util.GraphiqlJourneyIdExtractorImpl;
import com.lgim.group.service.graphql.util.GraphiqlJwtTokenExtractorImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@TestPropertySource(locations = "classpath:test.properties")
@ActiveProfiles("graphiql")
public class GraphQLApplicationGraphiqlProfileTest {

  @Autowired
  private ApplicationContext applicationContext;

  @Test
  public void testGraphiqlJwtTokenExtractorBeanIsLoadedForGraphiqlProfile() {

    assertTrue(applicationContext.getBean("jwtTokenExtractor") instanceof GraphiqlJwtTokenExtractorImpl);
    assertTrue(applicationContext.getBean("journeyIdExtractor") instanceof GraphiqlJourneyIdExtractorImpl);

  }
}