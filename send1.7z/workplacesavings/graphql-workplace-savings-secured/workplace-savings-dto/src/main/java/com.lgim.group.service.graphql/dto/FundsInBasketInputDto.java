package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
public class FundsInBasketInputDto implements java.io.Serializable {
  private List<BasketBenefitListInputDto> benefits;
  private BasketType basketType;

  public FundsInBasketInputDto(List<BasketBenefitListInputDto> benefits, BasketType basketType) {
    this.benefits = benefits;
    this.basketType = basketType;
  }
}
