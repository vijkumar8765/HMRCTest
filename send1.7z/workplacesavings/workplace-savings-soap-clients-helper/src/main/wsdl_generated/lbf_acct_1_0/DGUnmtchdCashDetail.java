
package lbf_acct_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_UnmtchdCashDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_UnmtchdCashDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="contributorType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="validContributorFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="unmtchdCashTotal" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_UnmtchdCashDetail", propOrder = {
    "contributorType",
    "validContributorFlag",
    "unmtchdCashTotal"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGUnmtchdCashDetail
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String contributorType;
    protected Boolean validContributorFlag;
    protected Double unmtchdCashTotal;

    /**
     * Gets the value of the contributorType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContributorType() {
        return contributorType;
    }

    /**
     * Sets the value of the contributorType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContributorType(String value) {
        this.contributorType = value;
    }

    /**
     * Gets the value of the validContributorFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isValidContributorFlag() {
        return validContributorFlag;
    }

    /**
     * Sets the value of the validContributorFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setValidContributorFlag(Boolean value) {
        this.validContributorFlag = value;
    }

    /**
     * Gets the value of the unmtchdCashTotal property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getUnmtchdCashTotal() {
        return unmtchdCashTotal;
    }

    /**
     * Sets the value of the unmtchdCashTotal property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setUnmtchdCashTotal(Double value) {
        this.unmtchdCashTotal = value;
    }

}
