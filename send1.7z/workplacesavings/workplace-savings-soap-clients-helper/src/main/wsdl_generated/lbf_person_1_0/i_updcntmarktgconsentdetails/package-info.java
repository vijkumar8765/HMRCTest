@javax.xml.bind.annotation.XmlSchema(namespace = "http://LBF_Person_1_0/I_UpdCntMarktgConsentDetails")
package lbf_person_1_0.i_updcntmarktgconsentdetails;
