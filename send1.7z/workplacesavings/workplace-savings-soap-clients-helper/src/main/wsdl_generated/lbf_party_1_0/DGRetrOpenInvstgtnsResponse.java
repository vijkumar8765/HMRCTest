
package lbf_party_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGResponseEnvelope;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_RetrOpenInvstgtnsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_RetrOpenInvstgtnsResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_ResponseEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="result" type="{http://LBF_Party_1_0}DG_RetrOpenInvstgtnsResult" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_RetrOpenInvstgtnsResponse", propOrder = {
    "result"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGRetrOpenInvstgtnsResponse
    extends DGResponseEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGRetrOpenInvstgtnsResult result;

    /**
     * Gets the value of the result property.
     * 
     * @return
     *     possible object is
     *     {@link DGRetrOpenInvstgtnsResult }
     *     
     */
    public DGRetrOpenInvstgtnsResult getResult() {
        return result;
    }

    /**
     * Sets the value of the result property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGRetrOpenInvstgtnsResult }
     *     
     */
    public void setResult(DGRetrOpenInvstgtnsResult value) {
        this.result = value;
    }

}
