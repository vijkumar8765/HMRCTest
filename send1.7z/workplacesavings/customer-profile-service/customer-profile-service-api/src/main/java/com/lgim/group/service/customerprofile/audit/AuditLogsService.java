package com.lgim.group.service.customerprofile.audit;

import com.lgim.group.ws.utility.plugin.model.GroupDigitalMessage;
import com.lgim.group.ws.utility.plugin.util.AuditRouteHelper;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.springframework.stereotype.Component;

@Setter
@Slf4j
@Component
public class AuditLogsService {
  private CamelContext camelContext;
  private ProducerTemplate producerTemplate;
  private AuditRouteHelper auditRouteHelper;


  public void audit(GroupDigitalMessage groupDigitalMessage) {
    log.info("Audit logs service invoked");
    auditRouteHelper.sendGroupDigitalMessageForAuditing(this.producerTemplate, groupDigitalMessage);
  }

}
