package com.lgim.group.service.graphql.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto implements java.io.Serializable {

  private Boolean permittedByScheme;
  private WorkInProgressCheckDto wipStatus;
  private Boolean noPostalAddress;

  public WorkplacePensionSwitchAndRedirectCheckAllowedResponseDto(Boolean permittedByScheme, WorkInProgressCheckDto wipStatus, Boolean noPostalAddress) {
    this.permittedByScheme = permittedByScheme;
    this.wipStatus = wipStatus;
    this.noPostalAddress = noPostalAddress;
  }
}
