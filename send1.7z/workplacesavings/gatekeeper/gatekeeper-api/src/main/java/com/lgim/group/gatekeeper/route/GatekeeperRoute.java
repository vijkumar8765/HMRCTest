package com.lgim.group.gatekeeper.route;

import com.lgim.group.gatekeeper.exception.JwtAuthenticationException;
import com.lgim.group.gatekeeper.exception.ProxyEndPointNotFoundException;
import com.lgim.group.gatekeeper.processor.ProxyRequestProcessor;
import com.lgim.group.gatekeeper.processor.ValidateJwtTokenProcessor;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.apache.camel.LoggingLevel;

@Component
public class GatekeeperRoute extends RouteBuilder {

  @Value("${rest_address:localhost}")
  private String gatekeeperUriLocal;

  @Value("${rest_port:9111}")
  private String port;

  @Autowired
  private ProxyRequestProcessor proxyProcessor;


  @Override
  public void configure() {

    String validateGatewayCall = "direct:gatekeeperRoute";

    restConfiguration()
        .component("restlet")
        .enableCORS(true)
        .host(gatekeeperUriLocal)
        .port(port)
        .bindingMode(RestBindingMode.off)
        .dataFormatProperty("prettyPrint", "true");

    rest("/")
        .post()
        .to(validateGatewayCall);


    from(validateGatewayCall)
        .routeId("gatekeeper-validate-jwt-token")
        .doTry()
          .to(GatekeeperCommonRoute.VALIDATE_JWT_TOKEN)
          .removeHeader("CLAIMS")
          .process(proxyProcessor)
          .setHeader("CamelHttpMethod", constant("POST"))
          .removeHeader("CamelHttpUri")
          .toD("${headers.proxyEndPoint}")
        .doCatch(JwtAuthenticationException.class)
            .setHeader(Exchange.HTTP_RESPONSE_CODE,simple("401"))
            .setBody(simple("Authentication Failed"))
        .doCatch(ProxyEndPointNotFoundException.class)
            .setHeader(Exchange.HTTP_RESPONSE_CODE,simple("404"))
            .setBody(simple("Endpoint not found"))
        .endDoTry()
        .end();

  }
}
