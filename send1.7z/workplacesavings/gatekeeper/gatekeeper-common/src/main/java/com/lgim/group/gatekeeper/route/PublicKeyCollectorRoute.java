package com.lgim.group.gatekeeper.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PublicKeyCollectorRoute extends RouteBuilder {

  public static final String ROUTE_ID = "fetch-sso-public-key-route";

  @Value("${public_key_check_interval:30000}")
  private int interval;

  @Override
  public void configure() {

    from("timer://simpleTimer?period=" + interval)
        .routeId(ROUTE_ID)
        .to("bean:publicKeyHelper?method=fetchPublicKey");

  }
}

