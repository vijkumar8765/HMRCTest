
package lbb_acct_b_1_0;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import lb_annotations_1_0.DGAnnotatableObject;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DA_AccountMembershipDtls complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DA_AccountMembershipDtls"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Annotations_1_0}DG_AnnotatableObject"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="opRulesRegime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="avcRegime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="pensionableServiceStatusCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="servicePeriodStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="servicePeriodEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="serviceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currentOpRegime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currentAvcRegime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="currentServicePeriodStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="currentServicePeriodEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="externalFundAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="tfcDrvtFundAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="tfcProtectedAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="postAdayAccruralIndicator" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="tfcGreaterThanThresholdAmount" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DA_AccountMembershipDtls", propOrder = {
    "opRulesRegime",
    "avcRegime",
    "pensionableServiceStatusCode",
    "servicePeriodStartDate",
    "servicePeriodEndDate",
    "serviceCode",
    "currentOpRegime",
    "currentAvcRegime",
    "currentServicePeriodStartDate",
    "currentServicePeriodEndDate",
    "externalFundAmount",
    "tfcDrvtFundAmount",
    "tfcProtectedAmount",
    "postAdayAccruralIndicator",
    "tfcGreaterThanThresholdAmount"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DAAccountMembershipDtls
    extends DGAnnotatableObject
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected String opRulesRegime;
    protected String avcRegime;
    protected String pensionableServiceStatusCode;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar servicePeriodStartDate;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar servicePeriodEndDate;
    protected String serviceCode;
    protected String currentOpRegime;
    protected String currentAvcRegime;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar currentServicePeriodStartDate;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar currentServicePeriodEndDate;
    protected BigDecimal externalFundAmount;
    protected BigDecimal tfcDrvtFundAmount;
    protected BigDecimal tfcProtectedAmount;
    protected Boolean postAdayAccruralIndicator;
    protected Boolean tfcGreaterThanThresholdAmount;

    /**
     * Gets the value of the opRulesRegime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpRulesRegime() {
        return opRulesRegime;
    }

    /**
     * Sets the value of the opRulesRegime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpRulesRegime(String value) {
        this.opRulesRegime = value;
    }

    /**
     * Gets the value of the avcRegime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvcRegime() {
        return avcRegime;
    }

    /**
     * Sets the value of the avcRegime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvcRegime(String value) {
        this.avcRegime = value;
    }

    /**
     * Gets the value of the pensionableServiceStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPensionableServiceStatusCode() {
        return pensionableServiceStatusCode;
    }

    /**
     * Sets the value of the pensionableServiceStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPensionableServiceStatusCode(String value) {
        this.pensionableServiceStatusCode = value;
    }

    /**
     * Gets the value of the servicePeriodStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getServicePeriodStartDate() {
        return servicePeriodStartDate;
    }

    /**
     * Sets the value of the servicePeriodStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setServicePeriodStartDate(XMLGregorianCalendar value) {
        this.servicePeriodStartDate = value;
    }

    /**
     * Gets the value of the servicePeriodEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getServicePeriodEndDate() {
        return servicePeriodEndDate;
    }

    /**
     * Sets the value of the servicePeriodEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setServicePeriodEndDate(XMLGregorianCalendar value) {
        this.servicePeriodEndDate = value;
    }

    /**
     * Gets the value of the serviceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceCode() {
        return serviceCode;
    }

    /**
     * Sets the value of the serviceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceCode(String value) {
        this.serviceCode = value;
    }

    /**
     * Gets the value of the currentOpRegime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentOpRegime() {
        return currentOpRegime;
    }

    /**
     * Sets the value of the currentOpRegime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentOpRegime(String value) {
        this.currentOpRegime = value;
    }

    /**
     * Gets the value of the currentAvcRegime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentAvcRegime() {
        return currentAvcRegime;
    }

    /**
     * Sets the value of the currentAvcRegime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentAvcRegime(String value) {
        this.currentAvcRegime = value;
    }

    /**
     * Gets the value of the currentServicePeriodStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCurrentServicePeriodStartDate() {
        return currentServicePeriodStartDate;
    }

    /**
     * Sets the value of the currentServicePeriodStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCurrentServicePeriodStartDate(XMLGregorianCalendar value) {
        this.currentServicePeriodStartDate = value;
    }

    /**
     * Gets the value of the currentServicePeriodEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCurrentServicePeriodEndDate() {
        return currentServicePeriodEndDate;
    }

    /**
     * Sets the value of the currentServicePeriodEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCurrentServicePeriodEndDate(XMLGregorianCalendar value) {
        this.currentServicePeriodEndDate = value;
    }

    /**
     * Gets the value of the externalFundAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getExternalFundAmount() {
        return externalFundAmount;
    }

    /**
     * Sets the value of the externalFundAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setExternalFundAmount(BigDecimal value) {
        this.externalFundAmount = value;
    }

    /**
     * Gets the value of the tfcDrvtFundAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTfcDrvtFundAmount() {
        return tfcDrvtFundAmount;
    }

    /**
     * Sets the value of the tfcDrvtFundAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTfcDrvtFundAmount(BigDecimal value) {
        this.tfcDrvtFundAmount = value;
    }

    /**
     * Gets the value of the tfcProtectedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTfcProtectedAmount() {
        return tfcProtectedAmount;
    }

    /**
     * Sets the value of the tfcProtectedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTfcProtectedAmount(BigDecimal value) {
        this.tfcProtectedAmount = value;
    }

    /**
     * Gets the value of the postAdayAccruralIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPostAdayAccruralIndicator() {
        return postAdayAccruralIndicator;
    }

    /**
     * Sets the value of the postAdayAccruralIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPostAdayAccruralIndicator(Boolean value) {
        this.postAdayAccruralIndicator = value;
    }

    /**
     * Gets the value of the tfcGreaterThanThresholdAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTfcGreaterThanThresholdAmount() {
        return tfcGreaterThanThresholdAmount;
    }

    /**
     * Sets the value of the tfcGreaterThanThresholdAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTfcGreaterThanThresholdAmount(Boolean value) {
        this.tfcGreaterThanThresholdAmount = value;
    }

}
