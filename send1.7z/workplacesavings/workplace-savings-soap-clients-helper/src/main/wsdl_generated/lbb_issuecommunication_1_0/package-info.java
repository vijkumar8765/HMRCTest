@javax.xml.bind.annotation.XmlSchema(namespace = "http://LBB_IssueCommunication_1_0")
package lbb_issuecommunication_1_0;
