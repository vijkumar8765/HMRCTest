
package lbf_acct_1_0;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lb_envelope_1_0.DGRequestEnvelope;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * <p>Java class for DG_RetrWIPRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DG_RetrWIPRequest"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://LB_Envelope_1_0}DG_RequestEnvelope"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="wipSearchCriteria" type="{http://LBF_Acct_1_0}DG_WIPSearchCriteria" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DG_RetrWIPRequest", propOrder = {
    "wipSearchCriteria"
})
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DGRetrWIPRequest
    extends DGRequestEnvelope
    implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected DGWIPSearchCriteria wipSearchCriteria;

    /**
     * Gets the value of the wipSearchCriteria property.
     * 
     * @return
     *     possible object is
     *     {@link DGWIPSearchCriteria }
     *     
     */
    public DGWIPSearchCriteria getWipSearchCriteria() {
        return wipSearchCriteria;
    }

    /**
     * Sets the value of the wipSearchCriteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link DGWIPSearchCriteria }
     *     
     */
    public void setWipSearchCriteria(DGWIPSearchCriteria value) {
        this.wipSearchCriteria = value;
    }

}
