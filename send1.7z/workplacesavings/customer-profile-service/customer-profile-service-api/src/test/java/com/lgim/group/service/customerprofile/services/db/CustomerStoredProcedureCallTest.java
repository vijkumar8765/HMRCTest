package com.lgim.group.service.customerprofile.services.db;

import com.lgim.group.service.customerprofile.dto.CustomerProfileDto;
import com.lgim.group.service.customerprofile.dto.ImmutableCustomerProfileDto;
import com.lgim.group.service.customerprofile.exception.CustomerNotFoundException;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
//import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CustomerStoredProcedureCallTest {

  private static final String CUSTOMER_ID = "Customer ID";
  @Mock
  private DataSource mockDataSource;
  @Mock
  private SimpleJdbcCall mockSimpleJdbcCall;
  @InjectMocks
  private CustomerStoredProcedureCall underTest;

  @Test
  public void execute() {
    final Map<String, Object> results = new HashMap<>();
    final ResultSet mockResultSet = mock(ResultSet.class);
    results.put(CustomerStoredProcedureCall.RESULT_SET_KEY, mockResultSet);

    final Map<String, Object> actual = underTest.execute(CUSTOMER_ID);

    assertNotNull("Unexpected customer profile from mapFrom result set", actual);
  }

  @Test(expected = CustomerNotFoundException.class)
  public void executeThrowsCustomerNotFoundException() {
    when(mockSimpleJdbcCall.execute(any(SqlParameterSource.class))).thenThrow(new DataAccessException("...") {
    });
    underTest.execute(CUSTOMER_ID);
  }

  @Test
  public void mapFrom() throws SQLException {
    final ResultSet mockResultSet = mock(ResultSet.class);
    final String forename = "forename";
    final String surname = "surname";
    final java.sql.Date birthDate = new java.sql.Date(new java.util.Date().getTime());
    final String gender = "gender";
    final String title = "title";

    when(mockResultSet.getString(CustomerStoredProcedureCall.OUT_FIRST_FORENAME)).thenReturn(forename);
    when(mockResultSet.getString(CustomerStoredProcedureCall.OUT_SURNAME)).thenReturn(surname);
    when(mockResultSet.getDate(CustomerStoredProcedureCall.OUT_BIRTH_DATE)).thenReturn(birthDate);
    when(mockResultSet.getString(CustomerStoredProcedureCall.OUT_GENDER)).thenReturn(gender);
    when(mockResultSet.getString(CustomerStoredProcedureCall.OUT_TITLE)).thenReturn(title);

    final CustomerProfileDto expected = ImmutableCustomerProfileDto.builder()
        .withForename(forename)
        .withSurname(surname)
        .withDateOfBirth(birthDate)
        .withGender(gender)
        .withTitle(title)
        .build();


    final CustomerProfileDto actual = CustomerStoredProcedureCall.mapFrom(mockResultSet, 0);

    assertEquals("Unexpected customer profile from mapFrom result set", actual, expected);
  }


  @Test
  public void createJdbcCall() {
    final SimpleJdbcCall simpleJdbcCall = underTest.getSimpleJdbcCall(mockDataSource);
    assertNotNull(simpleJdbcCall);
  }
}